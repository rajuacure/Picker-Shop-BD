<?php
namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/** সাইটে ৫০০ এরর বা কিছু কাজ না করলে একবার চালিয়ে কারণ বের করার কমান্ড: php artisan site:doctor */
class SiteDoctor extends Command
{
    protected $signature = 'site:doctor';
    protected $description = 'সাইটের সাধারণ সমস্যা (বাকি migrate, ফাইল, এক্সটেনশন, সর্বশেষ এরর) পরীক্ষা করে';

    private int $problems = 0;

    private function ok(string $m): void { $this->line('  ✔ ' . $m); }
    private function bad(string $m, string $fix = ''): void { $this->problems++; $this->error('  ✘ ' . $m); if ($fix) $this->line('      → ' . $fix); }

    public function handle(): int
    {
        $this->info('=== সাইট ডাক্তার · ' . now()->format('d M Y h:i A') . ' ===');
        $this->line('PHP ' . PHP_VERSION . ' · Laravel ' . app()->version() . ' · মেমোরি লিমিট ' . ini_get('memory_limit'));

        // ১) পরিবেশ
        $this->info("\n১) পরিবেশ (.env)");
        config('app.key') ? $this->ok('APP_KEY আছে') : $this->bad('APP_KEY নেই', 'artisan key:generate চালান');
        $this->ok('APP_URL = ' . config('app.url') . ' · APP_DEBUG = ' . (config('app.debug') ? 'true (সাইট চালু হলে false রাখুন)' : 'false'));
        $this->ok('SESSION_DRIVER = ' . config('session.driver') . ' · CACHE = ' . config('cache.default'));

        // ২) ডাটাবেস
        $this->info("\n২) ডাটাবেস");
        try {
            DB::connection()->getPdo();
            $this->ok('সংযোগ ঠিক আছে (' . config('database.default') . ' · ' . DB::connection()->getDatabaseName() . ')');
        } catch (\Throwable $e) {
            $this->bad('ডাটাবেসে সংযোগ হচ্ছে না: ' . mb_substr($e->getMessage(), 0, 200), '.env-এর DB_DATABASE, DB_USERNAME, DB_PASSWORD ও DB_CONNECTION=mysql দেখুন');
            return $this->finish();
        }

        // ৩) বাকি migrate
        $this->info("\n৩) বাকি migrate");
        try {
            $m = app('migrator');
            $files = $m->getMigrationFiles(array_merge($m->paths(), [database_path('migrations')]));
            $ran = $m->getRepository()->getRan();
            $pending = array_values(array_diff(array_keys($files), $ran));
            if ($pending) {
                $this->bad(count($pending) . 'টি migrate বাকি আছে: ' . implode(', ', $pending), 'artisan migrate --force চালান (এটাই ৫০০ এররের সবচেয়ে সাধারণ কারণ)');
            } else {
                $this->ok('সব migrate শেষ');
            }
        } catch (\Throwable $e) {
            $this->bad('migrate যাচাই করা যায়নি: ' . mb_substr($e->getMessage(), 0, 160));
        }

        // ৪) দরকারি টেবিল ও কলাম
        $this->info("\n৪) টেবিল ও কলাম");
        $need = [
            'products' => ['name_en', 'cost_price', 'offer_price', 'slug', 'meta_title'],
            'orders' => ['discount', 'source', 'courier', 'courier_tracking_code', 'risk_score', 'is_fake', 'ip_hash', 'shipping_zone'],
            'order_items' => ['variant_id', 'cost_price'],
            'product_variants' => [], 'visitor_sessions' => [], 'reviews' => [], 'admin_notifications' => [], 'expenses' => [],
            'expense_categories' => [], 'blocked_phones' => [], 'admin_users' => [], 'abandoned_checkouts' => [], 'shipping_zones' => [],
            'order_events' => [], 'settings' => [], 'sliders' => [], 'categories' => [], 'pages' => [],
        ];
        $miss = [];
        foreach ($need as $table => $cols) {
            if (! Schema::hasTable($table)) { $miss[] = "টেবিল {$table} নেই"; continue; }
            foreach ($cols as $c) if (! Schema::hasColumn($table, $c)) $miss[] = "{$table}.{$c} নেই";
        }
        $miss ? $this->bad(implode(' · ', $miss), 'ওপরের migrate চালালে ঠিক হবে') : $this->ok('সব টেবিল ও কলাম আছে');

        // ৫) ফাইল ও ফোল্ডার
        $this->info("\n৫) ফোল্ডার ও ফাইল");
        foreach ([storage_path(), storage_path('logs'), storage_path('framework/views'), storage_path('framework/cache'), base_path('bootstrap/cache')] as $dir) {
            is_writable($dir) ? $this->ok('লেখা যায়: ' . str_replace(base_path() . '/', '', $dir)) : $this->bad('লেখা যায় না: ' . $dir, 'File Manager থেকে ফোল্ডারের Permission 755 বা 775 করুন');
        }
        $up = \App\Support\Uploader::root() . '/uploads';
        is_dir($up) && is_writable($up) ? $this->ok('ছবির ফোল্ডার ঠিক আছে: ' . $up) : $this->bad('ছবির ফোল্ডার নেই বা লেখা যায় না: ' . $up, 'একবার ছবি আপলোড করলে নিজে তৈরি হয়; না হলে Permission দেখুন');
        foreach (['app/Http/Controllers/Admin/DashboardController.php', 'resources/views/layouts/app.blade.php', 'resources/views/layouts/admin.blade.php', 'routes/web.php'] as $f) {
            is_file(base_path($f)) ? null : $this->bad("ফাইল নেই: {$f}", 'সংশ্লিষ্ট আপডেটের জিপ আবার Extract করুন');
        }

        // ৬) PHP এক্সটেনশন
        $this->info("\n৬) PHP এক্সটেনশন");
        foreach (['pdo_mysql' => true, 'mbstring' => true, 'openssl' => true, 'curl' => true, 'fileinfo' => true, 'gd' => false, 'exif' => false] as $ext => $must) {
            if (extension_loaded($ext)) $this->ok($ext);
            elseif ($must) $this->bad("{$ext} চালু নেই", 'cPanel → Select PHP Version → Extensions থেকে চালু করুন');
            else $this->line("  – {$ext} চালু নেই (ঐচ্ছিক" . ($ext === 'gd' ? ': ছবি নিজে ছোট হবে না' : ': ফোনের ঘোরানো ছবি সোজা হবে না') . ')');
        }

        // ৭) সর্বশেষ এরর
        $this->info("\n৭) লগের সর্বশেষ এরর");
        $logs = glob(storage_path('logs/*.log')) ?: [];
        usort($logs, fn ($a, $b) => filemtime($b) <=> filemtime($a));
        if (! $logs) {
            $this->ok('কোনো লগ ফাইল নেই');
        } else {
            $size = filesize($logs[0]);
            $tail = (string) file_get_contents($logs[0], false, null, max(0, $size - 400000));
            preg_match_all('/^\[(\d{4}-\d\d-\d\d [\d:]+)\] \S+\.ERROR: (.*)$/m', $tail, $mm, PREG_SET_ORDER);
            if (! $mm) {
                $this->ok(basename($logs[0]) . ' এ সাম্প্রতিক কোনো ERROR নেই');
            } else {
                foreach (array_slice($mm, -4) as $e) {
                    $msg = mb_substr(trim($e[2]), 0, 420);
                    $this->line('  [' . $e[1] . '] ' . $msg);
                    if (str_contains($msg, 'Unknown column') || str_contains($msg, 'Base table or view not found')) $this->line('      → ডাটাবেসে কলাম/টেবিল নেই: migrate চালান');
                    elseif (str_contains($msg, 'Class "') || str_contains($msg, 'does not exist')) $this->line('      → কোনো ফাইল বসেনি: সংশ্লিষ্ট জিপ আবার Extract করুন');
                    elseif (str_contains($msg, 'Route [')) $this->line('      → রুট ফাইল (routes/web.php) পুরোনো: সর্বশেষ জিপ Extract করুন ও optimize:clear চালান');
                }
            }
        }

        // ৮) রুট ও কন্ট্রোলার (ফাইল পুরোনো-নতুন মিশে গেলে এখানে ধরা পড়ে)
        $this->info("\n৮) রুট ও কন্ট্রোলার");
        $routes = \Illuminate\Support\Facades\Route::getRoutes();
        $names = [];
        $badCls = [];
        foreach ($routes as $r) {
            if ($r->getName()) $names[$r->getName()] = true;
            $c = $r->getAction('controller');
            if (is_string($c) && str_contains($c, '@')) {
                [$cls, $m] = explode('@', $c, 2);
                if (! class_exists($cls)) $badCls[$cls] = true;
                elseif (! method_exists($cls, $m)) $badCls[$cls . '@' . $m] = true;
            }
        }
        $badCls ? $this->bad('রুটে থাকা কন্ট্রোলার পাওয়া যাচ্ছে না: ' . implode(', ', array_keys($badCls)), 'সংশ্লিষ্ট আপডেটের জিপ আবার Extract করুন') : $this->ok('সব রুটের কন্ট্রোলার আছে (' . count($routes->getRoutes()) . 'টি রুট)');

        $missRoutes = [];
        foreach ($this->phpAndBladeFiles([resource_path('views'), app_path()]) as $f) {
            if (preg_match_all('/(?<![>:\w])route\(\s*\'([a-zA-Z0-9_.\-]+)\'/', (string) file_get_contents($f), $mm)) {
                foreach (array_unique($mm[1]) as $n) if (! isset($names[$n])) $missRoutes[$n][] = str_replace(base_path() . '/', '', $f);
            }
        }
        if ($missRoutes) {
            foreach (array_slice($missRoutes, 0, 8, true) as $n => $fs) $this->bad("রুট \"{$n}\" নেই, অথচ ব্যবহার হয়েছে: " . implode(', ', array_slice(array_unique($fs), 0, 3)), 'routes/web.php পুরোনো/নতুন মিশে গেছে। সর্বশেষ আপডেটের জিপ Extract করুন, তারপর optimize:clear চালান (এটাই অ্যাডমিন পেজে 500-এর সাধারণ কারণ)');
        } else {
            $this->ok('ভিউ ও কোডে ব্যবহৃত সব রুটের নাম আছে');
        }

        // ৯) সিনট্যাক্স যাচাই (PHP ও Blade)
        $this->info("\n৯) ফাইলের সিনট্যাক্স");
        $errs = [];
        $blade = app('blade.compiler');
        foreach ($this->phpAndBladeFiles([app_path(), base_path('routes'), database_path('migrations'), resource_path('views')]) as $f) {
            $code = (string) file_get_contents($f);
            $rel = str_replace(base_path() . '/', '', $f);
            try {
                if (str_ends_with($f, '.blade.php')) $code = $blade->compileString($code);
                token_get_all($code, TOKEN_PARSE);
            } catch (\ParseError $e) {
                $errs[] = $rel . ' — ' . $e->getMessage() . ' (লাইন ' . $e->getLine() . (str_ends_with($f, '.blade.php') ? ', কম্পাইল করা কোডে' : '') . ')';
            } catch (\Throwable $e) {
                // কম্পাইলের অন্য সমস্যা এখানে ধরা হয় না
            }
        }
        if ($errs) foreach (array_slice($errs, 0, 8) as $e) $this->bad($e, 'ফাইলটি অসম্পূর্ণ বা ভুলভাবে আপলোড হয়েছে: জিপ আবার Extract করুন');
        else $this->ok('সব PHP ও Blade ফাইলের সিনট্যাক্স ঠিক আছে');

        // ১০) পেমেন্ট গেটওয়ে (গোপন তথ্য দেখায় না, শুধু আছে/নেই)
        $this->info("\n১০) পেমেন্ট গেটওয়ে");
        $has = fn ($v) => $v !== null && trim((string) $v) !== '';
        $ssl = (array) config('shop.payments.sslcommerz');
        $bk = (array) config('shop.payments.bkash');
        $this->line('  SSLCommerz: Store ID ' . ($has($ssl['store_id'] ?? null) ? 'আছে' : 'নেই') . ' · Password ' . ($has($ssl['store_passwd'] ?? null) ? 'আছে' : 'নেই') . ' · মোড ' . (($ssl['sandbox'] ?? true) ? 'Sandbox (পরীক্ষা)' : 'Live (আসল)'));
        $this->line('  bKash: Username ' . ($has($bk['username'] ?? null) ? 'আছে' : 'নেই') . ' · Password ' . ($has($bk['password'] ?? null) ? 'আছে' : 'নেই') . ' · App Key ' . ($has($bk['app_key'] ?? null) ? 'আছে' : 'নেই') . ' · App Secret ' . ($has($bk['app_secret'] ?? null) ? 'আছে' : 'নেই'));
        if (app()->configurationIsCached()) $this->line('  ⚠ কনফিগ ক্যাশ করা আছে: .env বদলালে optimize:clear চালাতে হয়');

        $env = is_file(base_path('.env')) ? (string) file_get_contents(base_path('.env')) : '';
        foreach (['SSLCOMMERZ_STORE_ID', 'SSLCOMMERZ_STORE_PASSWORD'] as $k) {
            if (! preg_match('/^' . $k . '=(.*)$/m', $env, $mm)) {
                $this->line("  .env-এ {$k} লাইনটিই নেই");
            } else {
                $v = trim($mm[1]);
                $this->line("  .env-এ {$k}: " . ($v === '' ? 'লাইন আছে কিন্তু মান ফাঁকা' : 'মান বসানো আছে'));
                if ($v !== '' && ! preg_match('/^["\'].*["\']$/', $v) && preg_match('/[#\s]/', $v)) {
                    $this->bad("{$k}-এর মানে # বা ফাঁকা আছে কিন্তু \" \" দেওয়া নেই, তাই মান কেটে যাচ্ছে", 'মানটির দুই পাশে ডবল কোটেশন দিন, যেমন ' . $k . '="abc#123"');
                }
            }
        }
        try {
            $on = array_keys(\App\Support\Payments::methods());
            $this->line('  চেকআউটে এখন দেখানো হচ্ছে: ' . implode(', ', $on));
            if (! in_array('sslcommerz', $on, true)) {
                $this->bad('SSLCommerz চেকআউটে চালু নেই', 'SSLCOMMERZ_STORE_ID ও SSLCOMMERZ_STORE_PASSWORD .env-এ ঠিকমতো বসিয়ে optimize:clear চালান');
            } else {
                $this->ok('SSLCommerz চেকআউটে চালু আছে');
            }
        } catch (\Throwable $e) {
            $this->bad('পেমেন্ট মেথড যাচাই করা যায়নি: ' . mb_substr($e->getMessage(), 0, 160));
        }

        return $this->finish();
    }

    /** @return array<int,string> */
    private function phpAndBladeFiles(array $dirs): array
    {
        $out = [];
        foreach ($dirs as $d) {
            if (! is_dir($d)) continue;
            foreach (new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($d, \FilesystemIterator::SKIP_DOTS)) as $f) {
                if ($f->isFile() && str_ends_with($f->getFilename(), '.php')) $out[] = $f->getPathname();
            }
        }
        return array_values(array_unique($out));
    }

    private function finish(): int
    {
        $this->line('');
        if ($this->problems === 0) {
            $this->info('✔ কোনো সমস্যা পাওয়া যায়নি। এরর হলে ওপরের "সর্বশেষ এরর" অংশের লেখা পাঠান।');
            return self::SUCCESS;
        }
        $this->error("✘ {$this->problems}টি সমস্যা পাওয়া গেছে, ওপরের → চিহ্নের নির্দেশ অনুযায়ী ঠিক করুন।");
        return self::FAILURE;
    }
}
