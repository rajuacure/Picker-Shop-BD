@php
    $badge = ['pending' => 'bg-amber-100 text-amber-800', 'confirmed' => 'bg-sky-100 text-sky-800', 'shipped' => 'bg-indigo-100 text-indigo-800', 'delivered' => 'bg-green-100 text-green-800', 'cancelled' => 'bg-slate-200 text-slate-600'];
    $payBadge = ['paid' => ['পরিশোধিত', 'text-green-700'], 'failed' => ['ব্যর্থ', 'text-red-600'], 'unpaid' => ['বাকি', 'text-amber-700']];
@endphp
<table class="w-full text-sm">
    <thead class="text-left text-slate-500 border-b border-slate-100">
        <tr>@if ($selectable ?? false)<th class="p-3 w-8"><input type="checkbox" id="selAll" aria-label="সব বাছুন"></th>@endif<th class="p-3">অর্ডার</th><th class="p-3">গ্রাহক</th><th class="p-3">মোট</th><th class="p-3">পেমেন্ট</th><th class="p-3">স্ট্যাটাস</th><th class="p-3">সময়</th></tr>
    </thead>
    <tbody class="divide-y divide-slate-100">
    @forelse ($orders as $o)
        <tr class="hover:bg-slate-50">
            @if ($selectable ?? false)<td class="p-3"><input type="checkbox" name="ids[]" value="{{ $o->id }}" class="sel" form="bulkForm" data-no="{{ $o->order_no }}" data-name="{{ $o->customer_name }}" data-phone="{{ $o->phone }}" data-status="{{ $o->status }}" data-sent="{{ $o->courier_tracking_code ? 1 : 0 }}" data-risk="{{ (int) ($o->risk_score ?? 0) }}" data-fake="{{ $o->is_fake ? 1 : 0 }}" data-cod="{{ $o->payment_status === 'paid' ? 0 : (int) $o->total }}"></td>@endif
            <td class="p-3"><a href="{{ route('admin.orders.show', $o) }}" class="text-brand font-medium">{{ $o->order_no }}</a>@if ($o->is_fake)<span class="ml-1 text-[10px] rounded bg-red-600 text-white px-1">ফেক</span>@elseif (($o->risk_score ?? 0) >= 60)<span title="{{ str_replace('|', ' · ', (string) $o->risk_flags) }}" class="ml-1 text-[10px] rounded bg-red-100 text-red-700 px-1">⚠ ঝুঁকি {{ $o->risk_score }}</span>@elseif (($o->risk_score ?? 0) >= 30)<span title="{{ str_replace('|', ' · ', (string) $o->risk_flags) }}" class="ml-1 text-[10px] rounded bg-amber-100 text-amber-800 px-1">সন্দেহ {{ $o->risk_score }}</span>@endif@if (($o->source ?? 'website') !== 'website')<span class="ml-1 text-[10px] rounded bg-slate-100 text-slate-500 px-1">ম্যানুয়াল</span>@endif</td>
            <td class="p-3">{{ $o->customer_name }}<div class="text-xs text-slate-500">{{ $o->phone }}@if($o->shipping_zone) · {{ $o->shipping_zone }}@endif</div></td>
            <td class="p-3">{{ config('shop.currency') }}{{ number_format($o->total) }}</td>
            <td class="p-3 whitespace-nowrap"><span class="text-xs text-slate-500">{{ \App\Support\Payments::label($o->payment_method) }}</span><div class="text-xs font-medium {{ $payBadge[$o->payment_status][1] ?? '' }}">{{ $payBadge[$o->payment_status][0] ?? $o->payment_status }}</div></td>
            <td class="p-3"><span class="px-2 py-0.5 rounded-full text-xs {{ $badge[$o->status] ?? '' }}">{{ $o->statusLabel() }}</span>@if ($o->courier_tracking_code)<div class="text-[11px] text-slate-500 mt-1 whitespace-nowrap" title="কুরিয়ারের স্ট্যাটাস: {{ \App\Services\Courier\Courier::statusLabel($o->courier_status) }}">🚚 {{ \App\Services\Courier\Courier::label($o->courier) }} · {{ $o->courier_tracking_code }}</div>@endif</td>
            <td class="p-3 text-slate-500 whitespace-nowrap" title="{{ $o->created_at->format('d M Y, h:i A') }}">{{ $o->created_at->diffForHumans() }}</td>
        </tr>
    @empty
        <tr><td colspan="7" class="p-6 text-center text-slate-500">কোনো অর্ডার পাওয়া যায়নি।</td></tr>
    @endforelse
    </tbody>
</table>
