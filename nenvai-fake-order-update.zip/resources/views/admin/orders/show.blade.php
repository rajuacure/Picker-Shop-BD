@extends('layouts.admin')
@section('title', $order->order_no)
@section('content')
@php
    $cur = config('shop.currency');
    $in = 'w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand';
    $badge = ['pending' => 'bg-amber-100 text-amber-800', 'confirmed' => 'bg-sky-100 text-sky-800', 'shipped' => 'bg-indigo-100 text-indigo-800', 'delivered' => 'bg-green-100 text-green-800', 'cancelled' => 'bg-slate-200 text-slate-600'];
    $payLabel = ['paid' => 'পরিশোধিত', 'failed' => 'ব্যর্থ', 'unpaid' => 'বাকি'];
    $typeIcon = ['created' => '🆕', 'status' => '🔄', 'payment' => '💳', 'note' => '📝', 'edit' => '✏️', 'courier' => '🚚', 'fake' => '🚫'];
    $wa = \App\Support\Contact::whatsappLinkFor($order->phone, 'আসসালামু আলাইকুম ' . $order->customer_name . ', আপনার অর্ডার ' . $order->order_no . ' সম্পর্কে...');
@endphp
<a href="{{ route('admin.orders.index') }}" class="text-sm text-brand">← সব অর্ডার</a>
<div class="flex flex-wrap items-center gap-3 mt-1 mb-6">
    <h1 class="text-2xl font-bold">{{ $order->order_no }}</h1>
    <span class="px-2.5 py-0.5 rounded-full text-sm {{ $badge[$order->status] ?? '' }}">{{ $order->statusLabel() }}</span>
    <span class="text-sm text-slate-500">{{ $order->created_at->format('d M Y, h:i A') }}</span>
    @if (($order->source ?? 'website') !== 'website')<span class="rounded-full bg-slate-100 text-slate-600 text-xs px-2.5 py-1">নিজে তৈরি: {{ \App\Http\Controllers\Admin\OrderEditorController::SOURCES[$order->source] ?? $order->source }}</span>@endif
    <span class="ml-auto flex flex-wrap gap-2">
        @if (\App\Support\AdminAuth::can('order_edit') && $order->status !== 'cancelled')<a href="{{ route('admin.orders.edit', $order) }}" class="rounded-lg border border-brand text-brand hover:bg-brand-soft px-4 py-2 text-sm font-medium">✏️ বিল এডিট</a>@endif
        <a href="{{ route('admin.orders.invoice', $order) }}" target="_blank" class="rounded-lg border border-slate-300 hover:bg-slate-100 px-4 py-2 text-sm">🧾 ইনভয়েস দেখুন</a>
        <a href="{{ route('admin.orders.invoice', [$order, 'print' => 1]) }}" target="_blank" class="rounded-lg bg-brand hover:bg-brand-dark text-white px-4 py-2 text-sm font-medium">🖨️ প্রিন্ট</a>
    </span>
</div>

<div class="grid lg:grid-cols-3 gap-6">
    <div class="lg:col-span-2 space-y-6">
        <section class="bg-white rounded-xl border border-slate-200 p-5">
            <h2 class="font-semibold mb-3">পণ্য</h2>
            <ul class="divide-y divide-slate-100 text-sm">
                @foreach ($order->items as $it)
                <li class="py-2 flex justify-between gap-3"><span>{{ $it->name }} × {{ $it->qty }}</span><span class="whitespace-nowrap">{{ $cur }}{{ number_format($it->price * $it->qty) }}</span></li>
                @endforeach
                @if ($order->discount > 0)<li class="py-2 flex justify-between text-green-700"><span>ছাড়</span><span>-{{ $cur }}{{ number_format($order->discount) }}</span></li>@endif
                <li class="py-2 flex justify-between text-slate-600"><span>ডেলিভারি চার্জ @if($order->shipping_zone)({{ $order->shipping_zone }})@endif</span><span>{{ $cur }}{{ number_format($order->shipping) }}</span></li>
                <li class="py-2 flex justify-between font-semibold text-base"><span>মোট</span><span>{{ $cur }}{{ number_format($order->total) }}</span></li>
            </ul>
        </section>

        <section class="bg-white rounded-xl border border-slate-200 p-5">
            <h2 class="font-semibold mb-4">অর্ডারের ইতিহাস</h2>
            <ol class="relative border-l-2 border-slate-200 ml-2 space-y-5">
                @forelse ($order->events as $e)
                <li class="ml-5">
                    <span class="absolute -left-[13px] flex h-6 w-6 items-center justify-center rounded-full bg-white border border-slate-200 text-xs">{{ $typeIcon[$e->type] ?? '•' }}</span>
                    <div class="text-sm">{{ $e->message }}</div>
                    <div class="text-xs text-slate-400">{{ $e->actor }} · {{ $e->created_at->format('d M Y, h:i A') }}</div>
                </li>
                @empty
                    <li class="ml-5 text-sm text-slate-500">এখনো কোনো ইতিহাস নেই।</li>
                @endforelse
            </ol>
            <form method="POST" action="{{ route('admin.orders.note', $order) }}" class="mt-5 flex gap-2">
                @csrf
                <input name="note" placeholder="অভ্যন্তরীণ নোট লিখুন (গ্রাহক দেখবে না)" class="{{ $in }}">
                <button class="rounded-lg border border-brand text-brand hover:bg-brand-soft px-4 text-sm whitespace-nowrap">নোট যোগ</button>
            </form>
            @error('note')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror
        </section>

        @if ($history->isNotEmpty())
        <section class="bg-white rounded-xl border border-slate-200 p-5 overflow-x-auto">
            <div class="flex flex-wrap items-baseline justify-between gap-2 mb-3">
                <h2 class="font-semibold">এই গ্রাহকের আগের অর্ডার</h2>
                <a href="{{ route('admin.customers.show', $order->phone) }}" class="text-sm text-brand">সব দেখুন →</a>
            </div>
            @include('admin.orders.table', ['orders' => $history])
        </section>
        @endif
    </div>

    <div class="space-y-6">
        <section class="bg-white rounded-xl border border-slate-200 p-5 text-sm space-y-1">
            <h2 class="font-semibold mb-2">গ্রাহক</h2>
            <div class="font-medium">{{ $order->customer_name }}</div>
            <a href="tel:{{ $order->phone }}" class="text-brand">{{ $order->phone }}</a>
            @if ($order->email)<div>{{ $order->email }}</div>@endif
            <div class="text-slate-600">{{ $order->address }}, {{ $order->city }}</div>
            @if ($order->note)<div class="text-slate-500 pt-2">গ্রাহকের নোট: {{ $order->note }}</div>@endif
            <div class="flex gap-2 pt-3">
                <a href="tel:{{ $order->phone }}" class="flex-1 text-center rounded-lg border border-slate-300 hover:bg-slate-100 py-1.5">কল</a>
                @if ($wa)<a href="{{ $wa }}" target="_blank" rel="noopener" class="flex-1 text-center rounded-lg bg-[#25D366] text-white py-1.5">WhatsApp</a>@endif
            </div>
            <div class="grid grid-cols-3 gap-2 pt-3 text-center text-xs">
                <div class="rounded-lg bg-slate-50 p-2"><div class="text-base font-bold">{{ (int) $stats->orders }}</div>অর্ডার</div>
                <div class="rounded-lg bg-slate-50 p-2"><div class="text-base font-bold">{{ (int) $stats->delivered }}</div>ডেলিভারড</div>
                <div class="rounded-lg bg-slate-50 p-2"><div class="text-base font-bold">{{ (int) $stats->cancelled }}</div>বাতিল</div>
            </div>
            <div class="text-xs text-slate-500 pt-1">মোট কেনাকাটা: {{ $cur }}{{ number_format($stats->spent) }}</div>
        </section>

        <section class="bg-white rounded-xl border border-slate-200 p-5 text-sm">
            <h2 class="font-semibold mb-3">স্ট্যাটাস</h2>
            <form method="POST" action="{{ route('admin.orders.status', $order) }}" class="flex gap-2">
                @csrf @method('PATCH')
                <select name="status" class="{{ $in }}">
                    @foreach (config('shop.statuses') as $k => $label)<option value="{{ $k }}" @selected($order->status === $k)>{{ $label }}</option>@endforeach
                </select>
                <button class="rounded-lg bg-brand text-white px-4">সেভ</button>
            </form>
            <p class="text-xs text-slate-500 mt-2">বাতিল করলে পণ্যের স্টক আবার যোগ হবে।</p>
        </section>

        @if ($order->status === 'delivered')
        @php
            $rv = \Illuminate\Support\Facades\URL::signedRoute('reviews.create', ['orderNo' => $order->order_no]);
            $rvWa = \App\Support\Contact::whatsappLinkFor($order->phone, 'আসসালামু আলাইকুম ' . $order->customer_name . ', ' . config('shop.name') . ' থেকে আপনার পণ্য কেমন লাগল? এই লিংকে ১ মিনিটে আপনার মতামত জানালে আমরা খুব খুশি হব: ' . $rv);
        @endphp
        <section class="bg-white rounded-xl border border-slate-200 p-5 text-sm">
            <h2 class="font-semibold mb-2">⭐ ক্রেতার ফিডব্যাক চান</h2>
            <p class="text-xs text-slate-500 mb-3">পণ্য পৌঁছানোর পর এই লিংক ক্রেতাকে পাঠান। ক্রেতা পণ্য ও সেবার রেটিং দিতে পারবে।</p>
            @if ($rvWa)<a href="{{ $rvWa }}" target="_blank" rel="noopener" class="block text-center rounded-lg bg-[#25D366] text-white py-1.5 mb-2">WhatsApp-এ পাঠান</a>@endif
            <input readonly value="{{ $rv }}" onclick="this.select()" class="w-full rounded border border-slate-300 bg-slate-50 px-2 py-1.5 text-xs font-mono">
        </section>
        @endif

        @php
            $risk = $order->risk_score;
            $flags = array_filter(explode('|', (string) $order->risk_flags));
            if ($risk === null) { $calc = \App\Support\Risk::assess($order); $risk = $calc['score']; $flags = $calc['flags']; $live = true; }
            $hist = \App\Support\Risk::history($order->phone, $order->id);
            $lvl = \App\Support\Risk::level($risk);
            $tone = ['high' => 'border-red-300 bg-red-50', 'mid' => 'border-amber-300 bg-amber-50', 'low' => 'border-green-200 bg-green-50'][$lvl];
        @endphp
        <section class="rounded-xl border {{ $tone }} p-5 text-sm">
            <h2 class="font-semibold mb-1">{{ $order->is_fake ? '🚫 ফেক অর্ডার' : ($lvl === 'high' ? '🔴 ঝুঁকিপূর্ণ অর্ডার' : ($lvl === 'mid' ? '🟡 সন্দেহজনক' : '🟢 ঝুঁকি কম')) }} <span class="font-normal text-slate-500">({{ $risk }}/১০০)</span></h2>
            @if (! empty($live))<p class="text-[11px] text-slate-400 mb-1">পুরোনো অর্ডার, এখন হিসাব করে দেখানো হচ্ছে।</p>@endif
            <ul class="list-disc pl-5 space-y-0.5 text-slate-700">@forelse ($flags as $f)<li>{{ $f }}</li>@empty<li>কোনো সতর্কসংকেত নেই</li>@endforelse</ul>
            <div class="mt-3 grid grid-cols-4 gap-1 text-center text-xs">
                <div class="rounded bg-white/70 py-1.5"><b>{{ $hist['total'] }}</b><br>আগের অর্ডার</div><div class="rounded bg-white/70 py-1.5"><b>{{ $hist['delivered'] }}</b><br>ডেলিভারড</div>
                <div class="rounded bg-white/70 py-1.5"><b>{{ $hist['cancelled'] }}</b><br>বাতিল</div><div class="rounded bg-white/70 py-1.5"><b>{{ $hist['fake'] }}</b><br>ফেক</div>
            </div>
            @if ($hist['blocked'])<p class="mt-2 text-xs text-red-700">এই নম্বর ব্লক করা আছে।</p>@endif
            <p class="mt-3 text-xs text-slate-500">এটা শুধু আন্দাজ। কনফার্ম করতে গ্রাহককে ফোন করে ঠিকানা ও পণ্য মিলিয়ে নিন।</p>
            @if (\App\Support\AdminAuth::can('order_edit'))
                @if ($order->is_fake)
                    <form method="POST" action="{{ route('admin.orders.unfake', $order) }}" class="mt-3" onsubmit="return confirm('ফেক চিহ্ন তুলে নেবেন?')">@csrf<button class="w-full rounded-lg border border-slate-300 bg-white hover:bg-slate-100 py-1.5">ফেক চিহ্ন তুলে নিন</button></form>
                @else
                    <form method="POST" action="{{ route('admin.orders.fake', $order) }}" class="mt-3 space-y-2" onsubmit="return confirm('অর্ডারটি ফেক হিসেবে বাতিল করবেন? স্টক ফেরত আসবে।')">@csrf
                        <label class="flex items-center gap-2 text-xs"><input type="checkbox" name="block" value="1" checked> এই নম্বর ব্লক করুন (ভবিষ্যতে অর্ডার করতে পারবে না)</label>
                        <button class="w-full rounded-lg bg-red-600 hover:bg-red-700 text-white py-1.5 font-medium">🚫 ফেক অর্ডার হিসেবে চিহ্নিত করুন</button>
                    </form>
                @endif
            @endif
        </section>

        @if (\App\Support\AdminAuth::can('courier'))
        @php $cList = \App\Services\Courier\Courier::available(); @endphp
        <section class="bg-white rounded-xl border border-slate-200 p-5 text-sm">
            <h2 class="font-semibold mb-2">🚚 কুরিয়ার</h2>
            @if ($order->courier_tracking_code || $order->courier)
                <div class="space-y-1">
                    <div>{{ \App\Services\Courier\Courier::label($order->courier) }}@if ($order->courier_tracking_code) · ট্র্যাকিং: <b class="font-mono select-all">{{ $order->courier_tracking_code }}</b>@endif</div>
                    @if ($order->courier_status)<div class="text-slate-600">স্ট্যাটাস: {{ \App\Services\Courier\Courier::statusLabel($order->courier_status) }}</div>@endif
                    @if ($order->courier_sent_at)<div class="text-xs text-slate-400">পাঠানো: {{ $order->courier_sent_at->format('d M Y, h:i A') }}</div>@endif
                </div>
                @if ($order->courier_consignment_id)<button type="button" id="cSync" class="mt-3 w-full rounded-lg border border-slate-300 hover:bg-slate-100 py-1.5">🔄 কুরিয়ারের স্ট্যাটাস আপডেট</button>@endif
            @elseif ($order->courier_error)
                <p class="text-red-600 text-xs mb-2">আগের চেষ্টা ব্যর্থ: {{ $order->courier_error }}</p>
            @endif

            @if (! $order->courier_tracking_code && ! in_array($order->status, ['cancelled', 'delivered'], true))
                @if ($cList)
                <div class="mt-3 flex gap-2">
                    <select id="cWhich1" class="flex-1 rounded-lg border border-slate-300 px-2 py-1.5">@foreach ($cList as $k => $l)<option value="{{ $k }}" @selected(\App\Services\Courier\Courier::defaultName() === $k)>{{ $l }}</option>@endforeach</select>
                    <button type="button" id="cSend" class="rounded-lg bg-brand hover:bg-brand-dark text-white px-4">পাঠান</button>
                </div>
                <p id="cMsg" class="mt-2 text-xs"></p>
                @else
                <p class="mt-2 text-xs text-slate-500">API সংযোগ নেই। @if (\App\Support\AdminAuth::can('settings'))<a href="{{ route('admin.courier.edit') }}" class="text-brand underline">কুরিয়ার সংযোগ করুন</a>@endif</p>
                @endif
                <details class="mt-3 text-xs"><summary class="cursor-pointer text-slate-500">অন্য কুরিয়ারে নিজে পাঠিয়েছেন? হাতে লিখে রাখুন</summary>
                    <form method="POST" action="{{ route('admin.orders.courier.manual', $order) }}" class="mt-2 space-y-2">@csrf
                        <input name="courier" placeholder="কুরিয়ারের নাম (RedX, Paperfly...)" class="w-full rounded-lg border border-slate-300 px-2 py-1.5" required>
                        <input name="tracking" placeholder="ট্র্যাকিং কোড (ঐচ্ছিক)" class="w-full rounded-lg border border-slate-300 px-2 py-1.5 font-mono">
                        <button class="w-full rounded-lg border border-brand text-brand hover:bg-brand-soft py-1.5">সেভ</button>
                    </form>
                </details>
            @endif
        </section>
        <script>
        (function () {
            var token = document.querySelector('meta[name=csrf-token]').content;
            function post(url, body) { return fetch(url, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', 'X-CSRF-TOKEN': token }, body: JSON.stringify(body || {}) }).then(function (r) { return r.json(); }); }
            var send = document.getElementById('cSend'), sync = document.getElementById('cSync'), msg = document.getElementById('cMsg');
            if (send) send.addEventListener('click', function () {
                send.disabled = true; send.textContent = '...'; msg.className = 'mt-2 text-xs text-slate-500'; msg.textContent = 'পাঠানো হচ্ছে...';
                post(@json(route('admin.orders.courier.send', $order)), { courier: document.getElementById('cWhich1').value })
                    .then(function (d) { if (d.ok) { location.reload(); } else { msg.className = 'mt-2 text-xs text-red-600'; msg.textContent = d.message || 'ব্যর্থ হয়েছে'; send.disabled = false; send.textContent = 'পাঠান'; } })
                    .catch(function () { msg.className = 'mt-2 text-xs text-red-600'; msg.textContent = 'নেটওয়ার্ক সমস্যা'; send.disabled = false; send.textContent = 'পাঠান'; });
            });
            if (sync) sync.addEventListener('click', function () {
                sync.disabled = true; sync.textContent = 'আনা হচ্ছে...';
                post(@json(route('admin.orders.courier.sync', $order))).then(function (d) { if (d.ok) location.reload(); else { alert(d.message || 'স্ট্যাটাস আনা যায়নি'); sync.disabled = false; sync.textContent = '🔄 কুরিয়ারের স্ট্যাটাস আপডেট'; } });
            });
        })();
        </script>
        @endif

        <section class="bg-white rounded-xl border border-slate-200 p-5 text-sm">
            <h2 class="font-semibold mb-2">পেমেন্ট</h2>
            <div>{{ \App\Support\Payments::label($order->payment_method) }} · <b class="{{ $order->payment_status === 'paid' ? 'text-green-700' : ($order->payment_status === 'failed' ? 'text-red-600' : 'text-amber-700') }}">{{ $payLabel[$order->payment_status] ?? $order->payment_status }}</b></div>
            @if ($order->payment_ref)<div class="text-xs text-slate-500">ট্রানজেকশন: {{ $order->payment_ref }}</div>@endif
            @if ($order->payment_status !== 'paid')
                <form method="POST" action="{{ route('admin.orders.paid', $order) }}" class="mt-3" onsubmit="return confirm('টাকা পাওয়া গেছে বলে চিহ্নিত করবেন?')">@csrf
                    <button class="w-full rounded-lg border border-green-600 text-green-700 hover:bg-green-50 py-1.5">টাকা পেয়েছি বলে চিহ্নিত করুন</button>
                </form>
            @endif
        </section>
    </div>
</div>
@endsection
