@extends('layouts.admin')
@section('title', 'অর্ডার')
@section('content')
@php $in = 'rounded-lg border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand'; $filtered = request()->hasAny(['q', 'status', 'pay', 'pm', 'from', 'to', 'cr', 'rk']); $canCourier = \App\Support\AdminAuth::can('courier'); $couriers = \App\Services\Courier\Courier::available(); @endphp
<div class="flex flex-wrap items-baseline justify-between gap-2 mb-4">
    <h1 class="text-2xl font-bold">অর্ডার @if (\App\Support\AdminAuth::can('order_edit'))<a href="{{ route('admin.orders.create') }}" class="ml-3 align-middle rounded-lg bg-brand hover:bg-brand-dark text-white px-4 py-2 text-sm font-medium">+ নতুন অর্ডার তৈরি</a>@endif</h1>
    <p class="text-sm text-slate-500">{{ $filtered ? 'ফলাফল' : 'মোট' }}: <b>{{ number_format($summary['count']) }}</b>টি অর্ডার · বিক্রি (বাতিল বাদে) <b>{{ config('shop.currency') }}{{ number_format($summary['total']) }}</b></p>
</div>

<form method="GET" class="bg-white rounded-xl border border-slate-200 p-4 mb-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-6">
    <input name="q" value="{{ request('q') }}" placeholder="ফোন, নাম, অর্ডার নম্বর, ঠিকানা, পণ্য..." class="{{ $in }} sm:col-span-2 lg:col-span-2" autofocus>
    <select name="status" class="{{ $in }}">
        <option value="">সব স্ট্যাটাস</option>
        @foreach (config('shop.statuses') as $k => $label)<option value="{{ $k }}" @selected(request('status') === $k)>{{ $label }}</option>@endforeach
    </select>
    <select name="pay" class="{{ $in }}">
        <option value="">পেমেন্টের অবস্থা</option>
        @foreach (['paid' => 'পরিশোধিত', 'unpaid' => 'বাকি', 'failed' => 'ব্যর্থ'] as $k => $label)<option value="{{ $k }}" @selected(request('pay') === $k)>{{ $label }}</option>@endforeach
    </select>
    <select name="rk" class="{{ $in }}">
        <option value="">ঝুঁকি: সব</option>
        <option value="high" @selected(request('rk') === 'high')>🔴 ঝুঁকিপূর্ণ</option>
        <option value="mid" @selected(request('rk') === 'mid')>🟡 সন্দেহজনক</option>
        <option value="fake" @selected(request('rk') === 'fake')>🚫 ফেক চিহ্নিত</option>
    </select>
    <select name="cr" class="{{ $in }}">
        <option value="">কুরিয়ার: সব</option>
        <option value="unsent" @selected(request('cr') === 'unsent')>কুরিয়ারে পাঠানো হয়নি</option>
        <option value="sent" @selected(request('cr') === 'sent')>কুরিয়ারে পাঠানো হয়েছে</option>
    </select>
    <select name="pm" class="{{ $in }}">
        <option value="">পেমেন্ট মাধ্যম</option>
        @foreach (\App\Support\Payments::methods() as $k => $label)<option value="{{ $k }}" @selected(request('pm') === $k)>{{ $label }}</option>@endforeach
    </select>
    <div class="flex gap-2 sm:col-span-2 lg:col-span-1"><button class="flex-1 rounded-lg bg-brand hover:bg-brand-dark text-white px-4 py-2 text-sm font-medium">খুঁজুন</button>
        @if ($filtered)<a href="{{ route('admin.orders.index') }}" class="rounded-lg border border-slate-300 hover:bg-slate-100 px-3 py-2 text-sm">মুছুন</a>@endif</div>
    <label class="text-xs text-slate-500 sm:col-span-1 lg:col-span-2 flex items-center gap-2">তারিখ <input type="date" name="from" value="{{ request('from') }}" class="{{ $in }} flex-1"> থেকে <input type="date" name="to" value="{{ request('to') }}" class="{{ $in }} flex-1"></label>
</form>

<form id="bulkForm" method="GET" action="{{ route('admin.orders.invoices') }}" target="_blank" class="flex flex-wrap items-center gap-3 mb-3 text-sm">
    <input type="hidden" name="print" value="1">
    <button class="rounded-lg border border-brand text-brand hover:bg-brand-soft px-4 py-2 font-medium" onclick="if(!document.querySelector('.sel:checked')){alert('আগে এক বা একাধিক অর্ডার বেছে নিন।');return false;}">🖨️ নির্বাচিত অর্ডারের ইনভয়েস প্রিন্ট</button>
    @if ($canCourier)<button type="button" id="openCourier" class="rounded-lg bg-brand hover:bg-brand-dark text-white px-4 py-2 font-medium">🚚 কুরিয়ারে পাঠান</button>@endif
    <span class="text-slate-500">টেবিলের বাঁ পাশের টিক দিয়ে অর্ডার বাছুন (ওপরের টিকে সব)।</span>
</form>

@if ($canCourier)
<div id="cModal" class="hidden fixed inset-0 z-[80] bg-black/50 flex items-center justify-center p-4" role="dialog" aria-modal="true">
    <div class="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl">
        <div class="flex items-center justify-between px-5 py-4 border-b border-slate-100">
            <h2 class="font-bold text-lg">🚚 কুরিয়ারে এন্ট্রি দিন</h2>
            <button type="button" id="cClose" class="h-8 w-8 rounded-full hover:bg-slate-100" aria-label="বন্ধ">✕</button>
        </div>
        <div class="px-5 py-4 overflow-y-auto space-y-4">
            @if (! $couriers)
                <p class="rounded-lg bg-amber-50 border border-amber-200 text-amber-900 text-sm px-4 py-3">এখনো কোনো কুরিয়ার সংযোগ করা নেই। @if (\App\Support\AdminAuth::can('settings'))<a href="{{ route('admin.courier.edit') }}" class="underline font-medium">কুরিয়ার সংযোগ পেজে</a> API তথ্য দিন।@else মালিককে কুরিয়ার সংযোগ করতে বলুন।@endif</p>
            @else
                <label class="block text-sm"><span class="font-medium">কোন কুরিয়ারে পাঠাবেন</span>
                    <select id="cWhich" class="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
                        @foreach ($couriers as $k => $l)<option value="{{ $k }}" @selected(\App\Services\Courier\Courier::defaultName() === $k)>{{ $l }}</option>@endforeach
                    </select></label>
                <p class="text-xs text-slate-500">বাতিল, ডেলিভারড ও আগেই পাঠানো অর্ডার বাদ যাবে। অর্ডারগুলো একটা একটা করে পাঠানো হয়, শেষ না হওয়া পর্যন্ত পেজ বন্ধ করবেন না।</p>
                <div class="rounded-lg border border-slate-200 overflow-hidden"><table class="w-full text-sm"><tbody id="cRows" class="divide-y divide-slate-100"></tbody></table></div>
                <div id="cBar" class="hidden h-2 rounded-full bg-slate-100"><div id="cBarIn" class="h-2 rounded-full bg-brand transition-all" style="width:0"></div></div>
                <p id="cSummary" class="text-sm font-medium"></p>
            @endif
        </div>
        <div class="flex justify-end gap-2 px-5 py-4 border-t border-slate-100">
            <button type="button" id="cReload" class="hidden rounded-lg border border-slate-300 hover:bg-slate-100 px-4 py-2 text-sm">পেজ রিফ্রেশ</button>
            @if ($couriers)<button type="button" id="cStart" class="rounded-lg bg-brand hover:bg-brand-dark text-white px-5 py-2 text-sm font-semibold">পাঠানো শুরু করুন</button>@endif
        </div>
    </div>
</div>
@endif
<div class="bg-white rounded-xl border border-slate-200 overflow-x-auto">@include('admin.orders.table', ['selectable' => true])</div>
<script>
(function () {
    var open = document.getElementById('openCourier'); if (!open) return;
    var modal = document.getElementById('cModal'), rowsEl = document.getElementById('cRows'), startBtn = document.getElementById('cStart'), which = document.getElementById('cWhich');
    var bar = document.getElementById('cBar'), barIn = document.getElementById('cBarIn'), summary = document.getElementById('cSummary'), reload = document.getElementById('cReload');
    var urlTpl = @json(route('admin.orders.courier.send', ['order' => '__ID__'])), token = document.querySelector('meta[name=csrf-token]').content, jobs = [], running = false;
    function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text) e.textContent = text; return e; }

    open.addEventListener('click', function () {
        if (running) return; var sel = document.querySelectorAll('.sel:checked');
        if (!sel.length) { alert('আগে এক বা একাধিক অর্ডার বেছে নিন।'); return; }
        jobs = []; rowsEl.textContent = ''; summary.textContent = ''; bar.classList.add('hidden'); reload.classList.add('hidden'); startBtn.disabled = false; startBtn.textContent = 'পাঠানো শুরু করুন';
        sel.forEach(function (c) {
            var skip = null;
            if (c.dataset.sent === '1') skip = 'আগেই পাঠানো হয়েছে';
            else if (c.dataset.status === 'cancelled') skip = 'বাতিল অর্ডার';
            else if (c.dataset.status === 'delivered') skip = 'ডেলিভারড অর্ডার';
            else if (c.dataset.fake === '1') skip = 'ফেক চিহ্নিত';
            var tr = el('tr'), a = el('td', 'p-2.5'), b = el('td', 'p-2.5 text-right text-xs whitespace-nowrap');
            a.appendChild(el('div', 'font-medium', c.dataset.no)); a.appendChild(el('div', 'text-xs text-slate-500', c.dataset.name + ' · ' + c.dataset.phone + ' · COD ৳' + Number(c.dataset.cod).toLocaleString('en-US') + (Number(c.dataset.risk) >= 60 ? ' · ⚠ ঝুঁকিপূর্ণ, আগে ফোনে কনফার্ম করুন' : '')));
            b.textContent = skip ? 'বাদ: ' + skip : 'অপেক্ষায়'; b.className += skip ? ' text-slate-400' : ' text-slate-500';
            tr.appendChild(a); tr.appendChild(b); rowsEl.appendChild(tr);
            if (!skip) jobs.push({ id: c.value, cell: b });
        });
        summary.textContent = jobs.length ? jobs.length + 'টি অর্ডার পাঠানোর জন্য তৈরি।' : 'পাঠানোর মতো কোনো অর্ডার নেই।';
        startBtn.classList.toggle('hidden', !jobs.length);
        modal.classList.remove('hidden');
    });
    document.getElementById('cClose').addEventListener('click', function () { if (!running) modal.classList.add('hidden'); });
    reload.addEventListener('click', function () { location.reload(); });

    startBtn.addEventListener('click', function () {
        if (running || !jobs.length) return; running = true; startBtn.disabled = true; startBtn.textContent = 'পাঠানো হচ্ছে...'; bar.classList.remove('hidden');
        var done = 0, okN = 0, failN = 0;
        (function next(i) {
            if (i >= jobs.length) { running = false; startBtn.textContent = 'শেষ'; reload.classList.remove('hidden'); summary.textContent = 'শেষ: ' + okN + 'টি সফল, ' + failN + 'টি ব্যর্থ।'; return; }
            var j = jobs[i]; j.cell.textContent = 'পাঠানো হচ্ছে...'; j.cell.className = 'p-2.5 text-right text-xs whitespace-nowrap text-sky-600';
            fetch(urlTpl.replace('__ID__', j.id), { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', 'X-CSRF-TOKEN': token }, body: JSON.stringify({ courier: which.value }) })
                .then(function (r) { return r.json().catch(function () { return { ok: false, message: 'সার্ভারের সাড়া বোঝা যায়নি' }; }); })
                .then(function (d) {
                    if (d.ok) { okN++; j.cell.textContent = '✔ ' + (d.tracking || 'পাঠানো হয়েছে'); j.cell.className = 'p-2.5 text-right text-xs whitespace-nowrap text-green-700 font-medium'; }
                    else { failN++; j.cell.textContent = '✗ ' + (d.message || 'ব্যর্থ'); j.cell.className = 'p-2.5 text-right text-xs text-red-600 max-w-[16rem]'; }
                }).catch(function () { failN++; j.cell.textContent = '✗ নেটওয়ার্ক সমস্যা'; j.cell.className = 'p-2.5 text-right text-xs text-red-600'; })
                .then(function () { done++; barIn.style.width = (done / jobs.length * 100) + '%'; next(i + 1); });
        })(0);
    });
})();
</script>
<script>
    var selAll = document.getElementById('selAll');
    if (selAll) selAll.addEventListener('change', function () { document.querySelectorAll('.sel').forEach(function (c) { c.checked = selAll.checked; }); });
</script>
<div class="mt-4">{{ $orders->links() }}</div>
@endsection
