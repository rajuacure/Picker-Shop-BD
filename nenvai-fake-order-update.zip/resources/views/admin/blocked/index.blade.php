@extends('layouts.admin')
@section('title', 'ব্লক করা নম্বর')
@section('content')
@php $in = 'rounded-lg border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand'; @endphp
<h1 class="text-2xl font-bold mb-2">🚫 ব্লক করা নম্বর</h1>
<p class="text-sm text-slate-500 mb-5 max-w-2xl">এই নম্বর দিয়ে সাইটে আর অর্ডার করা যায় না, গ্রাহক "WhatsApp-এ যোগাযোগ করুন" বার্তা দেখে। ভুয়া অর্ডার চিহ্নিত করার সময় নম্বর নিজে ব্লক করা যায়, এখান থেকে হাতেও যোগ করতে পারেন।</p>

<form method="POST" action="{{ route('admin.blocked.store') }}" class="flex flex-wrap gap-2 mb-6">
    @csrf
    <input name="phone" value="{{ old('phone') }}" placeholder="01XXXXXXXXX" class="{{ $in }} w-48" inputmode="tel">
    <input name="reason" value="{{ old('reason') }}" placeholder="কারণ (ঐচ্ছিক)" class="{{ $in }} flex-1 min-w-[12rem]">
    <button class="rounded-lg bg-brand hover:bg-brand-dark text-white px-5 text-sm font-medium">ব্লক করুন</button>
</form>
@error('phone')<p class="text-red-600 text-sm -mt-4 mb-4">{{ $message }}</p>@enderror

<div class="bg-white rounded-xl border border-slate-200 overflow-x-auto max-w-3xl">
<table class="w-full text-sm">
    <thead class="text-left text-slate-500 border-b border-slate-100"><tr><th class="p-3">নম্বর</th><th class="p-3">কারণ</th><th class="p-3">কে ব্লক করেছে</th><th class="p-3">তারিখ</th><th class="p-3"></th></tr></thead>
    <tbody class="divide-y divide-slate-100">
    @forelse ($rows as $r)
        <tr>
            <td class="p-3 font-mono">{{ $r->phone }}</td><td class="p-3">{{ $r->reason ?: '—' }}</td><td class="p-3 text-slate-500">{{ $r->created_by ?: '—' }}</td>
            <td class="p-3 text-slate-500 whitespace-nowrap">{{ $r->created_at->format('d M Y') }}</td>
            <td class="p-3 text-right"><form method="POST" action="{{ route('admin.blocked.destroy', $r) }}" onsubmit="return confirm('ব্লক তুলে নেবেন?')">@csrf @method('DELETE')<button class="text-red-600">তুলে নিন</button></form></td>
        </tr>
    @empty
        <tr><td colspan="5" class="p-6 text-center text-slate-500">কোনো নম্বর ব্লক করা নেই।</td></tr>
    @endforelse
    </tbody>
</table>
</div>
@endsection
