@extends('layouts.app')
@section('robots', 'noindex,follow')
@section('title', 'চেকআউট')
@php
    $cur = config('shop.currency');
    $selZone = (string) old('shipping_zone_id', optional($zone)->id);
    $zonesJson = $zones->mapWithKeys(fn ($z) => [$z->id => ['fee' => (float) $z->fee, 'free' => $z->free_over !== null ? (float) $z->free_over : null]]);
    $fbContents = $items->map(fn ($i) => ['id' => $i['product']->metaId($i['variant']), 'quantity' => (int) $i['qty'], 'item_price' => (float) $i['unit']])->values()->all();
    $fb = ['content_ids' => array_column($fbContents, 'id'), 'contents' => $fbContents, 'content_type' => 'product', 'value' => (float) $subtotal, 'currency' => 'BDT', 'num_items' => array_sum(array_column($fbContents, 'quantity'))];
    $fields = [
        ['name' => 'customer_name', 'label' => 'আপনার নাম', 'type' => 'text', 'ph' => ''],
        ['name' => 'phone', 'label' => 'মোবাইল নম্বর', 'type' => 'tel', 'ph' => '01XXXXXXXXX'],
        ['name' => 'city', 'label' => 'জেলা / শহর', 'type' => 'text', 'ph' => ''],
        ['name' => 'email', 'label' => 'ইমেইল (ঐচ্ছিক)', 'type' => 'email', 'ph' => ''],
    ];
@endphp
@push('pixel')
fbq('track', 'InitiateCheckout', {!! json_encode($fb, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) !!});
@endpush

@section('content')
<h1 class="text-2xl font-bold mb-6">চেকআউট</h1>
<form id="checkoutForm" method="POST" action="{{ route('checkout.store') }}" class="grid lg:grid-cols-3 gap-8">
    @csrf
    <div style="position:absolute;left:-9999px;top:-9999px" aria-hidden="true"><label>অন্য তথ্য<input type="text" name="nv_extra" tabindex="-1" autocomplete="off"></label></div>
    <input type="hidden" name="_ts" value="{{ now()->timestamp }}">
    <div class="lg:col-span-2 space-y-6">
        <section class="bg-white rounded-xl border border-slate-200 p-5 space-y-4">
            <h2 class="font-semibold">ডেলিভারির তথ্য</h2>
            <div class="grid sm:grid-cols-2 gap-4">
                @foreach ($fields as $f)
                <label class="block text-sm">
                    <span class="font-medium">{{ $f['label'] }}</span>
                    <input type="{{ $f['type'] }}" name="{{ $f['name'] }}" value="{{ old($f['name'], $prefill[$f['name']] ?? '') }}" placeholder="{{ $f['ph'] }}"
                           class="mt-1 w-full rounded-lg border px-3 py-2 {{ $errors->has($f['name']) ? 'border-red-400' : 'border-slate-300' }} focus:outline-none focus:ring-2 focus:ring-brand">
                    @error($f['name'])<span class="text-red-600 text-xs">{{ $message }}</span>@enderror
                </label>
                @endforeach
            </div>
            <label class="block text-sm">
                <span class="font-medium">পূর্ণ ঠিকানা</span>
                <textarea name="address" rows="2" class="mt-1 w-full rounded-lg border px-3 py-2 {{ $errors->has('address') ? 'border-red-400' : 'border-slate-300' }} focus:outline-none focus:ring-2 focus:ring-brand">{{ old('address', $prefill['address'] ?? '') }}</textarea>
                @error('address')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror
            </label>
            <label class="block text-sm">
                <span class="font-medium">নোট (ঐচ্ছিক)</span>
                <input name="note" value="{{ old('note') }}" class="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2">
            </label>
            <p class="text-xs text-slate-500">মোবাইল নম্বর দিলে কোনো কারণে অর্ডার সম্পূর্ণ না হলেও আমরা আপনার সাথে যোগাযোগ করে সাহায্য করতে পারি।</p>
        </section>

        @if ($zones->isNotEmpty())
        <section class="bg-white rounded-xl border border-slate-200 p-5">
            <h2 class="font-semibold mb-3">ডেলিভারির এলাকা</h2>
            <div class="space-y-2">
                @foreach ($zones as $z)
                @php $f = $z->feeFor((float) $subtotal); @endphp
                <label class="flex items-center gap-3 rounded-lg border border-slate-300 px-4 py-3 text-sm cursor-pointer has-[:checked]:border-brand has-[:checked]:bg-brand-soft">
                    <input type="radio" name="shipping_zone_id" value="{{ $z->id }}" class="accent-brand" @checked($selZone === (string) $z->id)>
                    <span class="font-medium flex-1">{{ $z->name }}@if ($z->free_over)<span class="block text-xs font-normal text-slate-500">{{ $cur }}{{ number_format($z->free_over) }} বা তার বেশি কিনলে ফ্রি</span>@endif</span>
                    <span class="font-semibold" data-zone-fee="{{ $z->id }}">{{ $f > 0 ? $cur.number_format($f) : 'ফ্রি' }}</span>
                </label>
                @endforeach
            </div>
            @error('shipping_zone_id')<span class="text-red-600 text-xs block mt-1">{{ $message }}</span>@enderror
        </section>
        @endif

        <section class="bg-white rounded-xl border border-slate-200 p-5">
            <fieldset class="space-y-2">
                <legend class="font-semibold mb-1">পেমেন্ট</legend>
                @foreach (\App\Support\Payments::methods() as $key => $label)
                <label class="flex items-center gap-3 rounded-lg border border-slate-300 px-4 py-3 text-sm cursor-pointer has-[:checked]:border-brand has-[:checked]:bg-brand-soft">
                    <input type="radio" name="payment_method" value="{{ $key }}" class="accent-brand" @checked(old('payment_method', 'cod') === $key)>
                    <span class="font-medium">{{ $label }}</span>
                    @if ($key === 'cod')<span class="text-slate-500">পণ্য হাতে পেয়ে টাকা দিন</span>@endif
                </label>
                @endforeach
                @error('payment_method')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror
            </fieldset>
        </section>
    </div>

    <div class="lg:col-start-3 lg:row-start-1 space-y-4">
        <div class="bg-white rounded-xl border border-slate-200 p-5">
            <h2 class="font-semibold mb-3">আপনার পণ্য</h2>
            <ul class="text-sm space-y-2">
                @foreach ($items as $i)
                <li class="flex justify-between gap-2"><span>{{ $i['name'] }} × {{ $i['qty'] }}</span><span>{{ $cur }}{{ number_format($i['line']) }}</span></li>
                @endforeach
            </ul>
        </div>
        @include('checkout.summary')
        <button class="w-full rounded-lg bg-brand hover:bg-brand-dark text-white py-3 font-semibold">অর্ডার কনফার্ম করুন</button>
    </div>
</form>

<script>
(function () {
    var form = document.getElementById('checkoutForm');
    var zones = @json($zonesJson), sub = {{ (float) $subtotal }}, cur = @json($cur);
    function fmt(n) { return cur + Math.round(n).toLocaleString('en-US'); }
    function feeOf(id) { var z = zones[id]; if (!z) return 0; return (z.free !== null && z.free > 0 && sub >= z.free) ? 0 : z.fee; }
    function updateTotals() {
        var sel = form.querySelector('input[name=shipping_zone_id]:checked');
        if (!sel) return;
        var fee = feeOf(sel.value);
        document.getElementById('sumShip').textContent = fee > 0 ? fmt(fee) : 'ফ্রি';
        document.getElementById('sumTotal').textContent = fmt(sub + fee);
    }
    form.querySelectorAll('input[name=shipping_zone_id]').forEach(function (r) { r.addEventListener('change', updateTotals); });
    updateTotals();

    // অসম্পূর্ণ অর্ডারের তথ্য রাখা
    var url = @json(route('checkout.track')), token = document.querySelector('meta[name=csrf-token]').content, timer = null, submitted = false;
    function send() {
        if (submitted) return;
        var d = {};
        ['customer_name', 'phone', 'email', 'address', 'city'].forEach(function (n) { d[n] = form.elements[n] ? form.elements[n].value : ''; });
        if (!/^(\+?88)?01[3-9]\d{8}$/.test(d.phone)) return;
        fetch(url, { method: 'POST', keepalive: true, credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': token, 'Accept': 'application/json' }, body: JSON.stringify(d) }).catch(function () {});
    }
    function queue() { clearTimeout(timer); timer = setTimeout(send, 1500); }
    ['customer_name', 'phone', 'email', 'address', 'city'].forEach(function (n) {
        var el = form.elements[n]; if (!el) return;
        el.addEventListener('input', queue); el.addEventListener('change', send);
    });
    document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'hidden') send(); });
    form.addEventListener('submit', function () { submitted = true; clearTimeout(timer); });
})();
</script>
@endsection
