<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\OrderEvent;
use App\Models\Product;
use App\Models\ProductVariant;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class OrderController extends Controller
{
    public function index(Request $request)
    {
        $q = trim((string) $request->query('q'));
        $base = Order::query()
            ->when($request->query('status'), fn ($w, $v) => $w->where('status', $v))
            ->when($request->query('pay'), fn ($w, $v) => $w->where('payment_status', $v))
            ->when($request->query('pm'), fn ($w, $v) => $w->where('payment_method', $v))
            ->when($request->query('rk') === 'high', fn ($w) => $w->where('is_fake', false)->where('risk_score', '>=', 60))
            ->when($request->query('rk') === 'mid', fn ($w) => $w->where('is_fake', false)->whereBetween('risk_score', [30, 59]))
            ->when($request->query('rk') === 'fake', fn ($w) => $w->where('is_fake', true))
            ->when($request->query('cr') === 'unsent', fn ($w) => $w->whereNull('courier_tracking_code'))
            ->when($request->query('cr') === 'sent', fn ($w) => $w->whereNotNull('courier_tracking_code'))
            ->when($request->query('from'), fn ($w, $v) => $w->whereDate('created_at', '>=', $v))
            ->when($request->query('to'), fn ($w, $v) => $w->whereDate('created_at', '<=', $v))
            ->when($q !== '', function ($w) use ($q) {
                $phone = preg_replace('/^88/', '', preg_replace('/\D/', '', $q));
                $w->where(function ($s) use ($q, $phone) {
                    $s->where('order_no', 'like', "%{$q}%")
                        ->orWhere('customer_name', 'like', "%{$q}%")
                        ->orWhere('email', 'like', "%{$q}%")
                        ->orWhere('address', 'like', "%{$q}%")
                        ->orWhereHas('items', fn ($i) => $i->where('name', 'like', "%{$q}%"));
                    if ($phone !== '') $s->orWhere('phone', 'like', "%{$phone}%");
                });
            });

        $summary = [
            'count' => (clone $base)->count(),
            'total' => (float) (clone $base)->where('status', '!=', 'cancelled')->sum('total'),
        ];
        $orders = $base->latest()->paginate(20)->withQueryString();

        return view('admin.orders.index', compact('orders', 'summary'));
    }

    public function show(Order $order)
    {
        $order->load('items', 'events');
        $history = Order::where('phone', $order->phone)->whereKeyNot($order->id)->latest()->take(8)->get();
        $stats = Order::where('phone', $order->phone)->selectRaw(
            "COUNT(*) as orders, SUM(CASE WHEN status <> 'cancelled' THEN total ELSE 0 END) as spent, "
            . "SUM(CASE WHEN status = 'delivered' THEN 1 ELSE 0 END) as delivered, SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled"
        )->first();
        return view('admin.orders.show', compact('order', 'history', 'stats'));
    }

    public function updateStatus(Request $request, Order $order)
    {
        $status = $request->validate([
            'status' => ['required', Rule::in(array_keys(config('shop.statuses')))],
        ])['status'];

        if ($status === $order->status) return back();

        $from = $order->statusLabel();
        // বাতিল করলে স্টক ফেরত যাবে (একবারই)
        if ($status === 'cancelled' && $order->status !== 'cancelled') {
            foreach ($order->items as $item) {
                if ($item->variant_id) {
                    ProductVariant::whereKey($item->variant_id)->increment('stock', $item->qty);
                    Product::find($item->product_id)?->syncFromVariants();
                } elseif ($item->product_id) {
                    Product::whereKey($item->product_id)->increment('stock', $item->qty);
                }
            }
        }
        $order->update(['status' => $status]);
        OrderEvent::log($order, 'status', "স্ট্যাটাস বদলানো হয়েছে: {$from} → " . $order->statusLabel());
        return back()->with('success', 'স্ট্যাটাস আপডেট হয়েছে।');
    }

    public function addNote(Request $request, Order $order)
    {
        $note = $request->validate(['note' => 'required|string|max:400'], ['note.required' => 'নোট লিখুন।'])['note'];
        OrderEvent::log($order, 'note', $note);
        return back()->with('success', 'নোট যোগ হয়েছে।');
    }

    public function markPaid(Order $order)
    {
        if ($order->payment_status !== 'paid') {
            $order->update(['payment_status' => 'paid']);
            OrderEvent::log($order, 'payment', 'পেমেন্ট পাওয়া গেছে বলে চিহ্নিত করা হয়েছে');
        }
        return back()->with('success', 'পেমেন্ট পরিশোধিত চিহ্নিত হয়েছে।');
    }
}
