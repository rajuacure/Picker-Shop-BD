<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\BlockedPhone;
use App\Models\Order;
use App\Models\OrderEvent;
use App\Models\Product;
use App\Models\ProductVariant;
use App\Support\AdminAuth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class FraudController extends Controller
{
    /** ফেক অর্ডার চিহ্নিত: বাতিল হয়, স্টক ফেরত আসে, চাইলে নম্বর ব্লক হয় */
    public function markFake(Request $request, Order $order)
    {
        DB::transaction(function () use ($order) {
            $order = Order::lockForUpdate()->find($order->id);
            if ($order->status !== 'cancelled') {
                $touched = [];
                foreach ($order->items as $item) {
                    if ($item->variant_id) { ProductVariant::whereKey($item->variant_id)->increment('stock', $item->qty); if ($item->product_id) $touched[$item->product_id] = true; }
                    elseif ($item->product_id) { Product::whereKey($item->product_id)->increment('stock', $item->qty); }
                }
                foreach (array_keys($touched) as $id) Product::find($id)?->syncFromVariants();
                $order->status = 'cancelled';
            }
            $order->is_fake = true;
            $order->save();
        });

        $msg = 'অর্ডারটি ফেক হিসেবে চিহ্নিত ও বাতিল করা হয়েছে, স্টক ফেরত এসেছে।';
        if ($request->boolean('block')) {
            BlockedPhone::firstOrCreate(['phone' => BlockedPhone::normalize($order->phone)], ['reason' => 'ফেক অর্ডার ' . $order->order_no, 'created_by' => AdminAuth::name()]);
            $msg .= ' নম্বরটি ব্লক করা হয়েছে।';
        }
        OrderEvent::log($order, 'fake', 'ফেক হিসেবে চিহ্নিত করা হয়েছে' . ($request->boolean('block') ? ' ও নম্বর ব্লক করা হয়েছে' : ''));
        return back()->with('success', $msg);
    }

    /** ভুল করে ফেক চিহ্নিত হলে চিহ্ন তোলা (অর্ডার বাতিলই থাকে, আপনি চাইলে স্ট্যাটাস ঠিক করবেন) */
    public function unmarkFake(Order $order)
    {
        $order->update(['is_fake' => false]);
        OrderEvent::log($order, 'fake', 'ফেক চিহ্ন তুলে নেওয়া হয়েছে (স্ট্যাটাস আলাদা ঠিক করুন)');
        return back()->with('success', 'ফেক চিহ্ন তোলা হয়েছে। অর্ডারটি বাতিলই আছে, দরকার হলে স্ট্যাটাস বদলান।');
    }

    public function blocked()
    {
        return view('admin.blocked.index', ['rows' => BlockedPhone::latest()->get()]);
    }

    public function blockStore(Request $request)
    {
        $data = $request->validate(['phone' => ['required', 'regex:/^(\+?88)?01[3-9]\d{8}$/'], 'reason' => 'nullable|string|max:200'], ['phone.regex' => 'সঠিক মোবাইল নম্বর দিন (যেমন 01712345678)।']);
        BlockedPhone::firstOrCreate(['phone' => BlockedPhone::normalize($data['phone'])], ['reason' => $data['reason'] ?? null, 'created_by' => AdminAuth::name()]);
        return back()->with('success', 'নম্বরটি ব্লক করা হয়েছে।');
    }

    public function blockDestroy(BlockedPhone $blocked)
    {
        $blocked->delete();
        return back()->with('success', 'ব্লক তুলে নেওয়া হয়েছে।');
    }
}
