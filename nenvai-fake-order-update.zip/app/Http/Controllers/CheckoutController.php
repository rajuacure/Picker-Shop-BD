<?php
namespace App\Http\Controllers;

use App\Models\AbandonedCheckout;
use App\Models\Order;
use App\Models\OrderEvent;
use App\Models\BlockedPhone;
use App\Models\Product;
use App\Models\ProductVariant;
use App\Models\ShippingZone;
use App\Support\Cart;
use App\Support\Meta;
use App\Support\Payments;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

class CheckoutController extends Controller
{
    private function zones()
    {
        try {
            return ShippingZone::where('is_active', true)->orderBy('sort_order')->orderBy('id')->get();
        } catch (\Throwable $e) {
            return collect();
        }
    }

    public function show()
    {
        $items = Cart::items();
        if ($items->isEmpty()) {
            return redirect()->route('cart.index');
        }
        $subtotal = $items->sum('line');
        $zones = $this->zones();
        $zone = $zones->first();
        $shipping = $zone ? $zone->feeFor($subtotal) : Cart::shipping($subtotal);

        $prefill = [];
        if ($user = auth()->user()) {
            $last = $user->orders()->latest()->first();
            $prefill = [
                'customer_name' => $user->name, 'phone' => $user->phone, 'email' => $user->email,
                'address' => $last->address ?? '', 'city' => $last->city ?? '',
            ];
        }
        return view('checkout.index', compact('items', 'subtotal', 'shipping', 'prefill', 'zones', 'zone'));
    }

    public function store(Request $request)
    {
        $zones = $this->zones();

        $data = $request->validate([
            'customer_name'    => 'required|string|max:100',
            'phone'            => ['required', 'regex:/^(\+?88)?01[3-9]\d{8}$/'],
            'email'            => 'nullable|email',
            'address'          => 'required|string|max:300',
            'city'             => 'required|string|max:80',
            'note'             => 'nullable|string|max:300',
            'payment_method'   => ['required', Rule::in(array_keys(Payments::methods()))],
            'shipping_zone_id' => $zones->isNotEmpty() ? ['required', Rule::in($zones->pluck('id')->all())] : 'nullable',
        ], [
            'phone.regex'                => 'সঠিক মোবাইল নম্বর দিন (যেমন 01712345678)।',
            'shipping_zone_id.required'  => 'ডেলিভারির এলাকা বেছে নিন।',
            'shipping_zone_id.in'        => 'ডেলিভারির এলাকা বেছে নিন।',
        ]);

        $zone = $zones->firstWhere('id', (int) ($data['shipping_zone_id'] ?? 0));
        unset($data['shipping_zone_id']);
        $data['phone'] = preg_replace('/^\+?88/', '', $data['phone']);

        // বট ধরা: লুকানো ঘর ভরা থাকলে বা ফর্ম অতি দ্রুত জমা হলে
        if ($request->filled('nv_extra')) {
            throw ValidationException::withMessages(['cart' => 'অর্ডার জমা হয়নি, একটু পরে আবার চেষ্টা করুন।']);
        }
        $tooFast = (int) $request->input('_ts', 0) > 0 && (time() - (int) $request->input('_ts')) < 3;
        if (BlockedPhone::isBlocked($data['phone'])) {
            throw ValidationException::withMessages(['phone' => 'এই নম্বর দিয়ে এখন অনলাইনে অর্ডার নেওয়া যাচ্ছে না। অনুগ্রহ করে আমাদের WhatsApp বা ফোনে যোগাযোগ করুন।']);
        }

        $order = DB::transaction(function () use ($data, $zone) {
            // কার্টের লাইন: [পণ্যের আইডি, সাইজের আইডি, সংখ্যা]
            $lines = [];
            foreach (Cart::raw() as $key => $qty) {
                [$pid, $vid] = Cart::parse((string) $key);
                $lines[] = [$pid, $vid, (int) $qty];
            }
            $products = Product::whereIn('id', array_unique(array_column($lines, 0)))->where('is_active', true)->lockForUpdate()->get()->keyBy('id');
            $vids = array_values(array_filter(array_unique(array_column($lines, 1))));
            $variants = $vids ? ProductVariant::whereIn('id', $vids)->lockForUpdate()->get()->keyBy('id') : collect();

            $prepared = [];
            $subtotal = 0;
            foreach ($lines as [$pid, $vid, $qty]) {
                $p = $products[$pid] ?? null;
                if (! $p) continue;
                $v = $vid ? ($variants[$vid] ?? null) : null;
                if ($vid && (! $v || (int) $v->product_id !== (int) $p->id || ! $v->is_active)) {
                    throw ValidationException::withMessages(['cart' => "\"{$p->name}\" এর বেছে নেওয়া সাইজ আর পাওয়া যাচ্ছে না। কার্ট আপডেট করুন।"]);
                }
                $name  = $p->name . ($v ? ' (' . $v->label . ')' : '');
                $stock = $v ? (int) $v->stock : (int) $p->stock;
                if ($stock < $qty) {
                    throw ValidationException::withMessages(['cart' => "\"{$name}\" এর মাত্র {$stock} টি স্টকে আছে। কার্ট আপডেট করুন।"]);
                }
                $unit = $v ? $v->currentPrice() : $p->currentPrice();
                $subtotal += $unit * $qty;
                $prepared[] = compact('p', 'v', 'name', 'unit', 'qty');
            }
            if (! $prepared) {
                throw ValidationException::withMessages(['cart' => 'আপনার কার্ট খালি।']);
            }
            $shipping = $zone ? $zone->feeFor($subtotal) : Cart::shipping($subtotal);

            $order = Order::create($data + [
                'user_id'       => auth()->id(),
                'order_no'      => 'ORD-' . now()->format('ymd') . '-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 5)),
                'shipping_zone' => $zone?->name,
                'subtotal'      => $subtotal,
                'shipping'      => $shipping,
                'total'         => $subtotal + $shipping,
            ]);

            $touched = [];
            foreach ($prepared as ['p' => $p, 'v' => $v, 'name' => $name, 'unit' => $unit, 'qty' => $qty]) {
                $order->items()->create([
                    'product_id' => $p->id,
                    'variant_id' => $v?->id,
                    'name'       => $name,
                    'price'      => $unit,
                    'cost_price' => $v ? $v->cost_price : $p->cost_price,
                    'qty'        => $qty,
                ]);
                if ($v) { $v->decrement('stock', $qty); $touched[$p->id] = $p; }
                else    { $p->decrement('stock', $qty); }
            }
            foreach ($touched as $p) $p->syncFromVariants();   // পণ্যের মোট স্টক ঠিক রাখা
            return $order;
        });

        // ঝুঁকির আন্দাজ (ব্যর্থ হলেও অর্ডার আটকাবে না)
        try {
            $ipHash = \App\Support\Risk::ipHash($request->ip());
            $risk = \App\Support\Risk::assess($order, $ipHash, $tooFast);
            $order->update(['risk_score' => $risk['score'], 'risk_flags' => mb_substr(implode('|', $risk['flags']), 0, 590), 'ip_hash' => $ipHash]);
        } catch (\Throwable $e) {
            report($e);
        }

        OrderEvent::log($order, 'created', 'অর্ডার তৈরি হয়েছে (' . Payments::label($order->payment_method) . ')', 'গ্রাহক');
        AbandonedCheckout::markRecovered($request->session()->getId(), $order->phone);
        Cart::clear();

        if ($order->isOnline()) {
            return redirect()->route('payment.start', $order->order_no);
        }
        \App\Support\Notifier::order($order, 'new');
        Meta::purchase($order);
        return redirect()->route('checkout.success', $order->order_no);
    }

    public function success(string $orderNo)
    {
        $order = Order::with('items')->where('order_no', $orderNo)->firstOrFail();

        // Pixel এর Purchase ইভেন্ট শুধু একবার ও নতুন অর্ডারেই
        $firePixel = false;
        if (Meta::pixelId() && ! $order->pixel_fired
            && ($order->payment_method === 'cod' || $order->payment_status === 'paid')
            && $order->created_at->gt(now()->subDay())) {
            $firePixel = true;
            $order->forceFill(['pixel_fired' => true])->save();
        }

        return view('checkout.success', compact('order', 'firePixel'));
    }
}
