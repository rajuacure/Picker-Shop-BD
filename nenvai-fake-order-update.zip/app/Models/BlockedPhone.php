<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BlockedPhone extends Model
{
    protected $guarded = [];

    public static function normalize(string $phone): string
    {
        return preg_replace('/^\+?88/', '', preg_replace('/[^\d+]/', '', trim($phone)));
    }

    public static function isBlocked(string $phone): bool
    {
        try {
            return static::where('phone', static::normalize($phone))->exists();
        } catch (\Throwable $e) {
            return false;   // টেবিল না থাকলে (migrate বাকি) অর্ডার আটকাবে না
        }
    }
}
