<?php
namespace App\Support;

use App\Models\BlockedPhone;
use App\Models\Order;
use App\Models\Setting;

/**
 * অর্ডার আসল না ভুয়া হওয়ার সম্ভাবনার আন্দাজ (০-১০০)। এটা শুধু সতর্কসংকেত: চূড়ান্ত সিদ্ধান্ত আপনি ফোন করে নেবেন।
 * ৩০+ = সন্দেহ, ৬০+ = ঝুঁকিপূর্ণ।
 */
class Risk
{
    public static function ipHash(?string $ip): ?string
    {
        return $ip ? hash_hmac('sha256', $ip, (string) config('app.key')) : null;
    }

    /** একই নম্বরের আগের অর্ডারের হিসাব */
    public static function history(string $phone, ?int $exceptId = null): array
    {
        $p = BlockedPhone::normalize($phone);
        $q = Order::whereIn('phone', [$p, '88' . $p, '+88' . $p])->when($exceptId, fn ($w) => $w->where('id', '!=', $exceptId));
        return [
            'total'     => (clone $q)->count(),
            'delivered' => (clone $q)->where('status', 'delivered')->count(),
            'cancelled' => (clone $q)->where('status', 'cancelled')->where('is_fake', false)->count(),
            'fake'      => (clone $q)->where('is_fake', true)->count(),
            'blocked'   => BlockedPhone::isBlocked($p),
        ];
    }

    /** @return array{score:int, flags:array<int,string>} */
    public static function assess(Order $o, ?string $ipHash = null, bool $tooFast = false): array
    {
        $score = 0;
        $flags = [];
        $add = function (int $n, string $why) use (&$score, &$flags) { $score += $n; $flags[] = $why; };

        $phone = BlockedPhone::normalize((string) $o->phone);
        $h = self::history($phone, $o->id);

        if ($h['fake'] > 0)      $add(70, 'এই নম্বরে আগে ফেক অর্ডার ছিল');
        if ($h['cancelled'] >= 2) $add(40, 'আগে ' . $h['cancelled'] . 'টি অর্ডার বাতিল হয়েছে');
        elseif ($h['cancelled'] == 1) $add(25, 'আগে ১টি অর্ডার বাতিল হয়েছে');
        if ($h['delivered'] > 0) { $score -= 30; $flags[] = 'আগে ' . $h['delivered'] . 'বার সফল ডেলিভারি ✓'; }

        // একই নম্বরে ২৪ ঘণ্টায় আরও অর্ডার
        $recent = Order::whereIn('phone', [$phone, '88' . $phone, '+88' . $phone])->where('id', '!=', $o->id)
            ->where('status', '!=', 'cancelled')->where('created_at', '>=', now()->subDay())->count();
        if ($recent >= 3) $add(50, '২৪ ঘণ্টায় একই নম্বরে ' . ($recent + 1) . 'টি অর্ডার');
        elseif ($recent >= 1) $add(30, '২৪ ঘণ্টায় একই নম্বরে আরেকটি অর্ডার');

        // একই নেটওয়ার্ক/ডিভাইস থেকে অনেক অর্ডার (ভিন্ন নম্বরে)
        if ($ipHash) {
            $ipN = Order::where('ip_hash', $ipHash)->where('id', '!=', $o->id)->where('created_at', '>=', now()->subDay())->count();
            if ($ipN >= 5) $add(60, 'একই ডিভাইস/নেটওয়ার্ক থেকে ২৪ ঘণ্টায় ' . ($ipN + 1) . 'টি অর্ডার');
            elseif ($ipN >= 2) $add(35, 'একই ডিভাইস/নেটওয়ার্ক থেকে ২৪ ঘণ্টায় ' . ($ipN + 1) . 'টি অর্ডার');
        }

        if ($tooFast) $add(50, 'ফর্ম ৩ সেকেন্ডের কমে জমা (বটের লক্ষণ)');

        // নম্বর বা নাম বানানো মনে হলে
        if (preg_match('/(\d)\1{5,}/', $phone) || preg_match('/0123456|1234567|2345678|9876543/', $phone)) $add(40, 'মোবাইল নম্বর বানানো মনে হচ্ছে');
        $name = trim((string) $o->customer_name);
        if (mb_strlen($name) < 3 || preg_match('/\d/', $name) || preg_match('/(.)\1{3,}/u', $name) || preg_match('/^[a-z]{1,2}$/i', $name)) $add(25, 'নাম অস্বাভাবিক');
        if (mb_strlen(trim((string) $o->address)) < 10) $add(20, 'ঠিকানা খুব ছোট');

        // প্রথম অর্ডারে বড় অঙ্কের ক্যাশ অন ডেলিভারি
        $limit = (int) (Setting::get('risk_high_value') ?: 3000);
        if ($h['delivered'] == 0 && $o->payment_status !== 'paid' && (float) $o->total >= $limit) $add(15, 'নতুন ক্রেতার প্রথম অর্ডারে বড় অঙ্ক (৳' . number_format($o->total) . ')');

        return ['score' => max(0, min(100, $score)), 'flags' => $flags];
    }

    public static function level(?int $score): string
    {
        $s = (int) $score;
        return $s >= 60 ? 'high' : ($s >= 30 ? 'mid' : 'low');
    }
}
