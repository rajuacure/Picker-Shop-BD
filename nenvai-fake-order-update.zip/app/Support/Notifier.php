<?php
namespace App\Support;

use App\Models\AdminNotification;
use App\Models\Order;
use App\Models\Setting;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Mail;

/** নতুন অর্ডার/পেমেন্ট/রিভিউ এলে অ্যাডমিন প্যানেলের ঘণ্টা, Telegram ও ইমেইলে জানায়। ব্যর্থ হলে মূল কাজ থামে না। */
class Notifier
{
    public static function push(string $type, string $title, ?string $body = null, ?string $url = null): void
    {
        try {
            AdminNotification::create(['type' => $type, 'title' => mb_substr($title, 0, 150), 'body' => $body ? mb_substr($body, 0, 500) : null, 'url' => $url]);
            if (random_int(1, 60) === 1) AdminNotification::where('created_at', '<', now()->subDays(30))->delete();
        } catch (\Throwable $e) {
            report($e);
        }
    }

    /** $kind: new (গ্রাহক) | manual (অ্যাডমিন নিজে) | paid (অনলাইন পেমেন্ট) */
    public static function order(Order $order, string $kind): void
    {
        try {
            $order->loadMissing('items');
            $cur = config('shop.currency');
            $items = $order->items->map(fn ($i) => $i->name . ' × ' . $i->qty)->implode(', ');
            $title = match ($kind) {
                'manual' => '📝 নতুন অর্ডার তৈরি হয়েছে (অ্যাডমিন): ' . $order->order_no,
                'paid'   => '💳 পেমেন্ট এসেছে: ' . $order->order_no,
                default  => '🛒 নতুন অর্ডার: ' . $order->order_no,
            };
            $risky = (int) ($order->risk_score ?? 0);
            if ($risky >= 60) $title = '⚠ ' . $title . ' (ঝুঁকিপূর্ণ)';
            $body = $order->customer_name . ' (' . $order->phone . ') · ' . $cur . number_format($order->total) . ' · ' . Payments::label($order->payment_method);
            $url = route('admin.orders.show', $order);

            self::push($kind === 'paid' ? 'payment' : 'order', $title, $body, $url);

            $text = $title . "\n\n"
                . 'গ্রাহক: ' . $order->customer_name . "\n" . 'ফোন: ' . $order->phone . "\n"
                . ($order->address ? 'ঠিকানা: ' . trim($order->address . ', ' . $order->city, ', ') . "\n" : '')
                . 'পণ্য: ' . $items . "\n"
                . 'মোট: ' . $cur . number_format($order->total) . ' (' . Payments::label($order->payment_method) . ')' . "\n"
                . ($order->shipping_zone ? 'ডেলিভারি: ' . $order->shipping_zone . "\n" : '')
                . ($risky >= 30 ? '⚠ ঝুঁকি ' . $risky . '/১০০: ' . str_replace('|', '; ', (string) $order->risk_flags) . "\n" : '')
                . "\n" . $url;
            self::external($title, $text);
        } catch (\Throwable $e) {
            report($e);
        }
    }

    public static function review(string $who, string $what, ?string $url = null): void
    {
        self::push('review', '⭐ নতুন রিভিউ / ফিডব্যাক', $who . ': ' . $what, $url);
        self::external('⭐ নতুন রিভিউ', "⭐ নতুন রিভিউ / ফিডব্যাক\n{$who}: {$what}" . ($url ? "\n\n" . $url : ''));
    }

    /** Telegram ও ইমেইলে পাঠায়; ফলাফল ['telegram' => bool|null, 'email' => bool|null] */
    public static function external(string $subject, string $text): array
    {
        return ['telegram' => self::telegram($text), 'email' => self::email($subject, $text)];
    }

    public static function telegram(string $text): ?bool
    {
        $token = Setting::get('telegram_bot_token');
        $chat = Setting::get('telegram_chat_id');
        if ($token === '' || $chat === '') return null;
        try {
            $res = Http::timeout(6)->asForm()->post("https://api.telegram.org/bot{$token}/sendMessage", [
                'chat_id' => $chat, 'text' => mb_substr($text, 0, 3900), 'disable_web_page_preview' => 'true',
            ]);
            if (! $res->successful()) report(new \RuntimeException('Telegram error: ' . mb_substr($res->body(), 0, 200)));
            return $res->successful();
        } catch (\Throwable $e) {
            report($e);
            return false;
        }
    }

    public static function email(string $subject, string $text): ?bool
    {
        $to = array_values(array_filter(array_map('trim', explode(',', Setting::get('notify_email')))));
        if (! $to) return null;
        try {
            Mail::raw($text, fn ($m) => $m->to($to)->subject(config('shop.name') . ' — ' . $subject));
            return true;
        } catch (\Throwable $e) {
            report($e);
            return false;
        }
    }
}
