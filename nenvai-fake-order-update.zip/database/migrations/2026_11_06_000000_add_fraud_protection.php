<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (! Schema::hasColumn('orders', 'risk_score')) {
            Schema::table('orders', function (Blueprint $t) {
                $t->unsignedSmallInteger('risk_score')->nullable();
                $t->string('risk_flags', 600)->nullable();
                $t->string('ip_hash', 64)->nullable()->index();   // আইপির এলোমেলো ছাপ, আসল আইপি রাখা হয় না
                $t->boolean('is_fake')->default(false)->index();
            });
        }

        if (! Schema::hasTable('blocked_phones')) {
            Schema::create('blocked_phones', function (Blueprint $t) {
                $t->id();
                $t->string('phone', 20)->unique();
                $t->string('reason', 200)->nullable();
                $t->string('created_by', 100)->nullable();
                $t->timestamps();
            });
        }
    }

    public function down(): void
    {
        //
    }
};
