<?php
namespace App\Http\Controllers;

use App\Models\Product;
use App\Support\Cart;
use App\Support\Meta;
use Illuminate\Http\Request;

class CartController extends Controller
{
    public function index()
    {
        $items = Cart::items();
        $subtotal = $items->sum('line');
        $shipping = null; // এলাকা অনুযায়ী চেকআউটে যোগ হবে
        return view('cart.index', compact('items', 'subtotal', 'shipping'));
    }

    /** ওপরের কার্টের ছোট তালিকার জন্য */
    public function mini()
    {
        return response()->json($this->miniData());
    }

    public function add(Request $request, Product $product)
    {
        abort_unless($product->is_active, 404);
        $json = $request->expectsJson();   // পেজ না ছেড়ে (AJAX) যোগ করলে JSON উত্তর
        $fail = fn (string $msg, bool $toProduct = false) => $json
            ? response()->json(['ok' => false, 'message' => $msg], 422)
            : ($toProduct ? redirect()->route('shop.show', $product) : back())->with('error', $msg);

        $qty = max(1, (int) $request->input('qty', 1));
        $product->load('variants');

        $variant = null;
        if ($product->hasVariants()) {
            $variant = $product->activeVariants()->firstWhere('id', (int) $request->input('variant_id'));
            if (! $variant) return $fail('আগে সাইজ বেছে নিন।', true);
        }

        $stock = $variant ? $variant->stock : $product->stock;
        if ($stock < 1) return $fail('এই পণ্যটি এখন স্টকে নেই।');

        Cart::add($product->id, $variant->id ?? 0, $qty);

        if ($json) {
            return response()->json([
                'ok' => true, 'message' => 'কার্টে যোগ হয়েছে', 'added' => Cart::key($product->id, $variant->id ?? 0),
                'mini' => $this->miniData(), 'fb' => Meta::pixelId() ? Meta::productData($product, $qty, $variant) : null,
            ]);
        }

        if (Meta::pixelId()) {
            session()->flash('fb_add_to_cart', Meta::productData($product, $qty, $variant));
        }
        // "অর্ডার করুন" বাটন সরাসরি চেকআউটে নিয়ে যায়
        return $request->boolean('buy_now')
            ? redirect()->route('checkout.show')
            : back()->with('success', 'কার্টে যোগ হয়েছে।');
    }

    public function update(Request $request, Product $product)
    {
        Cart::set($product->id, (int) $request->input('variant_id'), (int) $request->input('qty'));
        return back();
    }

    public function remove(Request $request, Product $product)
    {
        Cart::set($product->id, (int) $request->input('variant_id'), 0);
        return back();
    }

    private function miniData(): array
    {
        $items = Cart::items();
        return [
            'count'    => Cart::count(),
            'subtotal' => (float) $items->sum('line'),
            'currency' => config('shop.currency'),
            'items'    => $items->map(fn ($i) => [
                'key' => $i['key'], 'name' => $i['product']->name, 'label' => $i['label'], 'qty' => $i['qty'],
                'unit' => $i['unit'], 'line' => $i['line'], 'url' => route('shop.show', $i['product']),
                'image' => $i['product']->hasImage() ? $i['product']->thumbUrl() : null,
            ])->values()->all(),
        ];
    }
}
