<?php
namespace App\Providers;

use App\Models\Category;
use App\Models\Page;
use App\Models\Setting;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        // অ্যাডমিনের সেটিংস থাকলে সেটা .env এর মানের ওপর বসে
        $s = Setting::cached();
        if (! empty($s['shop_name']))   config(['shop.name' => $s['shop_name']]);
        if (! empty($s['brand_color'])) config(['shop.brand_color' => $s['brand_color']]);
        if (array_key_exists('logo', $s)) config(['shop.logo' => $s['logo'] ?: null]);
        if (isset($s['logo_height']) && $s['logo_height'] !== '')               config(['shop.logo_height' => (int) $s['logo_height']]);
        if (isset($s['shipping_fee']) && $s['shipping_fee'] !== '')             config(['shop.shipping_fee' => (int) $s['shipping_fee']]);
        if (isset($s['free_shipping_over']) && $s['free_shipping_over'] !== '') config(['shop.free_shipping_over' => (int) $s['free_shipping_over']]);

        // হেডারের ক্যাটাগরি মেনু ও ফুটারের পেজ
        View::composer('layouts.app', function ($view) {
            try {
                $view->with('navCategories', Category::withCount(['products as products_count' => fn ($q) => $q->where('is_active', true)])->where('is_active', true)->orderBy('sort_order')->orderBy('name')->get());
                $view->with('footerPages', Page::where('is_active', true)->where('show_in_footer', true)->orderBy('sort_order')->get(['title', 'slug']));
            } catch (\Throwable $e) {
                $view->with('navCategories', collect())->with('footerPages', collect());
            }
        });
    }
}
