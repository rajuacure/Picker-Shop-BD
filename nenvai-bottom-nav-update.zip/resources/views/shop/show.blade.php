@extends('layouts.app')
@php
    $cur = config('shop.currency');
    $url = route('shop.show', $product);
    $seoTitle = $product->seoTitle();
    $seoDesc  = $product->seoDescription();
    $variants = $product->activeVariants();
    $hasV = $variants->isNotEmpty();
    $flags = JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG;

    // কোন সাইজ আগে থেকে বাছা থাকবে: ?size= দিলে সেটা, নইলে প্রথম স্টকে থাকা সাইজ
    $selected = $hasV ? ($variants->firstWhere('id', (int) request('size')) ?? $variants->first(fn ($v) => $v->stock > 0) ?? $variants->first()) : null;

    $waBase = "আসসালামু আলাইকুম, আমি এই পণ্যটি অর্ডার করতে চাই:\n" . trim($product->name . ($hasV ? '' : ' ' . $product->weight));
    $waFor = fn ($v) => \App\Support\Contact::whatsappLink($waBase . ($v ? "\nসাইজ: " . $v->label : '') . "\n" . $url);
    $wa  = $waFor($selected);
    $tel = \App\Support\Contact::telLink();

    $vData = $variants->map(fn ($v) => [
        'id' => $v->id, 'price' => number_format($v->currentPrice()), 'old' => $v->hasOffer() ? number_format($v->price) : null,
        'off' => $v->discountPercent(), 'stock' => (int) $v->stock, 'wa' => $waFor($v),
    ])->keyBy('id');

    $shownPrice = $selected ? $selected->currentPrice() : $product->currentPrice();
    $inStock = $selected ? $selected->stock > 0 : $product->stock > 0;
    $maxQty = $selected ? $selected->stock : $product->stock;

    $offers = $hasV
        ? ['@type' => 'AggregateOffer', 'priceCurrency' => 'BDT', 'lowPrice' => number_format((float) $variants->min(fn ($v) => $v->currentPrice()), 2, '.', ''),
           'highPrice' => number_format((float) $variants->max(fn ($v) => $v->currentPrice()), 2, '.', ''), 'offerCount' => $variants->count(),
           'availability' => $product->stock > 0 ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock']
        : ['@type' => 'Offer', 'url' => $url, 'priceCurrency' => 'BDT', 'price' => number_format($product->currentPrice(), 2, '.', ''),
           'availability' => $product->stock > 0 ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock', 'itemCondition' => 'https://schema.org/NewCondition'];
    $ld = ['@context' => 'https://schema.org', '@type' => 'Product', 'name' => $product->name, 'description' => $seoDesc,
        'sku' => $product->sku ?: (string) $product->id, 'brand' => ['@type' => 'Brand', 'name' => config('shop.name')], 'offers' => $offers];
    if ($product->hasImage()) $ld['image'] = [$product->imageUrl()];
    if (! empty($ratingStats)) {
        $ld['aggregateRating'] = ['@type' => 'AggregateRating', 'ratingValue' => (string) $ratingStats['avg'], 'reviewCount' => (string) $ratingStats['count']];
        $ld['review'] = $reviews->take(5)->map(fn ($r) => array_filter([
            '@type' => 'Review', 'author' => ['@type' => 'Person', 'name' => $r->displayName()],
            'reviewRating' => ['@type' => 'Rating', 'ratingValue' => (string) $r->rating, 'bestRating' => '5'],
            'reviewBody' => $r->comment, 'datePublished' => $r->created_at->toDateString(),
        ]))->values()->all();
    }
    if ($product->category) $ld['category'] = $product->category->name;

    $crumbs = [['@type' => 'ListItem', 'position' => 1, 'name' => 'হোম', 'item' => url('/')]];
    if ($product->category) $crumbs[] = ['@type' => 'ListItem', 'position' => count($crumbs) + 1, 'name' => $product->category->name, 'item' => route('shop.category', $product->category)];
    $crumbs[] = ['@type' => 'ListItem', 'position' => count($crumbs) + 1, 'name' => $product->name, 'item' => $url];
    $bc = ['@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => $crumbs];

    $viewers = \App\Models\Setting::get('show_live_viewers') === '1' ? \App\Support\Live::viewingProduct($product->id) : 0;
@endphp
@section('title', $seoTitle)
@section('description', $seoDesc)
@section('og_type', 'product')
@if ($product->hasImage())@section('og_image', $product->imageUrl())@endif
@push('pixel')
fbq('track', 'ViewContent', {!! json_encode(\App\Support\Meta::productData($product, 1, $selected), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) !!});
@endpush
@push('jsonld')
<script type="application/ld+json">{!! json_encode($ld, $flags) !!}</script>
<script type="application/ld+json">{!! json_encode($bc, $flags) !!}</script>
@endpush

@section('content')
<nav class="text-sm text-slate-500 mb-4" aria-label="breadcrumb">
    <a href="{{ route('shop.index') }}" class="hover:text-brand">হোম</a> /
    @if ($product->category)<a href="{{ route('shop.category', $product->category) }}" class="hover:text-brand">{{ $product->category->name }}</a> /@endif
    <span>{{ $product->name }}</span>
</nav>

<div class="grid md:grid-cols-2 gap-8 items-start">
    <div class="relative">
        <img id="productMainImage" src="{{ $product->imageUrl() }}" fetchpriority="high" decoding="async" @if ($product->hasImage()) data-zoom="{{ $product->imageUrl() }}" @endif alt="{{ $product->name }}" class="w-full rounded-xl border border-slate-200 object-cover aspect-square">
        @if ($product->hasImage())<span class="pointer-events-none absolute bottom-3 right-3 rounded-full bg-black/60 text-white text-xs px-3 py-1.5">🔍 ছবিতে ট্যাপ করে বড় করুন</span>@endif
    </div>

    <div>
        <h1 class="text-2xl md:text-3xl font-bold leading-tight">{{ $product->name }}</h1>
        @if (! empty($ratingStats))<a href="#reviews" class="mt-2 inline-block">@include('shop._stars', ['avg' => $ratingStats['avg'], 'count' => $ratingStats['count'], 'size' => 'text-base'])</a>@endif
        @if (! $hasV && $product->weight)
            <span class="mt-2 inline-block rounded-full bg-brand-soft text-brand text-sm font-medium px-3 py-1">{{ $product->weight }}</span>
        @endif

        <div class="mt-4 flex flex-wrap items-baseline gap-3">
            <span id="priceNow" class="text-3xl font-bold text-brand">{{ $cur }}{{ number_format($shownPrice) }}</span>
            <span id="priceOld" class="text-lg text-slate-400 line-through {{ ($selected ? $selected->hasOffer() : $product->hasOffer()) ? '' : 'hidden' }}">{{ $cur }}{{ number_format($selected ? $selected->price : $product->price) }}</span>
            <span id="priceOff" class="rounded-full bg-red-600 text-white text-xs font-semibold px-2 py-0.5 {{ ($selected ? $selected->hasOffer() : $product->hasOffer()) ? '' : 'hidden' }}">-{{ $selected ? $selected->discountPercent() : $product->discountPercent() }}%</span>
        </div>

        @if ($viewers >= 2)<p class="mt-2 text-sm text-rose-600">👁 এই মুহূর্তে {{ $viewers }} জন এই পণ্যটি দেখছেন</p>@endif

        <form method="POST" action="{{ route('cart.add', $product) }}" class="mt-4" id="buyForm">
            @csrf
            @if ($hasV)
            <fieldset class="mb-4">
                <legend class="text-sm font-medium mb-2">সাইজ বাছুন</legend>
                <div class="flex flex-wrap gap-2">
                    @foreach ($variants as $v)
                    <label class="cursor-pointer {{ $v->stock < 1 ? 'opacity-50' : '' }}">
                        <input type="radio" name="variant_id" value="{{ $v->id }}" class="peer sr-only" data-stock="{{ $v->stock }}" @checked($selected && $selected->id === $v->id)>
                        <span class="block rounded-lg border-2 border-slate-300 px-4 py-2 text-sm font-medium peer-checked:border-brand peer-checked:bg-brand-soft peer-checked:text-brand peer-focus-visible:ring-2 peer-focus-visible:ring-brand">
                            {{ $v->label }}
                            <span class="block text-xs font-normal text-slate-500">{{ $cur }}{{ number_format($v->currentPrice()) }}@if ($v->stock < 1) · স্টক শেষ@endif</span>
                        </span>
                    </label>
                    @endforeach
                </div>
            </fieldset>
            @endif

            <p id="stockNote" class="mb-3 text-sm {{ $inStock ? ($maxQty <= 5 ? 'text-amber-700' : 'text-green-700') : 'text-slate-600' }}">
                @if ($inStock){{ $maxQty <= 5 ? 'মাত্র '.$maxQty.' টি বাকি' : 'স্টকে আছে' }}@else এই {{ $hasV ? 'সাইজ' : 'পণ্যটি' }} এখন স্টকে নেই।@endif
            </p>

            <div id="buyRow" class="flex flex-wrap items-center gap-3 {{ $inStock ? '' : 'hidden' }}">
                <input type="number" id="qtyInput" name="qty" value="1" min="1" max="{{ max($maxQty, 1) }}" aria-label="পরিমাণ" class="w-20 rounded-lg border border-slate-300 px-3 py-3">
                <button name="buy_now" value="1" class="flex-1 min-w-[11rem] rounded-lg bg-brand hover:bg-brand-dark text-white px-6 py-3 text-lg font-semibold">অর্ডার করুন</button>
                <button class="rounded-lg border border-brand text-brand hover:bg-brand-soft px-5 py-3 font-medium">কার্টে যোগ করুন</button>
            </div>
        </form>

        @if ($wa || $tel)
        <div class="mt-3 grid grid-cols-2 gap-3">
            @if ($wa)<a id="waLink" href="{{ $wa }}" target="_blank" rel="noopener" class="rounded-lg bg-[#25D366] hover:brightness-95 text-white py-2.5 text-center font-semibold">WhatsApp-এ অর্ডার</a>@endif
            @if ($tel)<a href="{{ $tel }}" class="rounded-lg border border-slate-300 hover:bg-slate-100 py-2.5 text-center font-semibold {{ $wa ? '' : 'col-span-2' }}">কল করুন</a>@endif
        </div>
        @endif
    </div>
</div>

<section class="mt-10 bg-white rounded-xl border border-slate-200 p-5 md:p-8">
    <h2 class="text-xl font-bold mb-4">পণ্যের বিবরণ</h2>
    @if ($product->description)
        <div class="leading-relaxed text-slate-700 whitespace-pre-line">{{ $product->description }}</div>
    @else
        <p class="text-slate-500">এই পণ্যের বিবরণ এখনো যোগ করা হয়নি।</p>
    @endif
    <dl class="mt-6 grid sm:grid-cols-3 gap-4 text-sm border-t border-slate-100 pt-4">
        @if ($hasV)<div><dt class="text-slate-500">পাওয়া যায়</dt><dd class="font-medium">{{ $variants->pluck('label')->implode(' · ') }}</dd></div>
        @elseif ($product->weight)<div><dt class="text-slate-500">ওজন / পরিমাণ</dt><dd class="font-medium">{{ $product->weight }}</dd></div>@endif
        @if ($product->category)<div><dt class="text-slate-500">ক্যাটাগরি</dt><dd class="font-medium"><a href="{{ route('shop.category', $product->category) }}" class="text-brand">{{ $product->category->name }}</a></dd></div>@endif
        @if ($product->sku)<div><dt class="text-slate-500">পণ্যের কোড</dt><dd class="font-medium">{{ $product->sku }}</dd></div>@endif
    </dl>
</section>

<section id="reviews" class="mt-10 bg-white rounded-xl border border-slate-200 p-5 md:p-8">
    <h2 class="text-xl font-bold mb-4">গ্রাহকের রিভিউ</h2>
    @if (! empty($ratingStats))
    <div class="grid md:grid-cols-3 gap-6">
        <div class="text-center md:border-r md:border-slate-100 md:pr-6">
            <div class="text-5xl font-bold text-brand">{{ number_format($ratingStats['avg'], 1) }}</div>
            @include('shop._stars', ['avg' => $ratingStats['avg'], 'size' => 'text-xl'])
            <div class="text-sm text-slate-500 mt-1">{{ $ratingStats['count'] }}টি রিভিউ</div>
            <div class="mt-4 space-y-1.5 text-xs text-left">
                @foreach ([5, 4, 3, 2, 1] as $n)
                    @php $c = (int) ($ratingStats['dist'][$n] ?? 0); @endphp
                    <div class="flex items-center gap-2"><span class="w-6">{{ $n }} ★</span><div class="flex-1 h-2 rounded-full bg-slate-100"><div class="h-2 rounded-full bg-amber-400" style="width: {{ $ratingStats['count'] ? $c / $ratingStats['count'] * 100 : 0 }}%"></div></div><span class="w-6 text-right text-slate-500">{{ $c }}</span></div>
                @endforeach
            </div>
        </div>
        <div class="md:col-span-2 space-y-5">
            @foreach ($reviews as $r)
            <article class="pb-5 border-b border-slate-100 last:border-0">
                <div class="flex flex-wrap items-center gap-2">
                    @include('shop._stars', ['avg' => $r->rating, 'size' => 'text-sm'])
                    <span class="font-medium text-sm">{{ $r->displayName() }}</span>
                    @if ($r->verified)<span class="rounded-full bg-green-50 text-green-700 text-[11px] px-2 py-0.5">✔ যাচাইকৃত ক্রেতা</span>@endif
                    <span class="text-xs text-slate-400 ml-auto">{{ $r->created_at->format('d M Y') }}</span>
                </div>
                @if ($r->comment)<p class="mt-2 text-sm leading-relaxed text-slate-700 whitespace-pre-line">{{ $r->comment }}</p>@endif
                @if ($r->admin_reply)<div class="mt-3 rounded-lg bg-brand-soft px-3 py-2 text-sm"><span class="font-semibold text-brand">{{ config('shop.name') }}-এর উত্তর:</span> {{ $r->admin_reply }}</div>@endif
            </article>
            @endforeach
        </div>
    </div>
    @else
        <p class="text-slate-500 text-sm">এই পণ্যের এখনো কোনো রিভিউ নেই।</p>
    @endif
    <p class="mt-5 text-xs text-slate-400">পণ্য হাতে পাওয়ার পর আমাদের পাঠানো লিংকে রিভিউ দেওয়া যায়, তাই সব রিভিউ আসল ক্রেতাদের।</p>
</section>

@if ($suggested->isNotEmpty())
<section class="mt-12">
    <h2 class="text-xl font-bold mb-4">আপনার পছন্দ হতে পারে</h2>
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
        @foreach ($suggested as $p) @include('shop._card') @endforeach
    </div>
</section>
@endif

@if ($hasV)
<script>
(function () {
    var data = @json($vData), cur = @json($cur);
    var radios = document.querySelectorAll('input[name=variant_id]');
    var priceNow = document.getElementById('priceNow'), priceOld = document.getElementById('priceOld'), priceOff = document.getElementById('priceOff');
    var stockNote = document.getElementById('stockNote'), buyRow = document.getElementById('buyRow'), qty = document.getElementById('qtyInput'), wa = document.getElementById('waLink');
    function apply(id) {
        var d = data[id]; if (!d) return;
        priceNow.textContent = cur + d.price;
        priceOld.classList.toggle('hidden', !d.old); if (d.old) priceOld.textContent = cur + d.old;
        priceOff.classList.toggle('hidden', !d.old); priceOff.textContent = '-' + d.off + '%';
        if (d.stock > 0) {
            stockNote.textContent = d.stock <= 5 ? 'মাত্র ' + d.stock + ' টি বাকি' : 'স্টকে আছে';
            stockNote.className = 'mb-3 text-sm ' + (d.stock <= 5 ? 'text-amber-700' : 'text-green-700');
            buyRow.classList.remove('hidden'); qty.max = d.stock; if (+qty.value > d.stock) qty.value = d.stock;
        } else {
            stockNote.textContent = 'এই সাইজ এখন স্টকে নেই।'; stockNote.className = 'mb-3 text-sm text-slate-600'; buyRow.classList.add('hidden');
        }
        if (wa && d.wa) wa.href = d.wa;
    }
    radios.forEach(function (r) { r.addEventListener('change', function () { apply(r.value); }); });
    var checked = document.querySelector('input[name=variant_id]:checked'); if (checked) apply(checked.value);
})();
</script>
@endif
@endsection
