@extends('layouts.admin')
@section('title', 'সেটিংস')
@section('content')
@php
    $S = \App\Models\Setting::cached();
    $val = fn ($k, $d = '') => old($k, $S[$k] ?? $d);
    $in = 'mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-brand';
    $lh = (int) old('logo_height', config('shop.logo_height', 36));
    $logo = \App\Support\Brand::logoUrl();
    $hasToken = ! empty($S['meta_capi_token']);
@endphp
<h1 class="text-2xl font-bold mb-6">সেটিংস</h1>

<form method="POST" action="{{ route('admin.settings.update') }}" enctype="multipart/form-data" class="space-y-6 max-w-2xl">
    @csrf

    <section class="bg-white rounded-xl border border-slate-200 p-5 space-y-4">
        <h2 class="font-semibold">দোকানের পরিচিতি</h2>
        <label class="block text-sm"><span class="font-medium">দোকানের নাম</span>
            <input name="shop_name" value="{{ old('shop_name', config('shop.name')) }}" class="{{ $in }}">
            @error('shop_name')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror</label>

        <div class="text-sm">
            <span class="font-medium">লোগো</span>
            @if ($logo)
                <div class="mt-2 flex items-center gap-4">
                    <img src="{{ $logo }}" alt="লোগো" class="h-12 w-auto rounded border border-slate-200 bg-white p-1">
                    <label class="flex items-center gap-2 text-slate-600"><input type="checkbox" name="remove_logo" value="1"> লোগো সরিয়ে ফেলুন</label>
                </div>
            @endif
            <input type="file" name="logo" accept="image/*" class="{{ $in }}">
            <p class="text-xs text-slate-500 mt-1">PNG, JPG, WEBP বা SVG, সর্বোচ্চ ২ MB। স্বচ্ছ ব্যাকগ্রাউন্ডের PNG ভালো দেখায়।</p>
            @error('logo')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror
        </div>

        <div class="text-sm">
            <span class="font-medium">লোগোর সাইজ (উচ্চতা)</span>
            <div class="mt-1 flex items-center gap-3">
                <span class="text-slate-500">ছোট</span>
                <input type="range" min="20" max="140" step="2" name="logo_height" id="logoRange" value="{{ $lh }}" class="w-56 accent-brand">
                <span class="text-slate-500">বড়</span>
                <span id="logoVal" class="font-mono w-14 text-right">{{ $lh }}px</span>
            </div>
            @if ($logo)
                <div class="mt-3 rounded-lg border border-slate-200 bg-white px-4 py-3 inline-flex items-center">
                    <img id="logoPrev" src="{{ $logo }}" alt="" style="height: {{ $lh }}px" class="w-auto max-w-full object-contain">
                </div>
            @endif
            @error('logo_height')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror
        </div>

        <div class="text-sm">
            <span class="font-medium">ব্র্যান্ডের রং</span>
            <div class="mt-1 flex flex-wrap items-center gap-3">
                <input type="color" id="colorPicker" value="{{ old('brand_color', config('shop.brand_color')) }}" class="h-10 w-14 rounded border border-slate-300 p-1 bg-white">
                <input name="brand_color" id="colorText" value="{{ old('brand_color', config('shop.brand_color')) }}" maxlength="7" class="w-32 rounded-lg border border-slate-300 px-3 py-2 font-mono">
                <span class="inline-block rounded-lg px-4 py-2 text-white text-sm" id="colorPreview" style="background: {{ old('brand_color', config('shop.brand_color')) }}">বাটনের নমুনা</span>
            </div>
            <p class="text-xs text-slate-500 mt-1">গাঢ় রং বেছে নিন, নইলে বাটনের সাদা লেখা পড়া কঠিন হবে।</p>
            @error('brand_color')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror
        </div>

        <label class="block text-sm"><span class="font-medium">সাইটের একদম ওপরের ঘোষণা (ঐচ্ছিক)</span>
            <input name="topbar_text" value="{{ $val('topbar_text') }}" placeholder="যেমন: সারা দেশে ক্যাশ অন ডেলিভারি" class="{{ $in }}">
            @error('topbar_text')<span class="text-red-600 text-xs block">{{ $message }}</span>@enderror</label>

        <label class="block text-sm"><span class="font-medium">সাইটের বর্ণনা (Google-এ হোম পেজের নিচে এই লেখা দেখায়)</span>
            <textarea name="site_description" rows="2" class="{{ $in }}">{{ $val('site_description') }}</textarea>
            <span class="text-xs text-slate-500">১৫০ অক্ষরের মধ্যে দোকান কী বিক্রি করে সেটা লিখুন।</span>
            @error('site_description')<span class="text-red-600 text-xs block">{{ $message }}</span>@enderror</label>

        <label class="block text-sm"><span class="font-medium">হোম পেজের ট্রাস্ট বার (ঐচ্ছিক)</span>
            <textarea name="trust_bar" rows="4" placeholder="🚚 | ক্যাশ অন ডেলিভারি | পণ্য হাতে পেয়ে টাকা দিন&#10;📞 | WhatsApp সাপোর্ট | যেকোনো প্রশ্নে সাহায্য&#10;🔄 | সহজ রিটার্ন | ত্রুটি থাকলে বদল" class="{{ $in }} font-mono text-xs">{{ $val('trust_bar') }}</textarea>
            <span class="text-xs text-slate-500">প্রতি লাইনে একটি: <b>আইকন | শিরোনাম | ছোট লেখা</b> (সর্বোচ্চ ৪টি)। শুধু যা সত্যিই দেন সেটাই লিখুন। ফাঁকা রাখলে বার দেখাবে না।</span>
            @error('trust_bar')<span class="text-red-600 text-xs block">{{ $message }}</span>@enderror</label>

        <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="show_nav_categories" value="1" @checked(($S['show_nav_categories'] ?? '1') !== '0')> ওপরে বাম পাশে ক্যাটাগরি ফিল্টার বাটন দেখান</label>
        <label class="flex items-start gap-2 text-sm"><input type="checkbox" name="show_live_viewers" value="1" class="mt-1" @checked(($S['show_live_viewers'] ?? '0') === '1')> <span>পণ্য পেজে "এই মুহূর্তে X জন দেখছেন" দেখান<span class="block text-xs text-slate-500">আসল সংখ্যা, ২ বা তার বেশি জন দেখলে তবেই দেখায়।</span></span></label>
    </section>

    <section class="bg-white rounded-xl border border-slate-200 p-5">
        <h2 class="font-semibold mb-1">ডেলিভারি চার্জ</h2>
        <p class="text-sm text-slate-600">এলাকা অনুযায়ী একাধিক ডেলিভারি চার্জ (যেমন ঢাকার ভেতরে, ঢাকার বাইরে) আলাদা পেজ থেকে ঠিক করুন।</p>
        <a href="{{ route('admin.zones.index') }}" class="inline-block mt-3 rounded-lg border border-brand text-brand hover:bg-brand-soft px-4 py-2 text-sm font-medium">🚚 ডেলিভারি এলাকা ও চার্জ</a>
    </section>

    <section class="bg-white rounded-xl border border-slate-200 p-5 space-y-4">
        <h2 class="font-semibold">ফুটার ও যোগাযোগ</h2>
        <label class="block text-sm"><span class="font-medium">দোকান সম্পর্কে ছোট লেখা</span>
            <textarea name="footer_about" rows="2" class="{{ $in }}">{{ $val('footer_about') }}</textarea>
            @error('footer_about')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror</label>
        <label class="block text-sm"><span class="font-medium">ঠিকানা</span>
            <input name="address" value="{{ $val('address') }}" class="{{ $in }}">@error('address')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror</label>
        <div class="grid sm:grid-cols-2 gap-4">
            <label class="block text-sm"><span class="font-medium">ফোন</span>
                <input name="phone" value="{{ $val('phone') }}" class="{{ $in }}">@error('phone')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror</label>
            <label class="block text-sm"><span class="font-medium">ইমেইল</span>
                <input name="email" value="{{ $val('email') }}" class="{{ $in }}">@error('email')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror</label>
            <label class="block text-sm"><span class="font-medium">WhatsApp নম্বর</span>
                <input name="whatsapp" value="{{ $val('whatsapp') }}" placeholder="01XXXXXXXXX" class="{{ $in }}">@error('whatsapp')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror</label>
            <label class="block text-sm"><span class="font-medium">খোলার সময়</span>
                <input name="hours" value="{{ $val('hours') }}" placeholder="প্রতিদিন সকাল ১০টা – রাত ৯টা" class="{{ $in }}">@error('hours')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror</label>
        </div>
    </section>

    <section class="bg-white rounded-xl border border-slate-200 p-5 space-y-4">
        <h2 class="font-semibold">সোশ্যাল মিডিয়া</h2>
        <p class="text-xs text-slate-500 -mt-2">পুরো লিংক দিন (https:// দিয়ে শুরু)। ফাঁকা রাখলে ফুটারে দেখাবে না।</p>
        @foreach (['facebook' => 'Facebook পেজ', 'instagram' => 'Instagram', 'youtube' => 'YouTube'] as $k => $label)
            <label class="block text-sm"><span class="font-medium">{{ $label }}</span>
                <input name="{{ $k }}" value="{{ $val($k) }}" placeholder="https://" class="{{ $in }}">@error($k)<span class="text-red-600 text-xs">{{ $message }}</span>@enderror</label>
        @endforeach
    </section>

    <section class="bg-white rounded-xl border border-slate-200 p-5 space-y-4">
        <div>
            <h2 class="font-semibold">🔔 অর্ডারের নোটিফিকেশন</h2>
            <p class="text-sm text-slate-500 mt-1">নতুন অর্ডার, পেমেন্ট বা রিভিউ এলে অ্যাডমিনের ঘণ্টায় শব্দসহ দেখায় (প্যানেল খোলা থাকলে)। প্যানেল বন্ধ থাকলেও ফোনে জানতে চাইলে Telegram বা ইমেইল চালু করুন।</p>
        </div>
        <label class="block text-sm"><span class="font-medium">Telegram বট টোকেন</span>
            <input type="password" name="telegram_bot_token" autocomplete="off" placeholder="{{ ! empty($S['telegram_bot_token']) ? '•••••••• (সেট করা আছে, বদলাতে চাইলে নতুন দিন)' : '123456:ABC-DEF...' }}" class="{{ $in }} font-mono">
            @if (! empty($S['telegram_bot_token']))<label class="flex items-center gap-2 text-xs text-slate-600 mt-1"><input type="checkbox" name="clear_telegram_token" value="1"> টোকেন মুছে ফেলুন</label>@endif
            @error('telegram_bot_token')<span class="text-red-600 text-xs block">{{ $message }}</span>@enderror</label>
        <label class="block text-sm"><span class="font-medium">Telegram Chat ID</span>
            <input name="telegram_chat_id" value="{{ $val('telegram_chat_id') }}" placeholder="যেমন: 123456789" class="{{ $in }} font-mono">
            @error('telegram_chat_id')<span class="text-red-600 text-xs block">{{ $message }}</span>@enderror</label>
        <details class="text-xs text-slate-600 rounded-lg bg-slate-50 border border-slate-200 p-3">
            <summary class="cursor-pointer font-medium">Telegram কীভাবে চালু করবেন (৩ মিনিট)</summary>
            <ol class="list-decimal pl-5 mt-2 space-y-1">
                <li>Telegram-এ <b>@BotFather</b> খুঁজে /newbot লিখে একটি বট বানান। যে টোকেন দেবে সেটা ওপরে বসান।</li>
                <li>নিজের বটটি খুঁজে খুলে <b>Start</b> চাপুন ও একটা মেসেজ লিখুন।</li>
                <li>Chat ID জানতে Telegram-এ <b>@userinfobot</b>-কে মেসেজ দিন, সে আপনার সংখ্যাটি (Id) বলে দেবে। সেটাই Chat ID।</li>
                <li>সেভ করে নিচের "পরীক্ষা পাঠান" চাপুন। একাধিক জনকে জানাতে গ্রুপ বানিয়ে বটকে যোগ করুন (গ্রুপের Chat ID - দিয়ে শুরু হয়)।</li>
            </ol>
        </details>
        <label class="block text-sm"><span class="font-medium">ইমেইলে জানান (ঐচ্ছিক)</span>
            <input name="notify_email" value="{{ $val('notify_email') }}" placeholder="you@example.com, অন্যজন@example.com" class="{{ $in }}">
            <span class="text-xs text-slate-500">ইমেইল পাঠাতে হলে সার্ভারে মেইল সেটিং (`.env`-এর MAIL_*) ঠিক থাকতে হবে। ঠিক না থাকলে এখানে "ব্যর্থ" দেখাবে, কিন্তু অর্ডার আটকাবে না।</span>
            @error('notify_email')<span class="text-red-600 text-xs block">{{ $message }}</span>@enderror</label>
        <button type="submit" form="testNotifyForm" class="rounded-lg border border-brand text-brand hover:bg-brand-soft px-4 py-2 text-sm font-medium">🔔 পরীক্ষা পাঠান</button>
        <span class="text-xs text-slate-500 ml-2">(আগে "সেভ করুন" চেপে নিন)</span>
    </section>

    <section class="bg-white rounded-xl border border-slate-200 p-5 space-y-4">
        <div>
            <h2 class="font-semibold">Meta (Facebook ও Instagram) বিজ্ঞাপন</h2>
            <p class="text-sm text-slate-500 mt-1">Meta Ads চালানোর জন্য যা যা লাগে সব এখানে। Pixel বসালে কে কোন পণ্য দেখল, কার্টে দিল ও কিনল সেটা Meta জানতে পারে এবং বিজ্ঞাপন আরও ভালো লক্ষ্যে যায়।</p>
        </div>

        <label class="block text-sm"><span class="font-medium">১. Pixel ID</span>
            <input name="meta_pixel_id" value="{{ $val('meta_pixel_id') }}" placeholder="যেমন: 123456789012345" inputmode="numeric" class="{{ $in }} font-mono">
            <span class="text-xs text-slate-500">Meta Events Manager → Data Sources → Pixel থেকে পাবেন। বসালে PageView, ViewContent, AddToCart, InitiateCheckout ও Purchase নিজে থেকে কাজ করবে।</span>
            @error('meta_pixel_id')<span class="text-red-600 text-xs block">{{ $message }}</span>@enderror</label>

        <label class="block text-sm"><span class="font-medium">২. ডোমেইন ভেরিফিকেশন কোড</span>
            <input name="meta_domain_verification" value="{{ $val('meta_domain_verification') }}" placeholder="meta ট্যাগের content এর কোড (পুরো ট্যাগ পেস্ট করলেও চলবে)" class="{{ $in }} font-mono">
            <span class="text-xs text-slate-500">Business Settings → Brand Safety → Domains → Meta-tag verification থেকে কোড নিন।</span>
            @error('meta_domain_verification')<span class="text-red-600 text-xs block">{{ $message }}</span>@enderror</label>

        <label class="block text-sm"><span class="font-medium">৩. Conversions API টোকেন (ঐচ্ছিক, তবে ভালো)</span>
            <input type="password" name="meta_capi_token" autocomplete="off" placeholder="{{ $hasToken ? '•••••••• (সেট করা আছে, বদলাতে চাইলে নতুন টোকেন দিন)' : 'Access token পেস্ট করুন' }}" class="{{ $in }} font-mono">
            <span class="text-xs text-slate-500">এটা দিলে কেনাকাটার তথ্য সার্ভার থেকেও Meta-কে যায়। ফোনের ব্রাউজার ট্র্যাকিং আটকালেও অর্ডার গোনা পড়ে। Events Manager → Settings → Conversions API → Generate access token।</span>
            @if ($hasToken)<label class="flex items-center gap-2 text-xs text-slate-600 mt-1"><input type="checkbox" name="clear_capi_token" value="1"> টোকেন মুছে ফেলুন</label>@endif
            @error('meta_capi_token')<span class="text-red-600 text-xs block">{{ $message }}</span>@enderror</label>

        <label class="block text-sm"><span class="font-medium">টেস্ট ইভেন্ট কোড (ঐচ্ছিক)</span>
            <input name="meta_test_code" value="{{ $val('meta_test_code') }}" placeholder="TEST12345" class="{{ $in }} font-mono">
            <span class="text-xs text-slate-500">পরীক্ষার সময় Events Manager → Test events থেকে কোড নিয়ে এখানে দিন। <b>পরীক্ষা শেষে মুছে ফেলুন।</b></span>
            @error('meta_test_code')<span class="text-red-600 text-xs block">{{ $message }}</span>@enderror</label>

        <div class="rounded-lg bg-slate-50 border border-slate-200 p-3 text-sm">
            <div class="font-medium mb-1">৪. পণ্যের ক্যাটালগ ফিড (Dynamic/Catalog বিজ্ঞাপনের জন্য)</div>
            <input readonly value="{{ route('feed.facebook') }}" onclick="this.select()" class="w-full rounded border border-slate-300 bg-white px-2 py-1.5 font-mono text-xs">
            <p class="text-xs text-slate-500 mt-1">Commerce Manager → Catalog → Data sources → Data feed → "Scheduled feed" বেছে এই লিংক দিন। শুধু ছবিসহ চালু পণ্য ফিডে যায়, দাম ও স্টক নিজে থেকে আপডেট হয়।</p>
        </div>

        <div class="rounded-lg bg-amber-50 border border-amber-200 p-3 text-xs text-amber-900 space-y-1">
            <div class="font-medium">বিজ্ঞাপন অনুমোদনের জন্য মনে রাখুন</div>
            <div>• সাইটে ঠিকানা, ফোন ও পলিসি পেজ (ডেলিভারি, রিটার্ন, গোপনীয়তা) থাকতে হবে। এগুলো আছে, তবে লেখা নিজের নিয়ম অনুযায়ী বদলে নিন।</div>
            <div>• গোপনীয়তা নীতিতে লিখুন যে সাইটে Meta Pixel ও কুকি ব্যবহার হয়।</div>
            <div>• মধু, হার্বাল ও স্বাস্থ্যজাত পণ্যে "রোগ সারায়" ধরনের দাবি বা আগে-পরে তুলনা Meta-র নিয়মে নিষিদ্ধ। বিজ্ঞাপনের লেখায় সাবধান থাকুন।</div>
        </div>
    </section>

    <button class="rounded-lg bg-brand hover:bg-brand-dark text-white px-6 py-2.5 font-semibold">সেভ করুন</button>
</form>
<form id="testNotifyForm" method="POST" action="{{ route('admin.settings.test-notify') }}">@csrf</form>

<script>
    (function () {
        var r = document.getElementById('logoRange'), val = document.getElementById('logoVal'), img = document.getElementById('logoPrev');
        r.addEventListener('input', function () { val.textContent = r.value + 'px'; if (img) img.style.height = r.value + 'px'; });
        var p = document.getElementById('colorPicker'), t = document.getElementById('colorText'), v = document.getElementById('colorPreview');
        p.addEventListener('input', function () { t.value = p.value; v.style.background = p.value; });
        t.addEventListener('input', function () { if (/^#[0-9a-fA-F]{6}$/.test(t.value)) { p.value = t.value; v.style.background = t.value; } });
    })();
</script>
@endsection
