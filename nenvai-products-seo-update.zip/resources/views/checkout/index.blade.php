@extends('layouts.app')
@section('robots', 'noindex,follow')
@section('title', 'চেকআউট')
@section('content')
<h1 class="text-2xl font-bold mb-6">চেকআউট</h1>
<form method="POST" action="{{ route('checkout.store') }}" class="grid lg:grid-cols-3 gap-8">
    @csrf
    <div class="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-5 space-y-4">
        <h2 class="font-semibold">ডেলিভারির তথ্য</h2>
        @php
            $field = fn ($name, $label, $type = 'text', $ph = '') => compact('name', 'label', 'type', 'ph');
            $fields = [
                $field('customer_name', 'আপনার নাম'),
                $field('phone', 'মোবাইল নম্বর', 'tel', '01XXXXXXXXX'),
                $field('city', 'জেলা / শহর'),
                $field('email', 'ইমেইল (ঐচ্ছিক)', 'email'),
            ];
        @endphp
        <div class="grid sm:grid-cols-2 gap-4">
            @foreach ($fields as $f)
            <label class="block text-sm">
                <span class="font-medium">{{ $f['label'] }}</span>
                <input type="{{ $f['type'] }}" name="{{ $f['name'] }}" value="{{ old($f['name'], $prefill[$f['name']] ?? '') }}" placeholder="{{ $f['ph'] }}"
                       class="mt-1 w-full rounded-lg border px-3 py-2 {{ $errors->has($f['name']) ? 'border-red-400' : 'border-slate-300' }} focus:outline-none focus:ring-2 focus:ring-brand">
                @error($f['name'])<span class="text-red-600 text-xs">{{ $message }}</span>@enderror
            </label>
            @endforeach
        </div>
        <label class="block text-sm">
            <span class="font-medium">পূর্ণ ঠিকানা</span>
            <textarea name="address" rows="2" class="mt-1 w-full rounded-lg border px-3 py-2 {{ $errors->has('address') ? 'border-red-400' : 'border-slate-300' }} focus:outline-none focus:ring-2 focus:ring-brand">{{ old('address', $prefill['address'] ?? '') }}</textarea>
            @error('address')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror
        </label>
        <label class="block text-sm">
            <span class="font-medium">নোট (ঐচ্ছিক)</span>
            <input name="note" value="{{ old('note') }}" class="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2">
        </label>
        <fieldset class="space-y-2">
            <legend class="font-semibold mb-1">পেমেন্ট</legend>
            @foreach (\App\Support\Payments::methods() as $key => $label)
            <label class="flex items-center gap-3 rounded-lg border border-slate-300 px-4 py-3 text-sm cursor-pointer has-[:checked]:border-brand has-[:checked]:bg-brand-soft">
                <input type="radio" name="payment_method" value="{{ $key }}" class="accent-brand" @checked(old('payment_method', 'cod') === $key)>
                <span class="font-medium">{{ $label }}</span>
                @if ($key === 'cod')<span class="text-slate-500">পণ্য হাতে পেয়ে টাকা দিন</span>@endif
            </label>
            @endforeach
            @error('payment_method')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror
        </fieldset>
    </div>
    <div class="lg:col-start-3 lg:row-start-1 space-y-4">
        <div class="bg-white rounded-xl border border-slate-200 p-5">
            <h2 class="font-semibold mb-3">আপনার পণ্য</h2>
            <ul class="text-sm space-y-2">
                @foreach ($items as $i)
                <li class="flex justify-between gap-2"><span>{{ $i['product']->name }} × {{ $i['qty'] }}</span><span>{{ config('shop.currency') }}{{ number_format($i['line']) }}</span></li>
                @endforeach
            </ul>
        </div>
        @include('checkout.summary')
        <button class="w-full rounded-lg bg-brand hover:bg-brand-dark text-white py-3 font-semibold">অর্ডার কনফার্ম করুন</button>
    </div>
</form>
@endsection
