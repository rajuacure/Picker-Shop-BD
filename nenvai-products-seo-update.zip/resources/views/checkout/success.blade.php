@extends('layouts.app')
@section('robots', 'noindex,follow')
@section('title', 'অর্ডার সম্পন্ন')
@section('content')
<div class="max-w-xl mx-auto bg-white rounded-xl border border-slate-200 p-8 text-center">
    @if ($order->needsPayment())
        <h1 class="text-2xl font-bold text-amber-700">পেমেন্ট বাকি আছে</h1>
        <p class="mt-1 text-sm text-slate-500">অর্ডারটি তৈরি হয়েছে, পেমেন্ট সম্পন্ন করলেই কনফার্ম হবে।</p>
        <a href="{{ route('payment.start', $order->order_no) }}" class="inline-block mt-4 rounded-lg bg-brand hover:bg-brand-dark text-white px-6 py-2.5 font-semibold">{{ \App\Support\Payments::label($order->payment_method) }} দিয়ে পেমেন্ট করুন</a>
    @else
        <h1 class="text-2xl font-bold text-brand">অর্ডার সম্পন্ন হয়েছে</h1>
    @endif
    <p class="mt-2 text-slate-600">অর্ডার নম্বর: <strong>{{ $order->order_no }}</strong></p>
    <p class="mt-1 text-sm text-slate-500">{{ $order->needsPayment() ? '' : 'আমরা '.$order->phone.' নম্বরে যোগাযোগ করে কনফার্ম করব।' }}</p>
    <ul class="mt-6 text-sm text-left divide-y divide-slate-100">
        @foreach ($order->items as $it)
        <li class="py-2 flex justify-between"><span>{{ $it->name }} × {{ $it->qty }}</span><span>{{ config('shop.currency') }}{{ number_format($it->price * $it->qty) }}</span></li>
        @endforeach
        <li class="py-2 flex justify-between"><span>ডেলিভারি চার্জ</span><span>{{ $order->shipping > 0 ? config('shop.currency').number_format($order->shipping) : 'ফ্রি' }}</span></li>
        <li class="py-2 flex justify-between font-semibold"><span>মোট {{ $order->payment_status === 'paid' ? '(পরিশোধিত)' : ($order->isOnline() ? '' : '(ডেলিভারিতে দিন)') }}</span><span>{{ config('shop.currency') }}{{ number_format($order->total) }}</span></li>
    </ul>
    <a href="{{ route('shop.index') }}" class="inline-block mt-6 text-brand underline">আরো কেনাকাটা করুন</a>
</div>
@endsection
