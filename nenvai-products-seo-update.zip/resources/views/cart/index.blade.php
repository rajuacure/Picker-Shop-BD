@extends('layouts.app')
@section('robots', 'noindex,follow')
@section('title', 'কার্ট')
@section('content')
<h1 class="text-2xl font-bold mb-6">আপনার কার্ট</h1>
@if ($items->isEmpty())
    <p class="text-slate-500">কার্ট খালি। <a href="{{ route('shop.index') }}" class="text-brand underline">কেনাকাটা শুরু করুন</a></p>
@else
<div class="grid lg:grid-cols-3 gap-8">
    <div class="lg:col-span-2 bg-white rounded-xl border border-slate-200 divide-y divide-slate-100">
        @foreach ($items as $i)
        <div class="p-4 flex gap-4 items-center">
            <img src="{{ $i['product']->imageUrl() }}" class="w-16 h-16 rounded-lg object-cover" alt="">
            <div class="flex-1 min-w-0">
                <div class="font-medium truncate">{{ $i['product']->name }}</div>
                <div class="text-sm text-slate-500">{{ config('shop.currency') }}{{ number_format($i['product']->currentPrice()) }}</div>
            </div>
            <form method="POST" action="{{ route('cart.update', $i['product']) }}">
                @csrf @method('PATCH')
                <input type="number" name="qty" value="{{ $i['qty'] }}" min="0" max="{{ $i['product']->stock }}"
                       onchange="this.form.submit()" class="w-16 rounded-lg border border-slate-300 px-2 py-1">
            </form>
            <div class="w-20 text-right font-medium">{{ config('shop.currency') }}{{ number_format($i['line']) }}</div>
            <form method="POST" action="{{ route('cart.remove', $i['product']) }}">
                @csrf @method('DELETE')
                <button class="text-sm text-red-600 hover:underline">মুছুন</button>
            </form>
        </div>
        @endforeach
    </div>
    @include('checkout.summary')
    <div class="lg:col-start-3">
        <a href="{{ route('checkout.show') }}" class="block text-center rounded-lg bg-brand hover:bg-brand-dark text-white py-3 font-semibold">চেকআউটে যান</a>
    </div>
</div>
@endif
@endsection
