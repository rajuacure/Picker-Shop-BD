@extends('layouts.base')
@section('robots', 'noindex,nofollow')
@section('body')
<div class="min-h-screen md:flex">
    <aside class="md:w-56 bg-slate-900 text-slate-200 md:min-h-screen p-4 flex md:block gap-2 items-center overflow-x-auto">
        <div class="font-bold text-white md:mb-6 mr-4 md:mr-0">{{ config('shop.name') }}</div>
        @php $nav = ['admin.dashboard' => 'ড্যাশবোর্ড', 'admin.orders.index' => 'অর্ডার', 'admin.products.index' => 'পণ্য', 'admin.categories.index' => 'ক্যাটাগরি', 'admin.import.form' => 'CSV ইমপোর্ট', 'admin.sliders.index' => 'স্লাইডার', 'admin.pages.index' => 'পেজ ও পলিসি', 'admin.settings.edit' => 'সেটিংস']; @endphp
        @foreach ($nav as $route => $label)
            <a href="{{ route($route) }}"
               class="block px-3 py-2 rounded-lg text-sm whitespace-nowrap {{ request()->routeIs(str_replace('.index', '.*', $route)) ? 'bg-brand text-white' : 'hover:bg-slate-800' }}">{{ $label }}</a>
        @endforeach
        <a href="{{ route('shop.index') }}" target="_blank" class="block px-3 py-2 text-sm text-slate-400 hover:text-white whitespace-nowrap md:mt-6">দোকান দেখুন</a>
        <form method="POST" action="{{ route('admin.logout') }}">@csrf
            <button class="px-3 py-2 text-sm text-slate-400 hover:text-white">লগআউট</button>
        </form>
    </aside>
    <main class="flex-1 p-4 md:p-8 min-w-0">
        @include('layouts.flash')
        @yield('content')
    </main>
</div>
@endsection
