@extends('layouts.base')
@section('body')
@php
    $S = \App\Models\Setting::cached();
    $digits = preg_replace('/\D/', '', $S['whatsapp'] ?? '');
@endphp

@if (! empty($S['topbar_text']))
    <div class="bg-brand text-white text-xs md:text-sm text-center py-2 px-4">{{ $S['topbar_text'] }}</div>
@endif

<header class="bg-white border-b border-slate-200 sticky top-0 z-20">
    <div class="max-w-7xl mx-auto px-4 py-2 flex items-center gap-3 md:gap-6" style="min-height: 4rem">
        <a href="{{ route('shop.index') }}" class="text-xl font-bold text-brand flex items-center shrink-0">@include('layouts.logo')</a>

        <form action="{{ route('shop.products') }}" class="hidden md:flex flex-1 max-w-2xl">
            <input name="q" value="{{ request('q') }}" placeholder="পণ্য খুঁজুন" class="w-full rounded-l-lg border border-slate-300 px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand">
            <button class="rounded-r-lg bg-brand hover:bg-brand-dark text-white px-5 text-sm font-medium">খুঁজুন</button>
        </form>

        <nav class="ml-auto flex items-center gap-3 md:gap-5 text-sm font-medium">
            @auth
                <a href="{{ route('account') }}" class="hover:text-brand whitespace-nowrap">আমার অ্যাকাউন্ট</a>
            @else
                <a href="{{ route('login') }}" class="hover:text-brand">লগইন</a>
                <a href="{{ route('register') }}" class="hidden sm:inline rounded-lg border border-brand text-brand hover:bg-brand-soft px-3 py-1.5">রেজিস্টার</a>
            @endauth
            <a href="{{ route('cart.index') }}" class="relative inline-flex items-center gap-1 rounded-lg bg-brand hover:bg-brand-dark text-white px-3 py-1.5 whitespace-nowrap">
                কার্ট <span class="rounded-full bg-white/25 px-1.5 text-xs">{{ \App\Support\Cart::count() }}</span>
            </a>
        </nav>
    </div>

    <form action="{{ route('shop.products') }}" class="md:hidden px-4 pb-2 flex">
        <input name="q" value="{{ request('q') }}" placeholder="পণ্য খুঁজুন" class="w-full rounded-l-lg border border-slate-300 px-3 py-2 text-sm">
        <button class="rounded-r-lg bg-brand text-white px-4 text-sm">খুঁজুন</button>
    </form>

    @if (($S['show_nav_categories'] ?? '1') !== '0')
    <div class="border-t border-slate-100 bg-white">
        <nav class="max-w-7xl mx-auto px-4 flex gap-1 overflow-x-auto text-sm whitespace-nowrap">
            <a href="{{ route('shop.products') }}" class="px-3 py-2.5 hover:text-brand {{ request()->routeIs('shop.products') ? 'text-brand font-semibold' : '' }}">সব পণ্য</a>
            @foreach (($navCategories ?? []) as $c)
                <a href="{{ route('shop.category', $c) }}" class="px-3 py-2.5 hover:text-brand {{ request()->routeIs('shop.category') && optional(request()->route('category'))->id === $c->id ? 'text-brand font-semibold' : '' }}">{{ $c->name }}</a>
            @endforeach
        </nav>
    </div>
    @endif
</header>

<main class="max-w-7xl mx-auto px-4 py-6 md:py-8 min-h-[60vh]">
    @include('layouts.flash')
    @yield('content')
</main>

<footer class="bg-slate-900 text-slate-300 mt-12">
    <div class="max-w-7xl mx-auto px-4 py-10 grid gap-8 sm:grid-cols-2 lg:grid-cols-4 text-sm">
        <div>
            <div class="text-white text-lg font-bold mb-3">{{ config('shop.name') }}</div>
            @if (! empty($S['footer_about']))<p class="leading-relaxed text-slate-400">{{ $S['footer_about'] }}</p>@endif
            <div class="flex flex-wrap gap-2 mt-4">
                @foreach (['facebook' => 'Facebook', 'instagram' => 'Instagram', 'youtube' => 'YouTube'] as $k => $label)
                    @if (! empty($S[$k]))<a href="{{ $S[$k] }}" target="_blank" rel="noopener" class="rounded-full border border-slate-600 hover:border-white hover:text-white px-3 py-1 text-xs">{{ $label }}</a>@endif
                @endforeach
            </div>
        </div>

        <div>
            <div class="text-white font-semibold mb-3">দ্রুত লিংক</div>
            <ul class="space-y-2">
                <li><a href="{{ route('shop.products') }}" class="hover:text-white">সব পণ্য</a></li>
                @foreach (collect($navCategories ?? [])->take(5) as $c)
                    <li><a href="{{ route('shop.category', $c) }}" class="hover:text-white">{{ $c->name }}</a></li>
                @endforeach
                <li><a href="{{ auth()->check() ? route('account') : route('login') }}" class="hover:text-white">আমার অ্যাকাউন্ট</a></li>
                <li><a href="{{ route('cart.index') }}" class="hover:text-white">কার্ট</a></li>
            </ul>
        </div>

        <div>
            <div class="text-white font-semibold mb-3">তথ্য ও নীতিমালা</div>
            <ul class="space-y-2">
                @forelse (($footerPages ?? []) as $p)
                    <li><a href="{{ route('page.show', $p->slug) }}" class="hover:text-white">{{ $p->title }}</a></li>
                @empty
                    <li class="text-slate-500">—</li>
                @endforelse
            </ul>
        </div>

        <div>
            <div class="text-white font-semibold mb-3">যোগাযোগ</div>
            <ul class="space-y-2 text-slate-400">
                @if (! empty($S['address']))<li>{{ $S['address'] }}</li>@endif
                @if (! empty($S['phone']))<li><a href="tel:{{ preg_replace('/[^\d+]/', '', $S['phone']) }}" class="hover:text-white">{{ $S['phone'] }}</a></li>@endif
                @if (! empty($S['email']))<li><a href="mailto:{{ $S['email'] }}" class="hover:text-white">{{ $S['email'] }}</a></li>@endif
                @if ($digits)<li><a href="https://wa.me/{{ $digits }}" target="_blank" rel="noopener" class="hover:text-white">WhatsApp এ মেসেজ করুন</a></li>@endif
                @if (! empty($S['hours']))<li>{{ $S['hours'] }}</li>@endif
            </ul>
        </div>
    </div>

    <div class="border-t border-slate-800">
        <div class="max-w-7xl mx-auto px-4 py-4 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-500">
            <span>© {{ date('Y') }} {{ config('shop.name') }}। সর্বস্বত্ব সংরক্ষিত।</span>
            <span class="flex flex-wrap gap-2">
                @foreach (\App\Support\Payments::methods() as $label)
                    <span class="rounded border border-slate-700 px-2 py-0.5 text-slate-400">{{ $label }}</span>
                @endforeach
            </span>
        </div>
    </div>
</footer>

@if ($waLink = \App\Support\Contact::whatsappLink('আসসালামু আলাইকুম, আমি ' . config('shop.name') . ' থেকে কিছু জানতে চাই।'))
<a href="{{ $waLink }}" target="_blank" rel="noopener" aria-label="WhatsApp-এ মেসেজ করুন"
   class="fixed bottom-5 right-5 z-30 inline-flex items-center gap-2 rounded-full bg-[#25D366] text-white px-4 py-3 shadow-lg font-semibold text-sm hover:brightness-95">
    <svg viewBox="0 0 24 24" class="h-5 w-5" fill="currentColor" aria-hidden="true"><path d="M20 2H4a2 2 0 0 0-2 2v18l4-4h14a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2z"/></svg>
    WhatsApp
</a>
@endif
@endsection
