<!doctype html>
<html lang="bn">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    @php
        $__title = trim($__env->yieldContent('title'));
        $__full  = $__title !== '' ? $__title . ' | ' . config('shop.name') : config('shop.name');
        $__desc  = trim($__env->yieldContent('description')) ?: \App\Models\Setting::get('site_description');
        $__img   = trim($__env->yieldContent('og_image')) ?: \App\Support\Brand::logoUrl();
    @endphp
    <title>{{ $__full }}</title>
    @if ($__desc !== '')<meta name="description" content="{{ $__desc }}">@endif
    @hasSection('robots')<meta name="robots" content="@yield('robots')">@endif
    <link rel="canonical" href="{{ url()->current() }}">
    <meta property="og:site_name" content="{{ config('shop.name') }}">
    <meta property="og:locale" content="bn_BD">
    <meta property="og:type" content="@yield('og_type', 'website')">
    <meta property="og:title" content="{{ $__title !== '' ? $__title : config('shop.name') }}">
    @if ($__desc !== '')<meta property="og:description" content="{{ $__desc }}">@endif
    <meta property="og:url" content="{{ url()->current() }}">
    @if ($__img)<meta property="og:image" content="{{ $__img }}">@endif
    <meta name="twitter:card" content="{{ $__img ? 'summary_large_image' : 'summary' }}">
    @if ($logo = \App\Support\Brand::logoUrl())<link rel="icon" href="{{ $logo }}">@endif
    @stack('jsonld')
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = { theme: { extend: {
            fontFamily: { sans: ['"Hind Siliguri"', 'system-ui', 'sans-serif'] },
            colors: { brand: @json(\App\Support\Brand::palette()) }
        } } }
    </script>
</head>
<body class="bg-slate-50 text-slate-800 font-sans antialiased">
    @yield('body')
</body>
</html>
