@extends('layouts.app')
@section('robots', 'noindex,follow')
@section('title', 'লগইন')
@section('content')
@php $in = 'mt-1 w-full rounded-lg border px-3 py-2 focus:outline-none focus:ring-2 focus:ring-brand'; @endphp
<div class="max-w-md mx-auto bg-white rounded-xl border border-slate-200 p-6 md:p-8">
    <h1 class="text-2xl font-bold mb-1">লগইন</h1>
    <p class="text-sm text-slate-500 mb-5">আপনার অর্ডার দেখতে ও দ্রুত কিনতে লগইন করুন।</p>
    <form method="POST" action="{{ route('login') }}" class="space-y-4">
        @csrf
        <label class="block text-sm"><span class="font-medium">মোবাইল নম্বর</span>
            <input type="tel" name="phone" value="{{ old('phone') }}" placeholder="01XXXXXXXXX" autofocus class="{{ $in }} {{ $errors->has('phone') ? 'border-red-400' : 'border-slate-300' }}">
            @error('phone')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror</label>
        <label class="block text-sm"><span class="font-medium">পাসওয়ার্ড</span>
            <input type="password" name="password" class="{{ $in }} border-slate-300">
            @error('password')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror</label>
        <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="remember" value="1"> আমাকে মনে রাখুন</label>
        <button class="w-full rounded-lg bg-brand hover:bg-brand-dark text-white py-2.5 font-semibold">লগইন করুন</button>
    </form>
    <p class="text-sm text-slate-500 mt-5 text-center">নতুন কাস্টমার? <a href="{{ route('register') }}" class="text-brand font-medium">অ্যাকাউন্ট খুলুন</a></p>
</div>
@endsection
