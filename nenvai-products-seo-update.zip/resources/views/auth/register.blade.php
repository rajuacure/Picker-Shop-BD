@extends('layouts.app')
@section('robots', 'noindex,follow')
@section('title', 'রেজিস্টার')
@section('content')
@php $in = 'mt-1 w-full rounded-lg border px-3 py-2 focus:outline-none focus:ring-2 focus:ring-brand'; @endphp
<div class="max-w-md mx-auto bg-white rounded-xl border border-slate-200 p-6 md:p-8">
    <h1 class="text-2xl font-bold mb-1">অ্যাকাউন্ট খুলুন</h1>
    <p class="text-sm text-slate-500 mb-5">অ্যাকাউন্ট না থাকলেও আপনি কিনতে পারবেন, তবে অ্যাকাউন্ট থাকলে অর্ডারের হিসাব দেখা যায়।</p>
    <form method="POST" action="{{ route('register') }}" class="space-y-4">
        @csrf
        <label class="block text-sm"><span class="font-medium">আপনার নাম</span>
            <input name="name" value="{{ old('name') }}" class="{{ $in }} {{ $errors->has('name') ? 'border-red-400' : 'border-slate-300' }}">
            @error('name')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror</label>
        <label class="block text-sm"><span class="font-medium">মোবাইল নম্বর</span>
            <input type="tel" name="phone" value="{{ old('phone') }}" placeholder="01XXXXXXXXX" class="{{ $in }} {{ $errors->has('phone') ? 'border-red-400' : 'border-slate-300' }}">
            @error('phone')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror</label>
        <label class="block text-sm"><span class="font-medium">ইমেইল (ঐচ্ছিক)</span>
            <input type="email" name="email" value="{{ old('email') }}" class="{{ $in }} {{ $errors->has('email') ? 'border-red-400' : 'border-slate-300' }}">
            @error('email')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror</label>
        <div class="grid grid-cols-2 gap-3">
            <label class="block text-sm"><span class="font-medium">পাসওয়ার্ড</span>
                <input type="password" name="password" class="{{ $in }} {{ $errors->has('password') ? 'border-red-400' : 'border-slate-300' }}"></label>
            <label class="block text-sm"><span class="font-medium">আবার লিখুন</span>
                <input type="password" name="password_confirmation" class="{{ $in }} border-slate-300"></label>
        </div>
        @error('password')<span class="text-red-600 text-xs block -mt-2">{{ $message }}</span>@enderror
        <button class="w-full rounded-lg bg-brand hover:bg-brand-dark text-white py-2.5 font-semibold">অ্যাকাউন্ট খুলুন</button>
    </form>
    <p class="text-sm text-slate-500 mt-5 text-center">আগেই অ্যাকাউন্ট আছে? <a href="{{ route('login') }}" class="text-brand font-medium">লগইন করুন</a></p>
</div>
@endsection
