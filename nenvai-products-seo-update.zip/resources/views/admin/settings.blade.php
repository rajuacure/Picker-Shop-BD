@extends('layouts.admin')
@section('title', 'সেটিংস')
@section('content')
@php
    $S = \App\Models\Setting::cached();
    $val = fn ($k, $d = '') => old($k, $S[$k] ?? $d);
    $in = 'mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-brand';
    $lh = (int) old('logo_height', config('shop.logo_height', 36));
    $logo = \App\Support\Brand::logoUrl();
@endphp
<h1 class="text-2xl font-bold mb-6">সেটিংস</h1>

<form method="POST" action="{{ route('admin.settings.update') }}" enctype="multipart/form-data" class="space-y-6 max-w-2xl">
    @csrf

    <section class="bg-white rounded-xl border border-slate-200 p-5 space-y-4">
        <h2 class="font-semibold">দোকানের পরিচিতি</h2>

        <label class="block text-sm"><span class="font-medium">দোকানের নাম</span>
            <input name="shop_name" value="{{ old('shop_name', config('shop.name')) }}" class="{{ $in }}">
            @error('shop_name')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror
        </label>

        <div class="text-sm">
            <span class="font-medium">লোগো</span>
            @if ($logo)
                <div class="mt-2 flex items-center gap-4">
                    <img src="{{ $logo }}" alt="লোগো" class="h-12 w-auto rounded border border-slate-200 bg-white p-1">
                    <label class="flex items-center gap-2 text-slate-600"><input type="checkbox" name="remove_logo" value="1"> লোগো সরিয়ে ফেলুন</label>
                </div>
            @endif
            <input type="file" name="logo" accept="image/*" class="{{ $in }}">
            <p class="text-xs text-slate-500 mt-1">PNG, JPG, WEBP বা SVG, সর্বোচ্চ ২ MB। স্বচ্ছ ব্যাকগ্রাউন্ডের PNG ভালো দেখায়।</p>
            @error('logo')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror
        </div>

        <div class="text-sm">
            <span class="font-medium">লোগোর সাইজ (উচ্চতা)</span>
            <div class="mt-1 flex items-center gap-3">
                <span class="text-slate-500">ছোট</span>
                <input type="range" min="20" max="140" step="2" name="logo_height" id="logoRange" value="{{ $lh }}" class="w-56 accent-brand">
                <span class="text-slate-500">বড়</span>
                <span id="logoVal" class="font-mono w-14 text-right">{{ $lh }}px</span>
            </div>
            @if ($logo)
                <div class="mt-3 rounded-lg border border-slate-200 bg-white px-4 py-3 inline-flex items-center">
                    <img id="logoPrev" src="{{ $logo }}" alt="" style="height: {{ $lh }}px" class="w-auto max-w-full object-contain">
                </div>
                <p class="text-xs text-slate-500 mt-1">দোকানের মাথায় যেভাবে দেখাবে তার নমুনা। সেভ করলে কার্যকর হবে।</p>
            @endif
            @error('logo_height')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror
        </div>

        <div class="text-sm">
            <span class="font-medium">ব্র্যান্ডের রং</span>
            <div class="mt-1 flex flex-wrap items-center gap-3">
                <input type="color" id="colorPicker" value="{{ old('brand_color', config('shop.brand_color')) }}" class="h-10 w-14 rounded border border-slate-300 p-1 bg-white">
                <input name="brand_color" id="colorText" value="{{ old('brand_color', config('shop.brand_color')) }}" maxlength="7" class="w-32 rounded-lg border border-slate-300 px-3 py-2 font-mono">
                <span class="inline-block rounded-lg px-4 py-2 text-white text-sm" id="colorPreview" style="background: {{ old('brand_color', config('shop.brand_color')) }}">বাটনের নমুনা</span>
            </div>
            <p class="text-xs text-slate-500 mt-1">গাঢ় রং বেছে নিন, নইলে বাটনের সাদা লেখা পড়া কঠিন হবে।</p>
            @error('brand_color')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror
        </div>

        <label class="block text-sm"><span class="font-medium">সাইটের একদম ওপরের ঘোষণা (ঐচ্ছিক)</span>
            <input name="topbar_text" value="{{ $val('topbar_text') }}" placeholder="যেমন: ২০০০ টাকার বেশি কিনলে ডেলিভারি ফ্রি" class="{{ $in }}">
            <span class="text-xs text-slate-500">ফাঁকা রাখলে ঘোষণার বার দেখাবে না।</span>
            @error('topbar_text')<span class="text-red-600 text-xs block">{{ $message }}</span>@enderror</label>

        <label class="block text-sm"><span class="font-medium">সাইটের বর্ণনা (Google-এ হোম পেজের নিচে এই লেখা দেখায়)</span>
            <textarea name="site_description" rows="2" class="{{ $in }}">{{ $val('site_description') }}</textarea>
            <span class="text-xs text-slate-500">১৫০ অক্ষরের মধ্যে দোকান কী বিক্রি করে সেটা লিখুন।</span>
            @error('site_description')<span class="text-red-600 text-xs block">{{ $message }}</span>@enderror</label>

        <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="show_nav_categories" value="1" @checked(($S['show_nav_categories'] ?? '1') !== '0')> হেডারের নিচে ক্যাটাগরির মেনু দেখান</label>
    </section>

    <section class="bg-white rounded-xl border border-slate-200 p-5 space-y-4">
        <h2 class="font-semibold">ডেলিভারি</h2>
        <div class="grid grid-cols-2 gap-4">
            <label class="block text-sm"><span class="font-medium">ডেলিভারি চার্জ ({{ config('shop.currency') }})</span>
                <input type="number" min="0" name="shipping_fee" value="{{ old('shipping_fee', config('shop.shipping_fee')) }}" class="{{ $in }}">
                @error('shipping_fee')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror</label>
            <label class="block text-sm"><span class="font-medium">এর বেশি কিনলে ফ্রি ({{ config('shop.currency') }})</span>
                <input type="number" min="0" name="free_shipping_over" value="{{ old('free_shipping_over', config('shop.free_shipping_over')) }}" class="{{ $in }}">
                @error('free_shipping_over')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror</label>
        </div>
    </section>

    <section class="bg-white rounded-xl border border-slate-200 p-5 space-y-4">
        <h2 class="font-semibold">ফুটার ও যোগাযোগ</h2>
        <label class="block text-sm"><span class="font-medium">দোকান সম্পর্কে ছোট লেখা</span>
            <textarea name="footer_about" rows="2" class="{{ $in }}">{{ $val('footer_about') }}</textarea>
            @error('footer_about')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror</label>
        <label class="block text-sm"><span class="font-medium">ঠিকানা</span>
            <input name="address" value="{{ $val('address') }}" class="{{ $in }}">@error('address')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror</label>
        <div class="grid sm:grid-cols-2 gap-4">
            <label class="block text-sm"><span class="font-medium">ফোন</span>
                <input name="phone" value="{{ $val('phone') }}" class="{{ $in }}">@error('phone')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror</label>
            <label class="block text-sm"><span class="font-medium">ইমেইল</span>
                <input name="email" value="{{ $val('email') }}" class="{{ $in }}">@error('email')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror</label>
            <label class="block text-sm"><span class="font-medium">WhatsApp নম্বর</span>
                <input name="whatsapp" value="{{ $val('whatsapp') }}" placeholder="8801XXXXXXXXX" class="{{ $in }}">@error('whatsapp')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror</label>
            <label class="block text-sm"><span class="font-medium">খোলার সময়</span>
                <input name="hours" value="{{ $val('hours') }}" placeholder="প্রতিদিন সকাল ১০টা – রাত ৯টা" class="{{ $in }}">@error('hours')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror</label>
        </div>
    </section>

    <section class="bg-white rounded-xl border border-slate-200 p-5 space-y-4">
        <h2 class="font-semibold">সোশ্যাল মিডিয়া</h2>
        <p class="text-xs text-slate-500 -mt-2">পুরো লিংক দিন (https:// দিয়ে শুরু)। ফাঁকা রাখলে ফুটারে দেখাবে না।</p>
        @foreach (['facebook' => 'Facebook পেজ', 'instagram' => 'Instagram', 'youtube' => 'YouTube'] as $k => $label)
            <label class="block text-sm"><span class="font-medium">{{ $label }}</span>
                <input name="{{ $k }}" value="{{ $val($k) }}" placeholder="https://" class="{{ $in }}">@error($k)<span class="text-red-600 text-xs">{{ $message }}</span>@enderror</label>
        @endforeach
    </section>

    <button class="rounded-lg bg-brand hover:bg-brand-dark text-white px-6 py-2.5 font-semibold">সেভ করুন</button>
</form>

<script>
    (function () {
        var r = document.getElementById('logoRange'), val = document.getElementById('logoVal'), img = document.getElementById('logoPrev');
        r.addEventListener('input', function () { val.textContent = r.value + 'px'; if (img) img.style.height = r.value + 'px'; });
        var p = document.getElementById('colorPicker'), t = document.getElementById('colorText'), v = document.getElementById('colorPreview');
        p.addEventListener('input', function () { t.value = p.value; v.style.background = p.value; });
        t.addEventListener('input', function () { if (/^#[0-9a-fA-F]{6}$/.test(t.value)) { p.value = t.value; v.style.background = t.value; } });
    })();
</script>
@endsection
