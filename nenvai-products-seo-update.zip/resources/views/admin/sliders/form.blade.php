@extends('layouts.admin')
@section('title', $slider->exists ? 'স্লাইড এডিট' : 'নতুন স্লাইড')
@section('content')
@php $in = 'mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-brand'; @endphp
<h1 class="text-2xl font-bold mb-6">{{ $slider->exists ? 'স্লাইড এডিট করুন' : 'নতুন স্লাইড' }}</h1>
<form method="POST" enctype="multipart/form-data"
      action="{{ $slider->exists ? route('admin.sliders.update', $slider) : route('admin.sliders.store') }}"
      class="bg-white rounded-xl border border-slate-200 p-5 max-w-2xl space-y-4">
    @csrf
    @if ($slider->exists) @method('PUT') @endif

    <div class="text-sm">
        <span class="font-medium">ছবি</span>
        @if ($slider->exists)
            <img src="{{ $slider->imageUrl() }}" alt="" class="mt-2 w-full max-w-md aspect-[16/6] rounded-lg object-cover border border-slate-200">
        @endif
        <input type="file" name="image" accept="image/*" class="{{ $in }}">
        <p class="text-xs text-slate-500 mt-1">সেরা মাপ ১৬০০×৬০০ পিক্সেল (চওড়া ছবি)। JPG, PNG বা WEBP, সর্বোচ্চ ২ MB।@if($slider->exists) নতুন ছবি না দিলে আগেরটাই থাকবে।@endif</p>
        @error('image')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror
    </div>

    <label class="block text-sm"><span class="font-medium">শিরোনাম (ঐচ্ছিক)</span>
        <input name="title" value="{{ old('title', $slider->title) }}" class="{{ $in }}">@error('title')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror</label>
    <label class="block text-sm"><span class="font-medium">ছোট লেখা (ঐচ্ছিক)</span>
        <input name="subtitle" value="{{ old('subtitle', $slider->subtitle) }}" class="{{ $in }}">@error('subtitle')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror</label>

    <div class="grid sm:grid-cols-2 gap-4">
        <label class="block text-sm"><span class="font-medium">বাটনের লেখা (ঐচ্ছিক)</span>
            <input name="button_text" value="{{ old('button_text', $slider->button_text) }}" placeholder="এখনই কিনুন" class="{{ $in }}">@error('button_text')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror</label>
        <label class="block text-sm"><span class="font-medium">লিংক (ঐচ্ছিক)</span>
            <input name="link" value="{{ old('link', $slider->link) }}" placeholder="/product/panjabi" class="{{ $in }}">@error('link')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror</label>
    </div>

    <label class="block text-sm"><span class="font-medium">কোথায় দেখাবে</span>
        <select name="position" class="{{ $in }}">
            @foreach (['top' => 'ওপরে (হোম পেজের শুরুতে)', 'middle' => 'মাঝখানে (পণ্যের সারির মাঝে)', 'bottom' => 'নিচে (ক্যাটাগরির আগে)'] as $k => $label)
                <option value="{{ $k }}" @selected(old('position', $slider->position ?? 'top') === $k)>{{ $label }}</option>
            @endforeach
        </select>
        <span class="text-xs text-slate-500">একই জায়গায় একাধিক স্লাইড দিলে সেগুলো ঘুরে ঘুরে দেখাবে।</span></label>
    <div class="grid grid-cols-2 gap-4 items-end">
        <label class="block text-sm"><span class="font-medium">ক্রম (ছোট সংখ্যা আগে)</span>
            <input type="number" min="0" name="sort_order" value="{{ old('sort_order', $slider->sort_order) }}" class="{{ $in }}"></label>
        <label class="flex items-center gap-2 text-sm pb-2"><input type="checkbox" name="is_active" value="1" @checked(old('is_active', $slider->is_active))> দোকানে দেখান</label>
    </div>

    <button class="rounded-lg bg-brand hover:bg-brand-dark text-white px-5 py-2 font-medium">সেভ করুন</button>
</form>
@endsection
