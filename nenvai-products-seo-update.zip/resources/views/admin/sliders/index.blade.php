@extends('layouts.admin')
@section('title', 'স্লাইডার')
@section('content')
<div class="flex flex-wrap justify-between items-center gap-3 mb-2">
    <h1 class="text-2xl font-bold">স্লাইডার</h1>
    <a href="{{ route('admin.sliders.create') }}" class="rounded-lg bg-brand text-white px-4 py-2 text-sm font-medium">নতুন স্লাইড</a>
</div>
<p class="text-sm text-slate-500 mb-4">দোকানের হোম পেজের ওপরে এই ছবিগুলো একটার পর একটা ঘুরে দেখায়। ক্রম ছোট সংখ্যা আগে আসে।</p>

<div class="bg-white rounded-xl border border-slate-200 divide-y divide-slate-100">
@forelse ($sliders as $s)
    <div class="p-4 flex flex-wrap items-center gap-4">
        <img src="{{ $s->imageUrl() }}" alt="" class="w-40 aspect-[16/6] rounded-lg object-cover border border-slate-200">
        <div class="flex-1 min-w-[10rem]">
            <div class="font-medium">{{ $s->title ?: '(শিরোনাম নেই)' }}</div>
            <div class="text-sm text-slate-500">{{ $s->subtitle }}</div>
            <div class="text-xs text-slate-400 mt-1">{{ ['top' => 'ওপরে', 'middle' => 'মাঝখানে', 'bottom' => 'নিচে'][$s->position ?? 'top'] ?? 'ওপরে' }} · ক্রম {{ $s->sort_order }} · {{ $s->is_active ? 'চালু' : 'বন্ধ' }}@if($s->link) · {{ $s->link }}@endif</div>
        </div>
        <div class="whitespace-nowrap text-sm">
            <a href="{{ route('admin.sliders.edit', $s) }}" class="text-brand">এডিট</a>
            <form method="POST" action="{{ route('admin.sliders.destroy', $s) }}" class="inline" onsubmit="return confirm('স্লাইডটি মুছে ফেলবেন?')">
                @csrf @method('DELETE') <button class="text-red-600 ml-3">মুছুন</button>
            </form>
        </div>
    </div>
@empty
    <p class="p-6 text-center text-slate-500">এখনো কোনো স্লাইড নেই। প্রথম স্লাইডটি যোগ করুন।</p>
@endforelse
</div>
@endsection
