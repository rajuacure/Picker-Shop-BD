@extends('layouts.admin')
@section('title', 'CSV ইমপোর্ট')
@section('content')
<h1 class="text-2xl font-bold mb-2">CSV দিয়ে পণ্য ইমপোর্ট</h1>
<p class="text-sm text-slate-500 mb-6">একসাথে অনেক পণ্য যোগ করা বা দাম ও স্টক বদলানো যায়। ছবি এখানে যায় না, ছবি পণ্য এডিট করে দিন।</p>

@if (! empty($report))
<section class="mb-6 rounded-xl border p-5 {{ $report['error_count'] ? 'border-amber-300 bg-amber-50' : 'border-green-300 bg-green-50' }}">
    <h2 class="font-semibold mb-1">ইমপোর্ট শেষ</h2>
    <p class="text-sm">নতুন পণ্য: <b>{{ $report['created'] }}</b> · আপডেট হয়েছে: <b>{{ $report['updated'] }}</b> · বাদ গেছে: <b>{{ $report['error_count'] }}</b></p>
    @if ($report['errors'])
        <ul class="mt-3 text-sm text-amber-800 list-disc pl-5 space-y-1">
            @foreach ($report['errors'] as $e)<li>{{ $e }}</li>@endforeach
        </ul>
        @if ($report['error_count'] > count($report['errors']))<p class="text-xs text-amber-700 mt-2">আরও {{ $report['error_count'] - count($report['errors']) }}টি সারির সমস্যা দেখানো হয়নি।</p>@endif
    @endif
</section>
@endif

<div class="grid lg:grid-cols-2 gap-6">
    <section class="bg-white rounded-xl border border-slate-200 p-5">
        <h2 class="font-semibold mb-3">১. ফাইল তৈরি</h2>
        <div class="flex flex-wrap gap-2 mb-4">
            <a href="{{ route('admin.import.sample') }}" class="rounded-lg border border-slate-300 hover:bg-slate-100 px-4 py-2 text-sm">নমুনা CSV ডাউনলোড</a>
            <a href="{{ route('admin.export') }}" class="rounded-lg border border-slate-300 hover:bg-slate-100 px-4 py-2 text-sm">বর্তমান সব পণ্য এক্সপোর্ট</a>
        </div>
        <p class="text-sm text-slate-600 mb-3">এক্সপোর্ট করা ফাইলে দাম বা স্টক বদলে আবার আপলোড করলে পণ্য আপডেট হয়ে যাবে।</p>
        <div class="overflow-x-auto">
        <table class="w-full text-xs border border-slate-200">
            <thead class="bg-slate-50 text-left"><tr><th class="p-2">কলাম</th><th class="p-2">অর্থ</th></tr></thead>
            <tbody class="divide-y divide-slate-100">
                <tr><td class="p-2 font-mono">name</td><td class="p-2"><b>দরকার।</b> পণ্যের নাম</td></tr>
                <tr><td class="p-2 font-mono">price</td><td class="p-2"><b>দরকার।</b> বিক্রির দাম</td></tr>
                <tr><td class="p-2 font-mono">sku</td><td class="p-2">পণ্যের কোড (মিললে আপডেট, না মিললে নতুন)</td></tr>
                <tr><td class="p-2 font-mono">category</td><td class="p-2">ক্যাটাগরির নাম (না থাকলে নতুন বানানো হবে)</td></tr>
                <tr><td class="p-2 font-mono">weight</td><td class="p-2">ওজন, যেমন ৫০০ গ্রাম</td></tr>
                <tr><td class="p-2 font-mono">cost_price</td><td class="p-2">কেনা দাম</td></tr>
                <tr><td class="p-2 font-mono">offer_price</td><td class="p-2">অফারের দাম (ফাঁকা = অফার নেই)</td></tr>
                <tr><td class="p-2 font-mono">stock</td><td class="p-2">স্টক সংখ্যা</td></tr>
                <tr><td class="p-2 font-mono">description</td><td class="p-2">বিবরণ</td></tr>
                <tr><td class="p-2 font-mono">is_active</td><td class="p-2">1 = দোকানে দেখাবে, 0 = লুকানো</td></tr>
            </tbody>
        </table>
        </div>
        <ul class="mt-3 text-xs text-slate-500 space-y-1 list-disc pl-4">
            <li>প্রথম সারি কলামের নাম। বাংলা নামও চলে (নাম, বিক্রি দাম, কেনা দাম, অফার দাম, স্টক, ওজন, ক্যাটাগরি, বিবরণ)।</li>
            <li>আপডেটের সময় যে কলাম ফাইলে নেই বা ঘর ফাঁকা, সেটা বদলাবে না (শুধু অফার দামের ফাঁকা ঘর মানে অফার বন্ধ)।</li>
            <li>Excel-এ "Save As → CSV UTF-8" বেছে সেভ করুন, নইলে বাংলা ভেঙে যাবে। একবারে সর্বোচ্চ ১০০০ সারি, ফাইল ২ MB-এর কম।</li>
        </ul>
    </section>

    <section class="bg-white rounded-xl border border-slate-200 p-5 h-fit">
        <h2 class="font-semibold mb-3">২. ফাইল আপলোড</h2>
        <form method="POST" action="{{ route('admin.import.run') }}" enctype="multipart/form-data" class="space-y-4">
            @csrf
            <input type="file" name="csv" accept=".csv,text/csv" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
            @error('csv')<span class="text-red-600 text-sm block">{{ $message }}</span>@enderror
            <button class="rounded-lg bg-brand hover:bg-brand-dark text-white px-6 py-2.5 font-semibold">ইমপোর্ট করুন</button>
        </form>
        <p class="text-xs text-slate-500 mt-3">ইমপোর্টের আগে এক্সপোর্ট করে একটা কপি রেখে দেওয়া নিরাপদ।</p>
    </section>
</div>
@endsection
