@extends('layouts.admin')
@section('title', 'পণ্য')
@section('content')
<div class="flex flex-wrap justify-between items-center gap-3 mb-4">
    <h1 class="text-2xl font-bold">পণ্য</h1>
    <div class="flex flex-wrap gap-2">
        <a href="{{ route('admin.import.form') }}" class="rounded-lg border border-slate-300 hover:bg-slate-100 px-4 py-2 text-sm">CSV ইমপোর্ট / এক্সপোর্ট</a>
        <a href="{{ route('admin.products.create') }}" class="rounded-lg bg-brand text-white px-4 py-2 text-sm font-medium">নতুন পণ্য</a>
    </div>
</div>
<form class="mb-4"><input name="q" value="{{ request('q') }}" placeholder="নাম বা কোড দিয়ে খুঁজুন" class="rounded-lg border border-slate-300 px-3 py-2 text-sm w-72"></form>

<div class="bg-white rounded-xl border border-slate-200 overflow-x-auto">
<table class="w-full text-sm">
    <thead class="text-left text-slate-500 border-b border-slate-100">
        <tr><th class="p-3">পণ্য</th><th class="p-3">কেনা</th><th class="p-3">বিক্রি</th><th class="p-3">অফার</th><th class="p-3">মুনাফা</th><th class="p-3">স্টক</th><th class="p-3">অবস্থা</th><th class="p-3"></th></tr>
    </thead>
    <tbody class="divide-y divide-slate-100">
    @forelse ($products as $p)
        @php $profit = $p->profitPerUnit(); @endphp
        <tr>
            <td class="p-3">
                <div class="flex items-center gap-3">
                    <img src="{{ $p->imageUrl() }}" class="w-10 h-10 rounded object-cover" alt="">
                    <div>
                        <div class="font-medium">{{ $p->name }}@if($p->weight) <span class="text-slate-400 font-normal">· {{ $p->weight }}</span>@endif</div>
                        <div class="text-xs text-slate-400">{{ $p->category->name ?? 'ক্যাটাগরি নেই' }}@if($p->sku) · {{ $p->sku }}@endif</div>
                    </div>
                </div>
            </td>
            <td class="p-3 text-slate-500">{{ $p->cost_price !== null ? config('shop.currency').number_format($p->cost_price) : '—' }}</td>
            <td class="p-3">{{ config('shop.currency') }}{{ number_format($p->price) }}</td>
            <td class="p-3">{!! $p->hasOffer() ? '<span class="text-red-600 font-medium">'.config('shop.currency').number_format($p->offer_price).'</span>' : '<span class="text-slate-400">—</span>' !!}</td>
            <td class="p-3 {{ $profit !== null && $profit < 0 ? 'text-red-600' : 'text-green-700' }}">{{ $profit !== null ? config('shop.currency').number_format($profit) : '—' }}</td>
            <td class="p-3 {{ $p->stock <= 5 ? 'text-amber-700 font-medium' : '' }}">{{ $p->stock }}</td>
            <td class="p-3">{{ $p->is_active ? 'চালু' : 'বন্ধ' }}</td>
            <td class="p-3 text-right whitespace-nowrap">
                <a href="{{ route('admin.products.edit', $p) }}" class="text-brand">এডিট</a>
                <form method="POST" action="{{ route('admin.products.destroy', $p) }}" class="inline" onsubmit="return confirm('পণ্যটি মুছে ফেলবেন?')">
                    @csrf @method('DELETE') <button class="text-red-600 ml-3">মুছুন</button>
                </form>
            </td>
        </tr>
    @empty
        <tr><td colspan="8" class="p-6 text-center text-slate-500">কোনো পণ্য নেই। প্রথম পণ্যটি যোগ করুন।</td></tr>
    @endforelse
    </tbody>
</table>
</div>
<div class="mt-4">{{ $products->links() }}</div>
@endsection
