@extends('layouts.admin')
@section('title', $product->exists ? 'পণ্য এডিট' : 'নতুন পণ্য')
@section('content')
@php $in = 'mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-brand'; @endphp
<h1 class="text-2xl font-bold mb-6">{{ $product->exists ? 'পণ্য এডিট করুন' : 'নতুন পণ্য' }}</h1>
<form method="POST" enctype="multipart/form-data"
      action="{{ $product->exists ? route('admin.products.update', $product) : route('admin.products.store') }}"
      class="space-y-6 max-w-3xl">
    @csrf
    @if ($product->exists) @method('PUT') @endif

    <section class="bg-white rounded-xl border border-slate-200 p-5 space-y-4">
        <h2 class="font-semibold">পণ্যের তথ্য</h2>
        <label class="block text-sm"><span class="font-medium">পণ্যের নাম</span>
            <input name="name" value="{{ old('name', $product->name) }}" class="{{ $in }}">@error('name')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror</label>

        <div class="grid sm:grid-cols-2 gap-4">
            <label class="block text-sm"><span class="font-medium">ওজন / পরিমাণ</span>
                <input name="weight" value="{{ old('weight', $product->weight) }}" placeholder="যেমন: ৫০০ গ্রাম, ১ কেজি, ২৫০ মি.লি." class="{{ $in }}">@error('weight')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror</label>
            <label class="block text-sm"><span class="font-medium">ক্যাটাগরি</span>
                <select name="category_id" class="{{ $in }}">
                    <option value="">— ক্যাটাগরি নেই —</option>
                    @foreach ($categories as $c)
                        <option value="{{ $c->id }}" @selected((string) old('category_id', $product->category_id) === (string) $c->id)>{{ $c->name }}</option>
                    @endforeach
                </select>
                @if ($categories->isEmpty())<span class="text-xs text-slate-500">আগে <a href="{{ route('admin.categories.create') }}" class="text-brand">ক্যাটাগরি যোগ করুন</a>।</span>@endif
                @error('category_id')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror</label>
        </div>

        <label class="block text-sm"><span class="font-medium">বিবরণ</span>
            <textarea name="description" rows="5" class="{{ $in }}">{{ old('description', $product->description) }}</textarea></label>

        <div class="text-sm">
            <span class="font-medium">ছবি</span>
            @if ($product->exists && $product->image)<img src="{{ $product->imageUrl() }}" alt="" class="mt-2 h-20 w-20 rounded-lg object-cover border border-slate-200">@endif
            <input type="file" name="image" accept="image/*" class="{{ $in }}">@error('image')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror
        </div>
    </section>

    <section class="bg-white rounded-xl border border-slate-200 p-5 space-y-4">
        <h2 class="font-semibold">দাম ও স্টক</h2>
        <div class="grid sm:grid-cols-3 gap-4">
            <label class="block text-sm"><span class="font-medium">কেনা দাম ({{ config('shop.currency') }})</span>
                <input type="number" step="0.01" min="0" id="fCost" name="cost_price" value="{{ old('cost_price', $product->cost_price) }}" class="{{ $in }}">
                <span class="text-xs text-slate-500">শুধু আপনি দেখবেন, মুনাফার হিসাবে লাগে</span>@error('cost_price')<span class="text-red-600 text-xs block">{{ $message }}</span>@enderror</label>
            <label class="block text-sm"><span class="font-medium">বিক্রির দাম ({{ config('shop.currency') }})</span>
                <input type="number" step="0.01" min="0" id="fPrice" name="price" value="{{ old('price', $product->price) }}" class="{{ $in }}">
                <span class="text-xs text-slate-500">নিয়মিত দাম</span>@error('price')<span class="text-red-600 text-xs block">{{ $message }}</span>@enderror</label>
            <label class="block text-sm"><span class="font-medium">অফারের দাম ({{ config('shop.currency') }})</span>
                <input type="number" step="0.01" min="0" id="fOffer" name="offer_price" value="{{ old('offer_price', $product->offer_price) }}" class="{{ $in }}">
                <span class="text-xs text-slate-500">দিলে এই দামে বিক্রি হবে, ফাঁকা = অফার নেই</span>@error('offer_price')<span class="text-red-600 text-xs block">{{ $message }}</span>@enderror</label>
        </div>
        <p id="profitNote" class="text-sm rounded-lg bg-slate-50 border border-slate-200 px-3 py-2 text-slate-600"></p>
        <label class="block text-sm max-w-xs"><span class="font-medium">স্টক (কতগুলো আছে)</span>
            <input type="number" min="0" name="stock" value="{{ old('stock', $product->stock ?? 0) }}" class="{{ $in }}">@error('stock')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror</label>
    </section>

    <details class="bg-white rounded-xl border border-slate-200 p-5" {{ $errors->hasAny(['slug', 'sku', 'meta_title', 'meta_description']) ? 'open' : '' }}>
        <summary class="font-semibold cursor-pointer">SEO ও কোড (ঐচ্ছিক, না দিলে নিজে থেকে তৈরি হবে)</summary>
        <div class="mt-4 space-y-4">
            <label class="block text-sm"><span class="font-medium">Google-এ দেখানো শিরোনাম</span>
                <input name="meta_title" maxlength="160" value="{{ old('meta_title', $product->meta_title) }}" placeholder="ফাঁকা রাখলে: পণ্যের নাম + ওজন" class="{{ $in }}">@error('meta_title')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror</label>
            <label class="block text-sm"><span class="font-medium">Google-এ দেখানো বর্ণনা</span>
                <textarea name="meta_description" rows="2" maxlength="300" placeholder="ফাঁকা রাখলে বিবরণের প্রথম অংশ ব্যবহার হবে। ১৫০ অক্ষরের মধ্যে রাখলে ভালো।" class="{{ $in }}">{{ old('meta_description', $product->meta_description) }}</textarea>@error('meta_description')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror</label>
            <div class="grid sm:grid-cols-2 gap-4">
                <label class="block text-sm"><span class="font-medium">পেজের লিংক (ইংরেজিতে)</span>
                    <input name="slug" value="{{ old('slug', $product->exists ? $product->slug : '') }}" placeholder="raw-honey-500g" class="{{ $in }} font-mono">
                    <span class="text-xs text-slate-500">ছোট হাতের ইংরেজি অক্ষর, সংখ্যা ও -। ফাঁকা রাখলে নিজে থেকে হবে।@if($product->exists) লিংক বদলালে পুরোনো লিংক আর কাজ করবে না।@endif</span>@error('slug')<span class="text-red-600 text-xs block">{{ $message }}</span>@enderror</label>
                <label class="block text-sm"><span class="font-medium">পণ্যের কোড (SKU)</span>
                    <input name="sku" value="{{ old('sku', $product->sku) }}" class="{{ $in }} font-mono">
                    <span class="text-xs text-slate-500">CSV দিয়ে দাম বদলাতে এই কোড কাজে লাগে</span>@error('sku')<span class="text-red-600 text-xs block">{{ $message }}</span>@enderror</label>
            </div>
        </div>
    </details>

    <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="is_active" value="1" @checked(old('is_active', $product->is_active))> দোকানে দেখান</label>
    <button class="rounded-lg bg-brand hover:bg-brand-dark text-white px-6 py-2.5 font-semibold">সেভ করুন</button>
</form>

<script>
    (function () {
        var c = document.getElementById('fCost'), p = document.getElementById('fPrice'), o = document.getElementById('fOffer'), n = document.getElementById('profitNote');
        function calc() {
            var cost = parseFloat(c.value), price = parseFloat(p.value), offer = parseFloat(o.value);
            var sell = (offer > 0 && offer < price) ? offer : price;
            if (!(sell > 0)) { n.textContent = 'দাম দিলে এখানে মুনাফা দেখাবে।'; return; }
            if (!(cost >= 0) || c.value === '') { n.textContent = 'বিক্রির দাম: ' + sell + '। কেনা দাম দিলে মুনাফা দেখাবে।'; return; }
            var profit = sell - cost, pct = sell > 0 ? Math.round(profit / sell * 100) : 0;
            n.textContent = 'বিক্রির দাম ' + sell + ' − কেনা দাম ' + cost + ' = প্রতি পিসে মুনাফা ' + profit + ' (' + pct + '%)' + (profit < 0 ? ' — লোকসান হচ্ছে!' : '');
            n.style.color = profit < 0 ? '#b91c1c' : '';
        }
        [c, p, o].forEach(function (e) { e.addEventListener('input', calc); });
        calc();
    })();
</script>
@endsection
