@extends('layouts.admin')
@section('title', 'ড্যাশবোর্ড')
@section('content')
@php $cur = config('shop.currency'); $max = max($days->max('total'), 1); @endphp
<h1 class="text-2xl font-bold mb-6">ড্যাশবোর্ড</h1>

<div class="grid grid-cols-2 lg:grid-cols-3 gap-4">
    @foreach ([
        ['আজকের অর্ডার', number_format($stats['today_orders'])],
        ['আজকের বিক্রি', $cur.number_format($stats['today_revenue'])],
        ['এই মাসের বিক্রি', $cur.number_format($stats['month_revenue'])],
        ['নতুন অর্ডার (বাকি)', number_format($stats['pending'])],
        ['আজকের মুনাফা', $cur.number_format($stats['today_profit'])],
        ['এই মাসের মুনাফা', $cur.number_format($stats['month_profit'])],
    ] as [$label, $value])
    <div class="bg-white rounded-xl border border-slate-200 p-4">
        <div class="text-sm text-slate-500">{{ $label }}</div>
        <div class="text-2xl font-bold mt-1">{{ $value }}</div>
    </div>
    @endforeach
</div>

<div class="grid lg:grid-cols-3 gap-6 mt-6">
    <section class="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-5">
        <h2 class="font-semibold mb-4">গত ৭ দিনের বিক্রি</h2>
        <div class="flex items-end gap-2 h-40">
            @foreach ($days as $d)
            <div class="flex-1 flex flex-col items-center justify-end h-full" title="{{ $cur }}{{ number_format($d['total']) }}">
                <div class="w-full bg-brand rounded-t" style="height: {{ max(($d['total'] / $max) * 100, $d['total'] > 0 ? 4 : 0) }}%"></div>
                <div class="text-xs text-slate-500 mt-1">{{ $d['label'] }}</div>
            </div>
            @endforeach
        </div>
    </section>

    <section class="bg-white rounded-xl border border-slate-200 p-5">
        <h2 class="font-semibold mb-3">স্টক কম</h2>
        @forelse ($lowStock as $p)
            <a href="{{ route('admin.products.edit', $p) }}" class="flex justify-between py-1.5 text-sm hover:text-brand">
                <span class="truncate">{{ $p->name }}</span>
                <span class="{{ $p->stock == 0 ? 'text-red-600' : 'text-amber-700' }} font-medium">{{ $p->stock == 0 ? 'শেষ' : $p->stock.' টি' }}</span>
            </a>
        @empty
            <p class="text-sm text-slate-500">সব পণ্যের স্টক ঠিক আছে।</p>
        @endforelse
    </section>
</div>

<section class="bg-white rounded-xl border border-slate-200 mt-6 overflow-x-auto">
    <div class="p-5 pb-2 flex justify-between"><h2 class="font-semibold">সাম্প্রতিক অর্ডার</h2>
        <a href="{{ route('admin.orders.index') }}" class="text-sm text-brand">সব অর্ডার</a></div>
    @include('admin.orders.table', ['orders' => $recent])
</section>
@endsection
