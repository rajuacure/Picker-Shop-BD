@extends('layouts.app')
@section('title', $page->title)
@section('description', \Illuminate\Support\Str::limit(trim(preg_replace('/\s+/u', ' ', strip_tags((string) $page->content))), 155))
@section('content')
<article class="max-w-3xl mx-auto bg-white rounded-xl border border-slate-200 p-6 md:p-10">
    <h1 class="text-2xl md:text-3xl font-bold mb-6">{{ $page->title }}</h1>
    <div class="leading-relaxed text-slate-700 space-y-4">{!! nl2br(e($page->content)) !!}</div>
</article>
@endsection
