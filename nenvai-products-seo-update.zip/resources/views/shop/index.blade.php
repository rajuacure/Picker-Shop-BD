@extends('layouts.app')
@php
    $S = \App\Models\Setting::cached();
    $org = ['@context' => 'https://schema.org', '@type' => 'Organization', 'name' => config('shop.name'), 'url' => url('/')];
    if ($lg = \App\Support\Brand::logoUrl()) $org['logo'] = $lg;
    $same = array_values(array_filter([$S['facebook'] ?? '', $S['instagram'] ?? '', $S['youtube'] ?? '']));
    if ($same) $org['sameAs'] = $same;
    if (! empty($S['phone'])) $org['contactPoint'] = ['@type' => 'ContactPoint', 'telephone' => $S['phone'], 'contactType' => 'customer service'];
    $site = ['@context' => 'https://schema.org', '@type' => 'WebSite', 'name' => config('shop.name'), 'url' => url('/'),
        'potentialAction' => ['@type' => 'SearchAction', 'target' => route('shop.products') . '?q={search_term_string}', 'query-input' => 'required name=search_term_string']];
    $flags = JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG;
    $by = fn ($pos) => $sliders->filter(fn ($s) => ($s->position ?? 'top') === $pos)->values();
@endphp
@push('jsonld')
<script type="application/ld+json">{!! json_encode($org, $flags) !!}</script>
<script type="application/ld+json">{!! json_encode($site, $flags) !!}</script>
@endpush
@section('content')
@include('shop._slider', ['slides' => $by('top'), 'sid' => 'top', 'ratio' => 'md:aspect-[16/6]'])

@if ($deals->isNotEmpty())
<section class="mb-8">
    <h2 class="text-xl font-bold mb-4">অফারের পণ্য</h2>
    <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-5">
        @foreach ($deals as $p) @include('shop._card') @endforeach
    </div>
</section>
@endif

@include('shop._slider', ['slides' => $by('middle'), 'sid' => 'mid', 'ratio' => 'md:aspect-[16/4]'])

<section class="mb-8">
    <div class="flex items-center justify-between mb-4">
        <h2 class="text-xl font-bold">নতুন পণ্য</h2>
        <a href="{{ route('shop.products') }}" class="text-sm text-brand font-medium">সব দেখুন →</a>
    </div>
    @if ($latest->isEmpty())
        <p class="text-slate-500">এখনো কোনো পণ্য যোগ করা হয়নি।</p>
    @else
        <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-5">
            @foreach ($latest as $p) @include('shop._card') @endforeach
        </div>
    @endif
</section>

@include('shop._slider', ['slides' => $by('bottom'), 'sid' => 'bot', 'ratio' => 'md:aspect-[16/4]'])

@if ($categories->isNotEmpty())
<section class="mt-12 mb-4 text-center">
    <h2 class="text-xl md:text-2xl font-bold">ক্যাটাগরি অনুযায়ী কিনুন</h2>
    <div class="mx-auto mt-2 mb-6 h-1 w-12 rounded-full bg-brand"></div>
    <div class="flex flex-wrap justify-center gap-5 md:gap-10">
        @foreach ($categories as $c)
        <a href="{{ route('shop.category', $c) }}" class="group flex flex-col items-center gap-2 w-24 md:w-28">
            @if ($c->imageUrl())
                <img src="{{ $c->imageUrl() }}" alt="{{ $c->name }}" loading="lazy" class="h-20 w-20 md:h-24 md:w-24 rounded-full object-cover border-2 border-slate-200 group-hover:border-brand shadow-sm">
            @else
                <span class="h-20 w-20 md:h-24 md:w-24 rounded-full bg-brand-soft text-brand text-3xl font-bold flex items-center justify-center border-2 border-transparent group-hover:border-brand shadow-sm">{{ mb_substr($c->name, 0, 1) }}</span>
            @endif
            <span class="text-sm md:text-base font-medium leading-tight group-hover:text-brand">{{ $c->name }}</span>
        </a>
        @endforeach
    </div>
</section>
@endif
@endsection
