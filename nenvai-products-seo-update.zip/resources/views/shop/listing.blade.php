@extends('layouts.app')
@section('title', $title)
@section('description', $category ? $category->name . ' ক্যাটাগরির পণ্য কিনুন — ' . config('shop.name') . '। ক্যাশ অন ডেলিভারি।' : (request('q') ? '' : \App\Models\Setting::get('site_description')))
@section('content')
<nav class="text-sm text-slate-500 mb-3"><a href="{{ route('shop.index') }}" class="hover:text-brand">হোম</a> / <span>{{ $title }}</span></nav>
<div class="flex flex-wrap items-center justify-between gap-3 mb-5">
    <h1 class="text-2xl font-bold">{{ $title }} <span class="text-base font-normal text-slate-400">({{ $products->total() }})</span></h1>
    <form method="GET" class="flex items-center gap-2 text-sm">
        @if (request('q'))<input type="hidden" name="q" value="{{ request('q') }}">@endif
        <label for="sort" class="text-slate-500">সাজান:</label>
        <select id="sort" name="sort" onchange="this.form.submit()" class="rounded-lg border border-slate-300 px-3 py-1.5">
            <option value="new" @selected($sort === 'new')>নতুন আগে</option>
            <option value="price_asc" @selected($sort === 'price_asc')>দাম: কম থেকে বেশি</option>
            <option value="price_desc" @selected($sort === 'price_desc')>দাম: বেশি থেকে কম</option>
            <option value="name" @selected($sort === 'name')>নাম অনুযায়ী</option>
        </select>
    </form>
</div>

@if ($products->isEmpty())
    <p class="text-slate-500 py-10 text-center">কোনো পণ্য পাওয়া যায়নি।</p>
@else
    <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-5">
        @foreach ($products as $p) @include('shop._card') @endforeach
    </div>
    <div class="mt-8">{{ $products->links() }}</div>
@endif
@endsection
