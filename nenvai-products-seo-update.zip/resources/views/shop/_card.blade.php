<div class="group bg-white rounded-xl border border-slate-200 overflow-hidden flex flex-col hover:shadow-md transition-shadow">
    <a href="{{ route('shop.show', $p) }}" class="relative block overflow-hidden">
        <img src="{{ $p->imageUrl() }}" alt="{{ $p->name }}" loading="lazy" class="aspect-square w-full object-cover group-hover:scale-105 transition-transform duration-300">
        @if ($p->stock > 0 && $p->discountPercent())
            <span class="absolute top-2 left-2 rounded-full bg-red-600 text-white text-xs font-semibold px-2 py-0.5">-{{ $p->discountPercent() }}%</span>
        @endif
        @if ($p->stock < 1)
            <span class="absolute inset-0 bg-white/60 flex items-center justify-center text-sm font-semibold text-slate-700">স্টক শেষ</span>
        @endif
    </a>
    <div class="p-3 flex flex-col flex-1">
        <a href="{{ route('shop.show', $p) }}" class="font-medium leading-snug line-clamp-2 hover:text-brand">{{ $p->name }}</a>
        @if ($p->weight)<div class="mt-0.5 text-xs text-slate-500">{{ $p->weight }}</div>@endif
        <div class="mt-1 flex items-baseline gap-2">
            <span class="font-semibold text-brand">{{ config('shop.currency') }}{{ number_format($p->currentPrice()) }}</span>
            @if ($p->hasOffer())<span class="text-xs text-slate-400 line-through">{{ config('shop.currency') }}{{ number_format($p->price) }}</span>@endif
        </div>
        <form method="POST" action="{{ route('cart.add', $p) }}" class="mt-auto pt-3">
            @csrf
            @if ($p->stock > 0)
                <button class="w-full rounded-lg bg-brand hover:bg-brand-dark text-white text-sm py-2 font-medium">কার্টে যোগ করুন</button>
            @else
                <div class="w-full rounded-lg bg-slate-100 text-slate-500 text-sm py-2 text-center">স্টক শেষ</div>
            @endif
        </form>
    </div>
</div>
