@extends('layouts.app')
@php
    $cur = config('shop.currency');
    $url = route('shop.show', $product);
    $seoTitle = $product->seoTitle();
    $seoDesc  = $product->seoDescription();
    $waText = "আসসালামু আলাইকুম, আমি এই পণ্যটি অর্ডার করতে চাই:\n" . trim($product->name . ' ' . $product->weight) . "\n" . $url;
    $wa  = \App\Support\Contact::whatsappLink($waText);
    $tel = \App\Support\Contact::telLink();
    $flags = JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG;

    $ld = [
        '@context' => 'https://schema.org', '@type' => 'Product',
        'name' => $product->name, 'description' => $seoDesc,
        'sku' => $product->sku ?: (string) $product->id,
        'brand' => ['@type' => 'Brand', 'name' => config('shop.name')],
        'offers' => [
            '@type' => 'Offer', 'url' => $url, 'priceCurrency' => 'BDT',
            'price' => number_format($product->currentPrice(), 2, '.', ''),
            'availability' => $product->stock > 0 ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock',
            'itemCondition' => 'https://schema.org/NewCondition',
        ],
    ];
    if ($product->hasImage()) $ld['image'] = [$product->imageUrl()];
    if ($product->category) $ld['category'] = $product->category->name;

    $crumbs = [['@type' => 'ListItem', 'position' => 1, 'name' => 'হোম', 'item' => url('/')]];
    if ($product->category) $crumbs[] = ['@type' => 'ListItem', 'position' => count($crumbs) + 1, 'name' => $product->category->name, 'item' => route('shop.category', $product->category)];
    $crumbs[] = ['@type' => 'ListItem', 'position' => count($crumbs) + 1, 'name' => $product->name, 'item' => $url];
    $bc = ['@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => $crumbs];
@endphp
@section('title', $seoTitle)
@section('description', $seoDesc)
@section('og_type', 'product')
@if ($product->hasImage())@section('og_image', $product->imageUrl())@endif
@push('jsonld')
<script type="application/ld+json">{!! json_encode($ld, $flags) !!}</script>
<script type="application/ld+json">{!! json_encode($bc, $flags) !!}</script>
@endpush

@section('content')
<nav class="text-sm text-slate-500 mb-4" aria-label="breadcrumb">
    <a href="{{ route('shop.index') }}" class="hover:text-brand">হোম</a> /
    @if ($product->category)<a href="{{ route('shop.category', $product->category) }}" class="hover:text-brand">{{ $product->category->name }}</a> /@endif
    <span>{{ $product->name }}</span>
</nav>

<div class="grid md:grid-cols-2 gap-8 items-start">
    <img src="{{ $product->imageUrl() }}" alt="{{ $product->name }}" class="w-full rounded-xl border border-slate-200 object-cover aspect-square">

    <div>
        <h1 class="text-2xl md:text-3xl font-bold leading-tight">{{ $product->name }}</h1>
        @if ($product->weight)
            <span class="mt-2 inline-block rounded-full bg-brand-soft text-brand text-sm font-medium px-3 py-1">{{ $product->weight }}</span>
        @endif

        <div class="mt-4 flex flex-wrap items-baseline gap-3">
            <span class="text-3xl font-bold text-brand">{{ $cur }}{{ number_format($product->currentPrice()) }}</span>
            @if ($product->hasOffer())
                <span class="text-lg text-slate-400 line-through">{{ $cur }}{{ number_format($product->price) }}</span>
                <span class="rounded-full bg-red-600 text-white text-xs font-semibold px-2 py-0.5">-{{ $product->discountPercent() }}%</span>
            @endif
        </div>

        @if ($product->stock > 0)
            <p class="mt-2 text-sm {{ $product->stock <= 5 ? 'text-amber-700' : 'text-green-700' }}">
                {{ $product->stock <= 5 ? 'মাত্র '.$product->stock.' টি বাকি' : 'স্টকে আছে' }}
            </p>
            <form method="POST" action="{{ route('cart.add', $product) }}" class="mt-5">
                @csrf
                <div class="flex flex-wrap items-center gap-3">
                    <input type="number" name="qty" value="1" min="1" max="{{ $product->stock }}" aria-label="পরিমাণ" class="w-20 rounded-lg border border-slate-300 px-3 py-3">
                    <button name="buy_now" value="1" class="flex-1 min-w-[11rem] rounded-lg bg-brand hover:bg-brand-dark text-white px-6 py-3 text-lg font-semibold">অর্ডার করুন</button>
                    <button class="rounded-lg border border-brand text-brand hover:bg-brand-soft px-5 py-3 font-medium">কার্টে যোগ করুন</button>
                </div>
            </form>
        @else
            <p class="mt-4 rounded-lg bg-slate-100 text-slate-600 px-4 py-3">এই পণ্যটি এখন স্টকে নেই।</p>
        @endif

        @if ($wa || $tel)
        <div class="mt-3 grid grid-cols-2 gap-3">
            @if ($wa)<a href="{{ $wa }}" target="_blank" rel="noopener" class="rounded-lg bg-[#25D366] hover:brightness-95 text-white py-2.5 text-center font-semibold">WhatsApp-এ অর্ডার</a>@endif
            @if ($tel)<a href="{{ $tel }}" class="rounded-lg border border-slate-300 hover:bg-slate-100 py-2.5 text-center font-semibold {{ $wa ? '' : 'col-span-2' }}">কল করুন</a>@endif
        </div>
        @endif
    </div>
</div>

<section class="mt-10 bg-white rounded-xl border border-slate-200 p-5 md:p-8">
    <h2 class="text-xl font-bold mb-4">পণ্যের বিবরণ</h2>
    @if ($product->description)
        <div class="leading-relaxed text-slate-700 whitespace-pre-line">{{ $product->description }}</div>
    @else
        <p class="text-slate-500">এই পণ্যের বিবরণ এখনো যোগ করা হয়নি।</p>
    @endif
    <dl class="mt-6 grid sm:grid-cols-3 gap-4 text-sm border-t border-slate-100 pt-4">
        @if ($product->weight)<div><dt class="text-slate-500">ওজন / পরিমাণ</dt><dd class="font-medium">{{ $product->weight }}</dd></div>@endif
        @if ($product->category)<div><dt class="text-slate-500">ক্যাটাগরি</dt><dd class="font-medium"><a href="{{ route('shop.category', $product->category) }}" class="text-brand">{{ $product->category->name }}</a></dd></div>@endif
        @if ($product->sku)<div><dt class="text-slate-500">পণ্যের কোড</dt><dd class="font-medium">{{ $product->sku }}</dd></div>@endif
    </dl>
</section>

@if ($suggested->isNotEmpty())
<section class="mt-12">
    <h2 class="text-xl font-bold mb-4">আপনার পছন্দ হতে পারে</h2>
    <div class="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-5">
        @foreach ($suggested as $p) @include('shop._card') @endforeach
    </div>
</section>
@endif
@endsection
