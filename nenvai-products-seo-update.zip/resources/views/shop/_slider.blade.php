{{-- ব্যবহার: @include('shop._slider', ['slides' => ..., 'sid' => 'top', 'ratio' => 'md:aspect-[16/6]']) --}}
@if ($slides->isNotEmpty())
<section id="{{ $sid }}Hero" class="relative mb-8 rounded-2xl overflow-hidden bg-slate-200" aria-roledescription="carousel">
    <div id="{{ $sid }}Track" class="flex transition-transform duration-500 ease-out">
        @foreach ($slides as $s)
        <div class="min-w-full relative aspect-[16/9] {{ $ratio }}">
            <img src="{{ $s->imageUrl() }}" alt="{{ $s->title }}" class="absolute inset-0 w-full h-full object-cover" @if (! $loop->first) loading="lazy" @endif>
            @if ($s->title || $s->subtitle || ($s->link && $s->button_text))
            <div class="absolute inset-0 bg-gradient-to-r from-black/60 via-black/25 to-transparent flex items-center">
                <div class="px-6 md:px-12 max-w-xl text-white">
                    @if ($s->title)<h2 class="text-2xl md:text-4xl font-bold leading-tight">{{ $s->title }}</h2>@endif
                    @if ($s->subtitle)<p class="mt-2 text-sm md:text-base text-white/90">{{ $s->subtitle }}</p>@endif
                    @if ($s->link)
                        <a href="{{ $s->link }}" class="inline-block mt-4 rounded-lg bg-white text-slate-900 hover:bg-slate-100 px-5 py-2 text-sm font-semibold">{{ $s->button_text ?: 'দেখুন' }}</a>
                    @endif
                </div>
            </div>
            @elseif ($s->link)
                <a href="{{ $s->link }}" class="absolute inset-0" aria-label="{{ $s->title ?: 'স্লাইড' }}"></a>
            @endif
        </div>
        @endforeach
    </div>

    @if ($slides->count() > 1)
    <button type="button" id="{{ $sid }}Prev" aria-label="আগেরটি" class="absolute left-3 top-1/2 -translate-y-1/2 h-9 w-9 rounded-full bg-white/85 hover:bg-white text-slate-800 shadow">‹</button>
    <button type="button" id="{{ $sid }}Next" aria-label="পরেরটি" class="absolute right-3 top-1/2 -translate-y-1/2 h-9 w-9 rounded-full bg-white/85 hover:bg-white text-slate-800 shadow">›</button>
    <div id="{{ $sid }}Dots" class="absolute bottom-3 left-0 right-0 flex justify-center gap-2">
        @foreach ($slides as $s)<button type="button" class="h-2 w-2 rounded-full bg-white/60" aria-label="স্লাইড {{ $loop->iteration }}"></button>@endforeach
    </div>
    <script>
    (function () {
        var id = '{{ $sid }}', track = document.getElementById(id + 'Track'), n = {{ $slides->count() }}, i = 0, timer = null;
        var dots = document.querySelectorAll('#' + id + 'Dots button');
        function go(k) {
            i = (k + n) % n;
            track.style.transform = 'translateX(-' + (i * 100) + '%)';
            dots.forEach(function (d, j) { d.style.background = j === i ? '#fff' : 'rgba(255,255,255,.55)'; });
        }
        function stop() { if (timer) { clearInterval(timer); timer = null; } }
        function play() {
            if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
            stop(); timer = setInterval(function () { go(i + 1); }, 5000);
        }
        document.getElementById(id + 'Prev').onclick = function () { go(i - 1); play(); };
        document.getElementById(id + 'Next').onclick = function () { go(i + 1); play(); };
        dots.forEach(function (d, j) { d.onclick = function () { go(j); play(); }; });
        var hero = document.getElementById(id + 'Hero');
        hero.addEventListener('mouseenter', stop); hero.addEventListener('mouseleave', play);
        go(0); play();
    })();
    </script>
    @endif
</section>
@endif
