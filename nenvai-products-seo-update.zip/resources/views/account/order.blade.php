@extends('layouts.app')
@section('robots', 'noindex,follow')
@section('title', $order->order_no)
@section('content')
<a href="{{ route('account') }}" class="text-sm text-brand">← আমার অর্ডার</a>
<h1 class="text-2xl font-bold mt-1 mb-6">{{ $order->order_no }}</h1>
<div class="grid lg:grid-cols-3 gap-6">
    <section class="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-5">
        <h2 class="font-semibold mb-3">পণ্য</h2>
        <ul class="divide-y divide-slate-100 text-sm">
            @foreach ($order->items as $it)
            <li class="py-2 flex justify-between"><span>{{ $it->name }} × {{ $it->qty }}</span><span>{{ config('shop.currency') }}{{ number_format($it->price * $it->qty) }}</span></li>
            @endforeach
            <li class="py-2 flex justify-between"><span>ডেলিভারি চার্জ</span><span>{{ $order->shipping > 0 ? config('shop.currency').number_format($order->shipping) : 'ফ্রি' }}</span></li>
            <li class="py-2 flex justify-between font-semibold"><span>মোট</span><span>{{ config('shop.currency') }}{{ number_format($order->total) }}</span></li>
        </ul>
        @if ($order->needsPayment())
            <a href="{{ route('payment.start', $order->order_no) }}" class="inline-block mt-4 rounded-lg bg-brand hover:bg-brand-dark text-white px-5 py-2 font-semibold">পেমেন্ট করুন</a>
        @endif
    </section>
    <section class="bg-white rounded-xl border border-slate-200 p-5 text-sm space-y-1 h-fit">
        <h2 class="font-semibold mb-2">অর্ডারের তথ্য</h2>
        <div>অবস্থা: <strong>{{ $order->statusLabel() }}</strong></div>
        <div>পেমেন্ট: {{ \App\Support\Payments::label($order->payment_method) }} ({{ ['paid' => 'পরিশোধিত', 'failed' => 'ব্যর্থ', 'unpaid' => 'বাকি'][$order->payment_status] ?? $order->payment_status }})</div>
        <div class="text-slate-600 pt-2">{{ $order->customer_name }}<br>{{ $order->phone }}<br>{{ $order->address }}, {{ $order->city }}</div>
        <div class="text-slate-400 pt-2">{{ $order->created_at->format('d M Y, h:i A') }}</div>
    </section>
</div>
@endsection
