@extends('layouts.app')
@section('robots', 'noindex,follow')
@section('title', 'আমার অ্যাকাউন্ট')
@section('content')
@php
    $in = 'mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-brand';
    $badge = ['pending' => 'bg-amber-100 text-amber-800', 'confirmed' => 'bg-sky-100 text-sky-800', 'shipped' => 'bg-indigo-100 text-indigo-800', 'delivered' => 'bg-green-100 text-green-800', 'cancelled' => 'bg-slate-200 text-slate-600'];
@endphp
<div class="flex flex-wrap items-center justify-between gap-3 mb-6">
    <div>
        <h1 class="text-2xl font-bold">আমার অ্যাকাউন্ট</h1>
        <p class="text-sm text-slate-500">{{ auth()->user()->name }} · {{ auth()->user()->phone }}</p>
    </div>
    <form method="POST" action="{{ route('logout') }}">@csrf
        <button class="rounded-lg border border-slate-300 hover:bg-slate-100 px-4 py-2 text-sm">লগআউট</button>
    </form>
</div>

<div class="grid lg:grid-cols-3 gap-6">
    <section class="lg:col-span-2 bg-white rounded-xl border border-slate-200">
        <h2 class="font-semibold p-5 pb-3">আমার অর্ডার</h2>
        <div class="overflow-x-auto">
        <table class="w-full text-sm">
            <thead class="text-left text-slate-500 border-b border-slate-100"><tr><th class="p-3 pl-5">অর্ডার</th><th class="p-3">তারিখ</th><th class="p-3">মোট</th><th class="p-3">অবস্থা</th></tr></thead>
            <tbody class="divide-y divide-slate-100">
            @forelse ($orders as $o)
                <tr>
                    <td class="p-3 pl-5"><a href="{{ route('account.order', $o->order_no) }}" class="text-brand font-medium">{{ $o->order_no }}</a></td>
                    <td class="p-3 whitespace-nowrap text-slate-500">{{ $o->created_at->format('d M Y') }}</td>
                    <td class="p-3">{{ config('shop.currency') }}{{ number_format($o->total) }}</td>
                    <td class="p-3"><span class="px-2 py-0.5 rounded-full text-xs {{ $badge[$o->status] ?? '' }}">{{ $o->statusLabel() }}</span></td>
                </tr>
            @empty
                <tr><td colspan="4" class="p-8 text-center text-slate-500">এখনো কোনো অর্ডার নেই। <a href="{{ route('shop.products') }}" class="text-brand">কেনাকাটা শুরু করুন</a></td></tr>
            @endforelse
            </tbody>
        </table>
        </div>
    </section>

    <section class="bg-white rounded-xl border border-slate-200 p-5 h-fit">
        <h2 class="font-semibold mb-3">আমার তথ্য</h2>
        <form method="POST" action="{{ route('account.update') }}" class="space-y-3 text-sm">
            @csrf @method('PUT')
            <label class="block"><span class="font-medium">নাম</span>
                <input name="name" value="{{ old('name', auth()->user()->name) }}" class="{{ $in }}">@error('name')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror</label>
            <label class="block"><span class="font-medium">ইমেইল</span>
                <input type="email" name="email" value="{{ old('email', auth()->user()->email) }}" class="{{ $in }}">@error('email')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror</label>
            <details class="rounded-lg border border-slate-200 p-3" {{ $errors->hasAny(['current_password', 'new_password']) ? 'open' : '' }}>
                <summary class="cursor-pointer font-medium">পাসওয়ার্ড বদলান</summary>
                <div class="mt-3 space-y-3">
                    <label class="block"><span>বর্তমান পাসওয়ার্ড</span><input type="password" name="current_password" class="{{ $in }}">@error('current_password')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror</label>
                    <label class="block"><span>নতুন পাসওয়ার্ড</span><input type="password" name="new_password" class="{{ $in }}">@error('new_password')<span class="text-red-600 text-xs">{{ $message }}</span>@enderror</label>
                    <label class="block"><span>নতুন পাসওয়ার্ড আবার</span><input type="password" name="new_password_confirmation" class="{{ $in }}"></label>
                </div>
            </details>
            <button class="w-full rounded-lg bg-brand hover:bg-brand-dark text-white py-2 font-medium">সেভ করুন</button>
        </form>
    </section>
</div>
@endsection
