<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        // পণ্য: কোড, ওজন, কেনা দাম, অফারের দাম, SEO
        if (! Schema::hasColumn('products', 'offer_price')) {
            Schema::table('products', function (Blueprint $t) {
                $t->decimal('offer_price', 10, 2)->nullable()->after('price');
            });
            // আগের "আগের দাম" ব্যবস্থা থেকে নতুন ব্যবস্থায়: নিয়মিত দাম = আগের দাম, অফারের দাম = এতদিনের বিক্রির দাম
            if (Schema::hasColumn('products', 'old_price')) {
                DB::table('products')->whereNotNull('old_price')->whereColumn('old_price', '>', 'price')
                    ->update(['offer_price' => DB::raw('price'), 'price' => DB::raw('old_price')]);
            }
        }
        if (! Schema::hasColumn('products', 'cost_price')) {
            Schema::table('products', fn (Blueprint $t) => $t->decimal('cost_price', 10, 2)->nullable()->after('price'));
        }
        if (! Schema::hasColumn('products', 'sku')) {
            Schema::table('products', fn (Blueprint $t) => $t->string('sku', 60)->nullable()->unique()->after('slug'));
        }
        if (! Schema::hasColumn('products', 'weight')) {
            Schema::table('products', fn (Blueprint $t) => $t->string('weight', 60)->nullable()->after('name'));
        }
        if (! Schema::hasColumn('products', 'meta_title')) {
            Schema::table('products', function (Blueprint $t) {
                $t->string('meta_title', 160)->nullable();
                $t->string('meta_description', 300)->nullable();
            });
        }

        // স্লাইডারের অবস্থান: top | middle | bottom
        if (! Schema::hasColumn('sliders', 'position')) {
            Schema::table('sliders', fn (Blueprint $t) => $t->string('position', 12)->default('top')->after('image'));
        }

        // অর্ডারের সময়ের কেনা দাম (মুনাফার হিসাবের জন্য)
        if (! Schema::hasColumn('order_items', 'cost_price')) {
            Schema::table('order_items', fn (Blueprint $t) => $t->decimal('cost_price', 10, 2)->nullable()->after('price'));
        }
    }

    public function down(): void
    {
        //
    }
};
