<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $guarded = [];
    protected $casts = ['is_active' => 'boolean'];

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function hasImage(): bool
    {
        return (bool) $this->image;
    }

    public function imageUrl(): string
    {
        return $this->image
            ? asset(str_starts_with($this->image, 'uploads/') ? $this->image : 'storage/' . $this->image)
            : 'data:image/svg+xml;utf8,' . rawurlencode('<svg xmlns="http://www.w3.org/2000/svg" width="400" height="400"><rect width="400" height="400" fill="#e4eceb"/><text x="200" y="210" text-anchor="middle" font-size="22" fill="#7f958f" font-family="sans-serif">ছবি নেই</text></svg>');
    }

    /** অফার চালু আছে কি (অফারের দাম নিয়মিত দামের চেয়ে কম হলে) */
    public function hasOffer(): bool
    {
        $o = (float) $this->offer_price;
        return $this->offer_price !== null && $o > 0 && $o < (float) $this->price;
    }

    /** গ্রাহক যে দামে কিনবে */
    public function currentPrice(): float
    {
        return $this->hasOffer() ? (float) $this->offer_price : (float) $this->price;
    }

    public function discountPercent(): int
    {
        return $this->hasOffer() ? (int) round((1 - (float) $this->offer_price / (float) $this->price) * 100) : 0;
    }

    /** প্রতি পিসে মুনাফা (কেনা দাম দেওয়া থাকলে) */
    public function profitPerUnit(): ?float
    {
        return $this->cost_price !== null ? $this->currentPrice() - (float) $this->cost_price : null;
    }

    public function seoTitle(): string
    {
        return $this->meta_title ?: trim($this->name . ' ' . $this->weight);
    }

    public function seoDescription(): string
    {
        if ($this->meta_description) return $this->meta_description;
        $text = trim(preg_replace('/\s+/u', ' ', strip_tags((string) $this->description)));
        if ($text !== '') return mb_strimwidth($text, 0, 155, '…');
        return trim($this->name . ' ' . $this->weight) . ' — ' . config('shop.name') . ' থেকে অনলাইনে অর্ডার করুন। ক্যাশ অন ডেলিভারি।';
    }
}
