<?php
namespace App\Support;

use App\Models\Product;

class Cart
{
    public static function raw(): array
    {
        return session('cart', []);
    }

    public static function add(int $id, int $qty = 1): void
    {
        $cart = self::raw();
        $cart[$id] = ($cart[$id] ?? 0) + $qty;
        session(['cart' => $cart]);
    }

    public static function set(int $id, int $qty): void
    {
        $cart = self::raw();
        if ($qty <= 0) unset($cart[$id]); else $cart[$id] = $qty;
        session(['cart' => $cart]);
    }

    public static function clear(): void
    {
        session()->forget('cart');
    }

    public static function count(): int
    {
        return array_sum(self::raw());
    }

    public static function items()
    {
        $raw = self::raw();
        return Product::whereIn('id', array_keys($raw))->where('is_active', true)->get()
            ->map(function ($p) use ($raw) {
                $q = min($raw[$p->id], max($p->stock, 0));
                return ['product' => $p, 'qty' => $q, 'line' => $p->currentPrice() * $q];
            })->filter(fn ($i) => $i['qty'] > 0)->values();
    }

    public static function subtotal(): float
    {
        return (float) self::items()->sum('line');
    }

    public static function shipping(float $subtotal): float
    {
        if ($subtotal <= 0 || $subtotal >= config('shop.free_shipping_over')) return 0;
        return (float) config('shop.shipping_fee');
    }
}
