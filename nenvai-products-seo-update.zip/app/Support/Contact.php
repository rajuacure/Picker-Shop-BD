<?php
namespace App\Support;

use App\Models\Setting;

class Contact
{
    /** WhatsApp নম্বর আন্তর্জাতিক রূপে (8801XXXXXXXXX), না থাকলে ফোন নম্বর */
    public static function whatsappDigits(): ?string
    {
        $d = preg_replace('/\D/', '', Setting::get('whatsapp') ?: Setting::get('phone'));
        if ($d === '') return null;
        if (strlen($d) === 11 && str_starts_with($d, '01')) $d = '88' . $d;
        return $d;
    }

    public static function whatsappLink(?string $text = null): ?string
    {
        $n = self::whatsappDigits();
        if (! $n) return null;
        return 'https://wa.me/' . $n . ($text ? '?text=' . rawurlencode($text) : '');
    }

    public static function phone(): ?string
    {
        return Setting::get('phone') ?: null;
    }

    public static function telLink(): ?string
    {
        $p = self::phone();
        return $p ? 'tel:' . preg_replace('/[^\d+]/', '', $p) : null;
    }
}
