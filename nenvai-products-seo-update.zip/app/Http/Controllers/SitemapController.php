<?php
namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Page;
use App\Models\Product;

class SitemapController extends Controller
{
    public function __invoke()
    {
        $urls = [[url('/'), null, '1.0']];
        $urls[] = [route('shop.products'), null, '0.8'];

        foreach (Category::where('is_active', true)->get() as $c) {
            $urls[] = [route('shop.category', $c), $c->updated_at, '0.7'];
        }
        foreach (Product::where('is_active', true)->get() as $p) {
            $urls[] = [route('shop.show', $p), $p->updated_at, '0.9'];
        }
        foreach (Page::where('is_active', true)->get() as $pg) {
            $urls[] = [route('page.show', $pg->slug), $pg->updated_at, '0.3'];
        }

        $xml = '<' . '?xml version="1.0" encoding="UTF-8"?>' . "\n" . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
        foreach ($urls as [$loc, $mod, $prio]) {
            $xml .= '  <url><loc>' . htmlspecialchars($loc, ENT_XML1) . '</loc>'
                . ($mod ? '<lastmod>' . $mod->toAtomString() . '</lastmod>' : '')
                . '<priority>' . $prio . '</priority></url>' . "\n";
        }
        $xml .= '</urlset>';

        return response($xml, 200, ['Content-Type' => 'application/xml; charset=UTF-8']);
    }
}
