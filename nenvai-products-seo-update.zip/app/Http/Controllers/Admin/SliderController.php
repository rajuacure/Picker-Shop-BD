<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Slider;
use App\Support\Uploader;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class SliderController extends Controller
{
    public function index()
    {
        $sliders = Slider::orderBy('sort_order')->orderByDesc('id')->get();
        return view('admin.sliders.index', compact('sliders'));
    }

    public function create()
    {
        return view('admin.sliders.form', ['slider' => new Slider(['is_active' => true, 'sort_order' => 0, 'position' => 'top'])]);
    }

    public function store(Request $request)
    {
        $data = $this->validated($request, true);
        $data['image'] = Uploader::save($request->file('image'), 'sliders');
        Slider::create($data);
        return redirect()->route('admin.sliders.index')->with('success', 'স্লাইড যোগ হয়েছে।');
    }

    public function edit(Slider $slider)
    {
        return view('admin.sliders.form', compact('slider'));
    }

    public function update(Request $request, Slider $slider)
    {
        $data = $this->validated($request, false);
        if ($request->hasFile('image')) {
            Uploader::delete($slider->image);
            $data['image'] = Uploader::save($request->file('image'), 'sliders');
        }
        $slider->update($data);
        return redirect()->route('admin.sliders.index')->with('success', 'স্লাইড আপডেট হয়েছে।');
    }

    public function destroy(Slider $slider)
    {
        Uploader::delete($slider->image);
        $slider->delete();
        return back()->with('success', 'স্লাইড মুছে ফেলা হয়েছে।');
    }

    private function validated(Request $request, bool $imageRequired): array
    {
        $data = $request->validate([
            'image'       => [$imageRequired ? 'required' : 'nullable', 'file', 'max:2048'],
            'title'       => 'nullable|string|max:120',
            'subtitle'    => 'nullable|string|max:200',
            'button_text' => 'nullable|string|max:40',
            'link'        => ['nullable', 'string', 'max:255', 'regex:/^(https?:\/\/|\/)/'],
            'position'    => ['required', Rule::in(['top', 'middle', 'bottom'])],
            'sort_order'  => 'nullable|integer|min:0|max:9999',
        ], [
            'link.regex' => 'লিংক / দিয়ে (যেমন /product/panjabi) অথবা https:// দিয়ে শুরু হতে হবে।',
            'image.required' => 'স্লাইডের ছবি দিতে হবে।',
        ]);
        unset($data['image']);
        $data['sort_order'] = (int) ($data['sort_order'] ?? 0);
        $data['is_active'] = $request->boolean('is_active');
        return $data;
    }
}
