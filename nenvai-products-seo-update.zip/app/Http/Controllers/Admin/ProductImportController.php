<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class ProductImportController extends Controller
{
    private const COLUMNS = ['name', 'sku', 'category', 'weight', 'cost_price', 'price', 'offer_price', 'stock', 'description', 'is_active'];

    /** বাংলা/বিকল্প কলামের নাম → আসল নাম */
    private const ALIASES = [
        'name' => 'name', 'product' => 'name', 'title' => 'name', 'নাম' => 'name', 'পণ্যের_নাম' => 'name',
        'sku' => 'sku', 'code' => 'sku', 'কোড' => 'sku',
        'category' => 'category', 'ক্যাটাগরি' => 'category',
        'weight' => 'weight', 'ওজন' => 'weight', 'size' => 'weight',
        'cost_price' => 'cost_price', 'cost' => 'cost_price', 'buying_price' => 'cost_price', 'কেনা_দাম' => 'cost_price',
        'price' => 'price', 'selling_price' => 'price', 'regular_price' => 'price', 'বিক্রি_দাম' => 'price', 'বিক্রির_দাম' => 'price',
        'offer_price' => 'offer_price', 'offer' => 'offer_price', 'sale_price' => 'offer_price', 'অফার_দাম' => 'offer_price', 'অফারের_দাম' => 'offer_price',
        'stock' => 'stock', 'quantity' => 'stock', 'qty' => 'stock', 'স্টক' => 'stock',
        'description' => 'description', 'বিবরণ' => 'description',
        'is_active' => 'is_active', 'active' => 'is_active', 'status' => 'is_active', 'চালু' => 'is_active',
    ];

    public function form()
    {
        return view('admin.import', ['report' => session('import_report')]);
    }

    public function sample()
    {
        return $this->csvDownload('products-sample.csv', [
            ['সুন্দরবনের খাঁটি মধু', 'HONEY-500', 'Honey', '৫০০ গ্রাম', 450, 650, 590, 25, 'সুন্দরবনের খাঁটি ও প্রাকৃতিক মধু।', 1],
            ['কারি পাতা গুঁড়া', 'CURRY-100', 'Herbs', '১০০ গ্রাম', 60, 120, '', 40, 'ঘরে তৈরি কারি পাতার গুঁড়া।', 1],
        ]);
    }

    public function export()
    {
        $rows = Product::with('category')->orderBy('id')->get()->map(fn ($p) => [
            $p->name, $p->sku, $p->category->name ?? '', $p->weight, $p->cost_price, $p->price, $p->offer_price, $p->stock,
            $p->description, $p->is_active ? 1 : 0,
        ])->all();
        return $this->csvDownload('products-' . now()->format('Ymd') . '.csv', $rows);
    }

    public function run(Request $request)
    {
        $request->validate(['csv' => 'required|file|max:2048'], ['csv.required' => 'একটি CSV ফাইল বেছে নিন।']);
        $file = $request->file('csv');
        if (! in_array(strtolower($file->getClientOriginalExtension()), ['csv', 'txt'], true)) {
            return back()->withErrors(['csv' => 'শুধু .csv ফাইল দেওয়া যাবে।']);
        }

        $content = (string) file_get_contents($file->getRealPath());
        $content = preg_replace('/^\xEF\xBB\xBF/', '', $content);
        if (! mb_check_encoding($content, 'UTF-8')) {
            return back()->withErrors(['csv' => 'ফাইলটি UTF-8 এনকোডিংয়ে সেভ করা নেই। Excel-এ "Save As → CSV UTF-8" বেছে সেভ করুন।']);
        }

        $stream = fopen('php://temp', 'r+');
        fwrite($stream, $content);
        rewind($stream);
        $firstLine = (string) fgets($stream);
        rewind($stream);
        $delim = substr_count($firstLine, "\t") > substr_count($firstLine, ',') ? "\t" : (substr_count($firstLine, ';') > substr_count($firstLine, ',') ? ';' : ',');

        $header = fgetcsv($stream, 0, $delim);
        if (! $header) return back()->withErrors(['csv' => 'ফাইলটি ফাঁকা।']);

        $map = [];
        foreach ($header as $i => $h) {
            $key = str_replace([' ', '-'], '_', mb_strtolower(trim($h)));
            if (isset(self::ALIASES[$key])) $map[self::ALIASES[$key]] = $i;
        }
        if (! isset($map['name']) || ! isset($map['price'])) {
            return back()->withErrors(['csv' => 'প্রথম সারিতে কমপক্ষে "name" ও "price" কলাম থাকতে হবে। নমুনা ফাইল ডাউনলোড করে দেখুন।']);
        }

        $created = $updated = 0;
        $errors = [];
        $row = 1;
        while (($cells = fgetcsv($stream, 0, $delim)) !== false) {
            $row++;
            if ($row > 1001) { $errors[] = 'একবারে সর্বোচ্চ ১০০০টি সারি নেওয়া হয়; বাকিগুলো বাদ গেছে।'; break; }
            if (count(array_filter($cells, fn ($c) => trim((string) $c) !== '')) === 0) continue;

            $get = fn ($k) => isset($map[$k]) ? trim((string) ($cells[$map[$k]] ?? '')) : null;
            $num = function ($v) {
                if ($v === null || $v === '') return null;
                $v = strtr($v, ['০' => 0, '১' => 1, '২' => 2, '৩' => 3, '৪' => 4, '৫' => 5, '৬' => 6, '৭' => 7, '৮' => 8, '৯' => 9]);
                $v = preg_replace('/[^\d.]/', '', $v);
                return $v === '' ? null : (float) $v;
            };

            $name = $get('name');
            $price = $num($get('price'));
            if ($name === null || $name === '') { $errors[] = "সারি $row: পণ্যের নাম নেই।"; continue; }
            if ($price === null) { $errors[] = "সারি $row ($name): বিক্রির দাম নেই বা ভুল।"; continue; }
            $offer = $num($get('offer_price'));
            if ($offer !== null && $offer >= $price) { $errors[] = "সারি $row ($name): অফারের দাম বিক্রির দামের কম হতে হবে।"; continue; }

            $sku = $get('sku') ?: null;
            $product = ($sku ? Product::where('sku', $sku)->first() : null) ?? Product::where('name', $name)->first();
            $isNew = ! $product;
            $product ??= new Product();

            $data = ['name' => $name, 'price' => $price];
            if (isset($map['offer_price'])) $data['offer_price'] = $offer;       // ফাঁকা = অফার নেই
            if (isset($map['cost_price']) && $get('cost_price') !== '') $data['cost_price'] = $num($get('cost_price'));
            if (isset($map['sku']) && $sku) $data['sku'] = $sku;
            if (isset($map['weight']) && $get('weight') !== '') $data['weight'] = $get('weight');
            if (isset($map['description']) && $get('description') !== '') $data['description'] = $get('description');
            if (isset($map['stock']) && $get('stock') !== '') $data['stock'] = (int) $num($get('stock'));
            elseif ($isNew) $data['stock'] = 0;
            if (isset($map['is_active']) && $get('is_active') !== '') {
                $data['is_active'] = ! in_array(mb_strtolower($get('is_active')), ['0', 'no', 'false', 'না', 'inactive', 'বন্ধ'], true);
            } elseif ($isNew) $data['is_active'] = true;

            if (isset($map['category']) && $get('category') !== '') {
                $catName = $get('category');
                $cat = Category::whereRaw('LOWER(name) = ?', [mb_strtolower($catName)])->first()
                    ?? Category::create(['name' => $catName, 'slug' => $this->uniqueSlug(Category::class, $catName, 'category'), 'is_active' => true, 'sort_order' => 0]);
                $data['category_id'] = $cat->id;
            }

            if ($isNew) $data['slug'] = $this->uniqueSlug(Product::class, $sku ?: $name, 'product');

            try {
                $product->fill($data)->save();
                $isNew ? $created++ : $updated++;
            } catch (\Throwable $e) {
                report($e);
                $errors[] = "সারি $row ($name): সেভ করা যায়নি।";
            }
        }
        fclose($stream);

        return redirect()->route('admin.import.form')->with('import_report', [
            'created' => $created, 'updated' => $updated, 'errors' => array_slice($errors, 0, 30), 'error_count' => count($errors),
        ]);
    }

    private function uniqueSlug(string $model, string $source, string $fallback): string
    {
        $base = Str::slug($source) ?: $fallback;
        $slug = $base; $i = 2;
        while ($model::where('slug', $slug)->exists()) $slug = $base . '-' . $i++;
        return $slug;
    }

    private function csvDownload(string $filename, array $rows)
    {
        return response()->streamDownload(function () use ($rows) {
            $out = fopen('php://output', 'w');
            fwrite($out, "\xEF\xBB\xBF"); // Excel-এ বাংলা ঠিক দেখানোর জন্য
            fputcsv($out, self::COLUMNS);
            foreach ($rows as $r) fputcsv($out, $r);
            fclose($out);
        }, $filename, ['Content-Type' => 'text/csv; charset=UTF-8']);
    }
}
