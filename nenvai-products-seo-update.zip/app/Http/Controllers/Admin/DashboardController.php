<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;

class DashboardController extends Controller
{
    public function __invoke()
    {
        $valid = fn ($q) => $q->where('status', '!=', 'cancelled');

        $stats = [
            'today_orders'  => Order::whereDate('created_at', today())->count(),
            'today_revenue' => (float) Order::whereDate('created_at', today())->where('status', '!=', 'cancelled')->sum('total'),
            'month_revenue' => (float) Order::where('created_at', '>=', now()->startOfMonth())->where('status', '!=', 'cancelled')->sum('total'),
            'pending'       => Order::where('status', 'pending')->count(),
            'today_profit'  => $this->profit(today()->startOfDay()),
            'month_profit'  => $this->profit(now()->startOfMonth()),
        ];

        // গত ৭ দিনের বিক্রি
        $days = collect(range(6, 0))->map(function ($i) {
            $d = today()->subDays($i);
            return [
                'label' => $d->format('d M'),
                'total' => (float) Order::whereDate('created_at', $d)->where('status', '!=', 'cancelled')->sum('total'),
            ];
        });

        $recent   = Order::latest()->take(8)->get();
        $lowStock = Product::where('is_active', true)->where('stock', '<=', 5)->orderBy('stock')->take(6)->get();

        return view('admin.dashboard', compact('stats', 'days', 'recent', 'lowStock'));
    }

    /** কেনা দাম দেওয়া পণ্যের মুনাফা (ডেলিভারি চার্জ বাদে) */
    private function profit($from): float
    {
        return (float) OrderItem::join('orders', 'orders.id', '=', 'order_items.order_id')
            ->where('orders.status', '!=', 'cancelled')
            ->where('orders.created_at', '>=', $from)
            ->whereNotNull('order_items.cost_price')
            ->sum(\Illuminate\Support\Facades\DB::raw('(order_items.price - order_items.cost_price) * order_items.qty'));
    }
}
