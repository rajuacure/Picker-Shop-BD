<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Product;
use App\Support\Uploader;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class ProductController extends Controller
{
    public function index(Request $request)
    {
        $products = Product::with('category')
            ->when($request->q, fn ($q, $s) => $q->where(fn ($w) => $w->where('name', 'like', "%$s%")->orWhere('sku', 'like', "%$s%")))
            ->latest()->paginate(20)->withQueryString();
        return view('admin.products.index', compact('products'));
    }

    public function create()
    {
        return view('admin.products.form', ['product' => new Product(['is_active' => true]), 'categories' => $this->categories()]);
    }

    public function store(Request $request)
    {
        $data = $this->validated($request);
        $data['slug'] = ! empty($data['slug']) ? $data['slug'] : $this->uniqueSlug($data['name']);
        Product::create($data);
        return redirect()->route('admin.products.index')->with('success', 'পণ্য যোগ হয়েছে।');
    }

    public function edit(Product $product)
    {
        return view('admin.products.form', ['product' => $product, 'categories' => $this->categories()]);
    }

    public function update(Request $request, Product $product)
    {
        $data = $this->validated($request, $product);
        if (empty($data['slug'])) unset($data['slug']);
        if (isset($data['image'])) Uploader::delete($product->image);
        $product->update($data);
        return redirect()->route('admin.products.index')->with('success', 'পণ্য আপডেট হয়েছে।');
    }

    public function destroy(Product $product)
    {
        Uploader::delete($product->image);
        $product->delete();
        return back()->with('success', 'পণ্য মুছে ফেলা হয়েছে।');
    }

    private function validated(Request $request, ?Product $product = null): array
    {
        $data = $request->validate([
            'name'             => 'required|string|max:150',
            'slug'             => ['nullable', 'regex:/^[a-z0-9-]+$/', 'max:120', Rule::unique('products', 'slug')->ignore($product?->id)],
            'sku'              => ['nullable', 'string', 'max:60', Rule::unique('products', 'sku')->ignore($product?->id)],
            'category_id'      => 'nullable|exists:categories,id',
            'weight'           => 'nullable|string|max:60',
            'description'      => 'nullable|string',
            'cost_price'       => 'nullable|numeric|min:0',
            'price'            => 'required|numeric|min:0',
            'offer_price'      => 'nullable|numeric|min:0|lt:price',
            'stock'            => 'required|integer|min:0',
            'meta_title'       => 'nullable|string|max:160',
            'meta_description' => 'nullable|string|max:300',
            'image'            => 'nullable|file|max:2048',
        ], [
            'slug.regex'      => 'লিংক শুধু ইংরেজি ছোট হাতের অক্ষর, সংখ্যা ও - দিয়ে লিখুন (যেমন raw-honey-500g)।',
            'slug.unique'     => 'এই লিংক আরেকটি পণ্যে আছে।',
            'sku.unique'      => 'এই কোড আরেকটি পণ্যে আছে।',
            'offer_price.lt'  => 'অফারের দাম বিক্রির দামের চেয়ে কম হতে হবে।',
        ]);

        // ফাঁকা ঘর null হিসেবে সেভ হবে
        foreach (['sku', 'weight', 'cost_price', 'offer_price', 'meta_title', 'meta_description', 'slug'] as $k) {
            if (($data[$k] ?? null) === '' || ! array_key_exists($k, $data)) $data[$k] = null;
        }
        $data['is_active'] = $request->boolean('is_active');
        if ($request->hasFile('image')) {
            $data['image'] = Uploader::save($request->file('image'), 'products');
        } else {
            unset($data['image']);
        }
        return $data;
    }

    private function categories()
    {
        return Category::orderBy('sort_order')->orderBy('name')->get();
    }

    private function uniqueSlug(string $name): string
    {
        $base = Str::slug($name) ?: 'product';
        $slug = $base; $i = 2;
        while (Product::where('slug', $slug)->exists()) $slug = $base . '-' . $i++;
        return $slug;
    }
}
