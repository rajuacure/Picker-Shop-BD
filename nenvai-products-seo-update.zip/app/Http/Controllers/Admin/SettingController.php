<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use App\Support\Uploader;
use Illuminate\Http\Request;

class SettingController extends Controller
{
    private const TEXT_FIELDS = ['topbar_text', 'footer_about', 'address', 'phone', 'email', 'whatsapp', 'hours', 'facebook', 'instagram', 'youtube', 'site_description'];

    public function edit()
    {
        return view('admin.settings');
    }

    public function update(Request $request)
    {
        $data = $request->validate([
            'shop_name'          => 'required|string|max:60',
            'brand_color'        => ['required', 'regex:/^#[0-9a-fA-F]{6}$/'],
            'logo_height'        => 'required|integer|min:20|max:140',
            'shipping_fee'       => 'required|integer|min:0|max:100000',
            'free_shipping_over' => 'required|integer|min:0|max:10000000',
            'logo'               => 'nullable|file|max:2048',
            'topbar_text'        => 'nullable|string|max:200',
            'site_description'   => 'nullable|string|max:300',
            'footer_about'       => 'nullable|string|max:500',
            'address'            => 'nullable|string|max:300',
            'phone'              => 'nullable|string|max:40',
            'email'              => 'nullable|email|max:120',
            'whatsapp'           => 'nullable|string|max:20',
            'hours'              => 'nullable|string|max:120',
            'facebook'           => 'nullable|url|max:255',
            'instagram'          => 'nullable|url|max:255',
            'youtube'            => 'nullable|url|max:255',
        ], [
            'brand_color.regex' => 'রঙের কোড #0f6b5c এর মতো হতে হবে।',
            'facebook.url'      => 'পুরো লিংক দিন (https:// দিয়ে শুরু)।',
            'instagram.url'     => 'পুরো লিংক দিন (https:// দিয়ে শুরু)।',
            'youtube.url'       => 'পুরো লিংক দিন (https:// দিয়ে শুরু)।',
        ]);

        foreach (['shop_name', 'brand_color', 'logo_height', 'shipping_fee', 'free_shipping_over'] as $k) {
            Setting::put($k, (string) $data[$k]);
        }
        foreach (self::TEXT_FIELDS as $k) {
            Setting::put($k, (string) ($data[$k] ?? ''));
        }

        Setting::put('show_nav_categories', $request->boolean('show_nav_categories') ? '1' : '0');

        $old = config('shop.logo');
        if ($request->hasFile('logo')) {
            $new = Uploader::save($request->file('logo'), 'branding', 'logo', ['jpg', 'jpeg', 'png', 'webp', 'gif', 'svg']);
            Uploader::delete($old);
            Setting::put('logo', $new);
        } elseif ($request->boolean('remove_logo')) {
            Uploader::delete($old);
            Setting::put('logo', '');
        }

        return redirect()->route('admin.settings.edit')->with('success', 'সেটিংস সেভ হয়েছে।');
    }
}
