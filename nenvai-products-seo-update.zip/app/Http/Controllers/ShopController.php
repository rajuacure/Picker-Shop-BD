<?php
namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use App\Models\Slider;
use Illuminate\Http\Request;

class ShopController extends Controller
{
    /** হোম পেজ */
    public function index()
    {
        $sliders = $categories = $deals = collect();
        try {
            $sliders    = Slider::where('is_active', true)->orderBy('sort_order')->orderByDesc('id')->get();
            $categories = Category::where('is_active', true)->orderBy('sort_order')->orderBy('name')->get();
            $deals      = Product::with('category')->where('is_active', true)->whereNotNull('offer_price')
                            ->whereColumn('offer_price', '<', 'price')->latest()->take(4)->get();
        } catch (\Throwable $e) {
            // migrate না হয়ে থাকলে এই অংশগুলো ছাড়াই দোকান চলবে
        }
        $latest = Product::with('category')->where('is_active', true)->latest()->take(8)->get();

        return view('shop.index', compact('sliders', 'categories', 'deals', 'latest'));
    }

    /** সব পণ্য / সার্চ */
    public function products(Request $request)
    {
        return $this->listing($request, null, $request->q ? '"' . $request->q . '" এর ফলাফল' : 'সব পণ্য');
    }

    public function category(Request $request, Category $category)
    {
        abort_unless($category->is_active, 404);
        return $this->listing($request, $category, $category->name);
    }

    public function show(Product $product)
    {
        abort_unless($product->is_active, 404);
        $product->load('category');

        // সাজেশন: একই ক্যাটাগরির পণ্য আগে, তারপর নতুন পণ্য
        $suggested = Product::with('category')->where('is_active', true)->whereKeyNot($product->id)
            ->when($product->category_id, fn ($q) => $q->orderByRaw('category_id = ? desc', [$product->category_id]))
            ->latest()->take(8)->get();

        return view('shop.show', compact('product', 'suggested'));
    }

    private function listing(Request $request, ?Category $category, string $title)
    {
        $sort = in_array($request->query('sort'), ['price_asc', 'price_desc', 'name'], true) ? $request->query('sort') : 'new';
        $effective = 'COALESCE(CASE WHEN offer_price < price THEN offer_price END, price)';

        $products = Product::with('category')->where('is_active', true)
            ->when($category, fn ($q) => $q->where('category_id', $category->id))
            ->when($request->q, fn ($q, $s) => $q->where('name', 'like', "%{$s}%"))
            ->when($sort === 'price_asc', fn ($q) => $q->orderByRaw($effective . ' asc'))
            ->when($sort === 'price_desc', fn ($q) => $q->orderByRaw($effective . ' desc'))
            ->when($sort === 'name', fn ($q) => $q->orderBy('name'))
            ->when($sort === 'new', fn ($q) => $q->latest())
            ->paginate(12)->withQueryString();

        return view('shop.listing', compact('products', 'category', 'title', 'sort'));
    }
}
