<?php
namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Product;
use App\Support\Cart;
use App\Support\Payments;
use Illuminate\Validation\Rule;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class CheckoutController extends Controller
{
    public function show()
    {
        $items = Cart::items();
        if ($items->isEmpty()) {
            return redirect()->route('cart.index');
        }
        $subtotal = $items->sum('line');
        $shipping = Cart::shipping($subtotal);
        $prefill = [];
        if ($user = auth()->user()) {
            $last = $user->orders()->latest()->first();
            $prefill = [
                'customer_name' => $user->name, 'phone' => $user->phone, 'email' => $user->email,
                'address' => $last->address ?? '', 'city' => $last->city ?? '',
            ];
        }
        return view('checkout.index', compact('items', 'subtotal', 'shipping', 'prefill'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'customer_name' => 'required|string|max:100',
            'phone'         => ['required', 'regex:/^(\+?88)?01[3-9]\d{8}$/'],
            'email'         => 'nullable|email',
            'address'       => 'required|string|max:300',
            'city'          => 'required|string|max:80',
            'note'          => 'nullable|string|max:300',
            'payment_method' => ['required', Rule::in(array_keys(Payments::methods()))],
        ], [
            'phone.regex' => 'সঠিক মোবাইল নম্বর দিন (যেমন 01712345678)।',
        ]);

        $order = DB::transaction(function () use ($data) {
            $raw = Cart::raw();
            $products = Product::whereIn('id', array_keys($raw))->where('is_active', true)->lockForUpdate()->get();
            if ($products->isEmpty()) {
                throw ValidationException::withMessages(['cart' => 'আপনার কার্ট খালি।']);
            }

            $subtotal = 0;
            foreach ($products as $p) {
                if ($p->stock < $raw[$p->id]) {
                    throw ValidationException::withMessages([
                        'cart' => "\"{$p->name}\" এর মাত্র {$p->stock} টি স্টকে আছে। কার্ট আপডেট করুন।",
                    ]);
                }
                $subtotal += $p->currentPrice() * $raw[$p->id];
            }
            $shipping = Cart::shipping($subtotal);

            $order = Order::create($data + [
                'user_id'  => auth()->id(),
                'order_no' => 'ORD-' . now()->format('ymd') . '-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 5)),
                'subtotal' => $subtotal,
                'shipping' => $shipping,
                'total'    => $subtotal + $shipping,
            ]);

            foreach ($products as $p) {
                $order->items()->create([
                    'product_id' => $p->id,
                    'name'       => $p->name,
                    'price'      => $p->currentPrice(),
                    'cost_price' => $p->cost_price,
                    'qty'        => $raw[$p->id],
                ]);
                $p->decrement('stock', $raw[$p->id]);
            }
            return $order;
        });

        Cart::clear();

        // অনলাইন পেমেন্ট হলে সরাসরি গেটওয়েতে পাঠানো হয়
        return $order->isOnline()
            ? redirect()->route('payment.start', $order->order_no)
            : redirect()->route('checkout.success', $order->order_no);
    }

    public function success(string $orderNo)
    {
        $order = Order::with('items')->where('order_no', $orderNo)->firstOrFail();
        return view('checkout.success', compact('order'));
    }
}
