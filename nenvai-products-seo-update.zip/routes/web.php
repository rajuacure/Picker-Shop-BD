<?php
use App\Http\Controllers\Admin;
use App\Http\Controllers\AccountController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\CheckoutController;
use App\Http\Controllers\CustomerAuthController;
use App\Http\Controllers\PageController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\ShopController;
use App\Http\Controllers\SitemapController;
use App\Http\Middleware\AdminOnly;
use Illuminate\Support\Facades\Route;

// দোকান
Route::get('/sitemap.xml', SitemapController::class)->name('sitemap');
Route::get('/', [ShopController::class, 'index'])->name('shop.index');
Route::get('/products', [ShopController::class, 'products'])->name('shop.products');
Route::get('/category/{category:slug}', [ShopController::class, 'category'])->name('shop.category');
Route::get('/product/{product:slug}', [ShopController::class, 'show'])->name('shop.show');
Route::get('/page/{page:slug}', [PageController::class, 'show'])->name('page.show');

// কাস্টমার অ্যাকাউন্ট
Route::get('/login', [CustomerAuthController::class, 'loginForm'])->name('login');
Route::post('/login', [CustomerAuthController::class, 'login'])->middleware('throttle:10,1');
Route::get('/register', [CustomerAuthController::class, 'registerForm'])->name('register');
Route::post('/register', [CustomerAuthController::class, 'register'])->middleware('throttle:10,1');
Route::post('/logout', [CustomerAuthController::class, 'logout'])->name('logout');
Route::middleware('auth')->group(function () {
    Route::get('/account', [AccountController::class, 'index'])->name('account');
    Route::put('/account', [AccountController::class, 'update'])->name('account.update');
    Route::get('/account/orders/{orderNo}', [AccountController::class, 'order'])->name('account.order');
});

// কার্ট
Route::get('/cart', [CartController::class, 'index'])->name('cart.index');
Route::post('/cart/add/{product}', [CartController::class, 'add'])->name('cart.add');
Route::patch('/cart/{product}', [CartController::class, 'update'])->name('cart.update');
Route::delete('/cart/{product}', [CartController::class, 'remove'])->name('cart.remove');

// চেকআউট
Route::get('/checkout', [CheckoutController::class, 'show'])->name('checkout.show');
Route::post('/checkout', [CheckoutController::class, 'store'])->name('checkout.store');
Route::get('/order/{orderNo}/success', [CheckoutController::class, 'success'])->name('checkout.success');

// পেমেন্ট (গেটওয়ের কলব্যাকে CSRF টোকেন থাকে না — README দেখুন)
Route::get('/pay/{orderNo}', [PaymentController::class, 'start'])->name('payment.start');
Route::match(['get', 'post'], '/payment/ssl/success', [PaymentController::class, 'sslSuccess'])->name('payment.ssl.success');
Route::match(['get', 'post'], '/payment/ssl/fail', [PaymentController::class, 'sslFail'])->name('payment.ssl.fail');
Route::match(['get', 'post'], '/payment/ssl/cancel', [PaymentController::class, 'sslCancel'])->name('payment.ssl.cancel');
Route::post('/payment/ssl/ipn', [PaymentController::class, 'sslIpn'])->name('payment.ssl.ipn');
Route::get('/payment/bkash/{orderNo}', [PaymentController::class, 'bkashCallback'])->name('payment.bkash.callback');

// অ্যাডমিন
Route::prefix('admin')->name('admin.')->group(function () {
    Route::get('login', [Admin\AuthController::class, 'form'])->name('login');
    Route::post('login', [Admin\AuthController::class, 'login'])->middleware('throttle:5,1');
    Route::post('logout', [Admin\AuthController::class, 'logout'])->name('logout');

    Route::middleware(AdminOnly::class)->group(function () {
        Route::get('/', Admin\DashboardController::class)->name('dashboard');
        Route::resource('products', Admin\ProductController::class)->except('show');
        Route::resource('categories', Admin\CategoryController::class)->except('show');
        Route::resource('sliders', Admin\SliderController::class)->except('show');
        Route::resource('pages', Admin\PageController::class)->except('show');
        Route::get('import', [Admin\ProductImportController::class, 'form'])->name('import.form');
        Route::post('import', [Admin\ProductImportController::class, 'run'])->name('import.run');
        Route::get('import/sample', [Admin\ProductImportController::class, 'sample'])->name('import.sample');
        Route::get('export', [Admin\ProductImportController::class, 'export'])->name('export');
        Route::get('settings', [Admin\SettingController::class, 'edit'])->name('settings.edit');
        Route::post('settings', [Admin\SettingController::class, 'update'])->name('settings.update');
        Route::get('orders', [Admin\OrderController::class, 'index'])->name('orders.index');
        Route::get('orders/{order}', [Admin\OrderController::class, 'show'])->name('orders.show');
        Route::patch('orders/{order}/status', [Admin\OrderController::class, 'updateStatus'])->name('orders.status');
    });
});
