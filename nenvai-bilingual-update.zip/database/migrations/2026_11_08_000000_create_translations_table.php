<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (! Schema::hasTable('translations')) {
            Schema::create('translations', function (Blueprint $t) {
                $t->id();
                $t->char('src_hash', 40)->unique();     // বাংলা লেখার ছাপ
                $t->text('src');                        // বাংলা লেখা
                $t->text('en');                         // ইংরেজি অনুবাদ
                $t->string('kind', 12)->default('ui');  // ui | data
                $t->timestamps();
            });
        }
    }

    public function down(): void
    {
        //
    }
};
