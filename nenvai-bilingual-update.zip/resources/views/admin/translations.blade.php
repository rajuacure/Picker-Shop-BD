@extends('layouts.admin')
@section('title', 'ইংরেজি অনুবাদ')
@section('content')
@php
    $tabs = ['products' => 'পণ্য', 'categories' => 'ক্যাটাগরি', 'pages' => 'পেজ ও স্লাইডার', 'site' => 'সাইটের লেখা', 'missing' => 'বাকি লেখা', 'all' => 'সাধারণ লেখা'];
    $in = 'w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand';
@endphp
<div class="flex flex-wrap items-start justify-between gap-3 mb-5">
    <div>
        <h1 class="text-2xl font-bold">🌐 ইংরেজি অনুবাদ</h1>
        <p class="text-sm text-slate-500 mt-1 max-w-3xl">সাইটের উপরের মেনু বা ফুটার থেকে ক্রেতা বাংলা/English বেছে নিতে পারে। English বেছে নিলে নিচের ইংরেজি লেখা দেখায়, না থাকলে বাংলাই থাকে। অ্যাডমিন সবসময় বাংলায়।</p>
    </div>
    <a href="{{ url('/') }}?lang=en" target="_blank" class="rounded-lg border border-brand text-brand hover:bg-brand-soft px-4 py-2 text-sm font-medium">English সাইট দেখুন ↗</a>
</div>

<div class="flex flex-wrap gap-2 mb-5 text-sm">
    @foreach ($tabs as $k => $l)
        @php $c = $counts[$k]; @endphp
        <a href="{{ route('admin.translations.index', ['tab' => $k]) }}" class="rounded-lg px-4 py-2 border {{ $tab === $k ? 'bg-brand text-white border-brand' : 'border-slate-300 hover:bg-slate-100' }}">
            {{ $l }}
            @if ($k === 'missing')<span class="ml-1 rounded-full {{ $c['total'] ? 'bg-amber-400 text-slate-900' : ($tab === $k ? 'bg-white/25' : 'bg-slate-100') }} px-1.5 text-xs">{{ $c['total'] }}</span>
            @elseif ($k !== 'all')<span class="ml-1 rounded-full {{ $tab === $k ? 'bg-white/25' : ($c['done'] >= $c['total'] && $c['total'] ? 'bg-green-100 text-green-700' : 'bg-slate-100') }} px-1.5 text-xs">{{ $c['done'] }}/{{ $c['total'] }}</span>@endif
        </a>
    @endforeach
</div>

@if ($tab === 'missing')
<p class="text-sm text-slate-500 mb-3 max-w-3xl">ইংরেজি পেজ খোলার সময় যে বাংলা লেখাগুলোর অনুবাদ পাওয়া যায়নি সেগুলো এখানে জমা হয় (বেশিবার দেখা আগে)। ইংরেজি লিখে সেভ করলে লেখাটি সবখানে ইংরেজি হবে। এতে নাম, দাম বা সংখ্যার মতো লেখা আসতে পারে, ওগুলো বাদ দিন।</p>
@elseif ($tab === 'all')
<p class="text-sm text-slate-500 mb-3 max-w-3xl">সাইটের বাটন, লেবেল ও বার্তার মূল অনুবাদ। ইংরেজি শব্দ পছন্দ না হলে এখানে বদলে দিন। ঘর খালি করে সেভ করলে বদল মুছে আগের অনুবাদ ফিরে আসে।</p>
<input type="search" id="rowFilter" placeholder="খুঁজুন..." class="{{ $in }} max-w-sm mb-3">
@elseif ($tab === 'products')
<p class="text-sm text-slate-500 mb-3 max-w-3xl">পণ্যের নাম ও বিবরণ ইংরেজিতে লিখুন (ওজন যেমন "২৫০ গ্রাম" নিজে "250 g" হয়ে যায়)। এখানকার "ইংরেজি নাম" আর পণ্যের ফর্মের "ইংরেজি নাম" (Google Shopping-এর জন্য) আলাদা, দুটোই ভরা ভালো।</p>
@endif

<form method="POST" action="{{ route('admin.translations.save') }}" class="space-y-3">
    @csrf
    <input type="hidden" name="tab" value="{{ $tab }}">
    <input type="hidden" name="page" value="{{ request('page') }}">

    @forelse ($rows as $r)
    <div class="row-item bg-white rounded-xl border border-slate-200 p-4 grid md:grid-cols-2 gap-3">
        <div class="text-sm">
            @if ($r['group'])<div class="text-xs text-slate-400 mb-0.5">{{ \Illuminate\Support\Str::limit($r['group'], 50) }}</div>@endif
            @if ($r['label'])<div class="text-xs font-medium text-slate-500 mb-1">{{ $r['label'] }}</div>@endif
            <div class="whitespace-pre-line text-slate-800 {{ $r['long'] ? 'max-h-40 overflow-y-auto' : '' }}">{{ $r['src'] }}</div>
        </div>
        <div>
            @if ($r['long'])<textarea name="en[{{ $r['key'] }}]" rows="{{ min(10, max(3, (int) ceil(mb_strlen($r['src']) / 90))) }}" placeholder="English" class="{{ $in }}">{{ $r['en'] }}</textarea>
            @else<input name="en[{{ $r['key'] }}]" value="{{ $r['en'] }}" placeholder="English" class="{{ $in }}">@endif
            @if ($r['en'] === '')<span class="text-[11px] text-amber-700">অনুবাদ বাকি</span>@endif
        </div>
    </div>
    @empty
        <p class="bg-white rounded-xl border border-slate-200 p-8 text-center text-slate-500">এখানে এখন অনুবাদ করার মতো কিছু নেই।@if ($tab === 'missing') ইংরেজি সাইট ঘুরে দেখুন, বাকি লেখা এখানে জমা হবে।@endif</p>
    @endforelse

    @if ($rows)
    <div class="sticky bottom-3 flex flex-wrap items-center gap-3 rounded-xl bg-white/95 backdrop-blur border border-slate-200 shadow-lg p-3">
        <button class="rounded-lg bg-brand hover:bg-brand-dark text-white px-6 py-2 text-sm font-semibold">অনুবাদ সেভ করুন</button>
        <span class="text-xs text-slate-500">ইংরেজি লেখায় ডবল বা সিঙ্গেল কোটেশন (" ') আর < > চিহ্ন দেবেন না, সেগুলো নিজে বদলে বা বাদ হয়ে যায়।</span>
    </div>
    @endif
</form>

@if ($pager)<div class="mt-4">{{ $pager->links() }}</div>@endif

@if ($tab === 'missing' && $rows)
<form method="POST" action="{{ route('admin.translations.clear') }}" class="mt-3" onsubmit="return confirm('জমা থাকা বাকি লেখার তালিকা খালি করবেন?')">@csrf<button class="text-xs text-slate-500 underline">তালিকা খালি করুন</button></form>
@endif

<script>
(function () {
    var f = document.getElementById('rowFilter'); if (!f) return;
    f.addEventListener('input', function () {
        var q = f.value.trim().toLowerCase();
        document.querySelectorAll('.row-item').forEach(function (r) { r.style.display = !q || r.textContent.toLowerCase().indexOf(q) !== -1 || Array.prototype.some.call(r.querySelectorAll('input,textarea'), function (i) { return (i.value || '').toLowerCase().indexOf(q) !== -1; }) ? '' : 'none'; });
    });
})();
</script>
@endsection
