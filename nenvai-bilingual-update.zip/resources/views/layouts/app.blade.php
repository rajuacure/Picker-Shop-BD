@extends('layouts.base')
@section('body')
@php
    $S = \App\Models\Setting::cached();
    $digits = preg_replace('/\D/', '', $S['whatsapp'] ?? '');
@endphp

@if (! empty($S['topbar_text']))
    <div class="bg-brand text-white text-xs md:text-sm text-center py-2 px-4">{{ $S['topbar_text'] }}</div>
@endif

@php
    $cartCount = \App\Support\Cart::count();
    $showCats = ($S['show_nav_categories'] ?? '1') !== '0' && collect($navCategories ?? [])->isNotEmpty();
    $curCat = request()->routeIs('shop.category') ? optional(request()->route('category'))->id : null;
@endphp

{{-- ওপরে: বামে ক্যাটাগরি ফিল্টার, মাঝে লোগো, ডানে শুধু কার্ট --}}
<header class="bg-white/95 backdrop-blur border-b border-slate-200 sticky top-0 z-30">
    <div class="max-w-7xl mx-auto px-3 md:px-4 h-14 md:h-16 grid grid-cols-[1fr_auto_1fr] items-center gap-2">
        <div class="flex items-center">
            @if ($showCats)
            <button type="button" data-open="cat" class="inline-flex items-center gap-2 rounded-xl border border-slate-300 hover:border-brand hover:text-brand px-3 py-2 text-sm font-medium" aria-label="ক্যাটাগরি ফিল্টার">
                <svg viewBox="0 0 24 24" class="h-5 w-5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M4 6h16M7 12h10M10 18h4"/></svg>
                <span class="hidden sm:inline">ক্যাটাগরি</span>
            </button>
            @endif
        </div>

        <a href="{{ route('shop.index') }}" class="text-xl font-bold text-brand flex items-center justify-center min-w-0">@include('layouts.logo')</a>

        <div class="relative flex justify-end">
            <button type="button" id="cartBtn" class="relative inline-flex h-10 w-10 items-center justify-center rounded-xl border border-slate-300 hover:border-brand hover:text-brand" aria-label="কার্ট">
                <svg viewBox="0 0 24 24" class="h-5 w-5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 4h2l2.4 11.2a1 1 0 0 0 1 .8h9.2a1 1 0 0 0 1-.8L20 8H6.2"/><circle cx="9.5" cy="20" r="1.3"/><circle cx="17.5" cy="20" r="1.3"/></svg>
                <span data-cart-count class="{{ $cartCount > 0 ? '' : 'hidden' }} absolute -top-1.5 -right-1.5 min-w-[1.2rem] h-[1.2rem] px-1 rounded-full bg-red-600 text-white text-[11px] font-bold leading-[1.2rem] text-center">{{ $cartCount }}</span>
            </button>

            <div id="miniCart" class="hidden absolute right-0 top-full mt-2 w-[22rem] max-w-[92vw] bg-white rounded-2xl border border-slate-200 shadow-2xl z-40">
                <div class="px-4 py-3 border-b border-slate-100 flex items-center justify-between">
                    <span class="font-semibold text-sm">আপনার কার্ট</span>
                    <span class="text-xs text-slate-500"><span data-cart-count-text>{{ $cartCount }}</span>টি পণ্য</span>
                </div>
                <div id="miniItems" class="max-h-72 overflow-y-auto divide-y divide-slate-100"><div class="px-4 py-6 text-center text-sm text-slate-500">লোড হচ্ছে...</div></div>
                <div class="px-4 py-3 border-t border-slate-100">
                    <div class="flex justify-between text-sm mb-3"><span class="text-slate-600">পণ্যের মূল্য</span><b id="miniSub">—</b></div>
                    <div class="grid grid-cols-2 gap-2">
                        <a href="{{ route('cart.index') }}" class="text-center rounded-xl border border-brand text-brand hover:bg-brand-soft py-2 text-sm font-semibold">কার্ট দেখুন</a>
                        <a href="{{ route('checkout.show') }}" class="text-center rounded-xl bg-brand hover:bg-brand-dark text-white py-2 text-sm font-semibold">অর্ডার করুন</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>

<main class="max-w-7xl mx-auto px-4 py-6 md:py-8 min-h-[60vh]">
    @include('layouts.flash')
    @yield('content')
</main>

<footer class="bg-slate-900 text-slate-300 mt-12">
    <div class="max-w-7xl mx-auto px-4 py-10 grid gap-8 sm:grid-cols-2 lg:grid-cols-4 text-sm">
        <div>
            <div class="text-white text-lg font-bold mb-3">{{ config('shop.name') }}</div>
            @if (! empty($S['footer_about']))<p class="leading-relaxed text-slate-400">{{ $S['footer_about'] }}</p>@endif
            <div class="flex flex-wrap gap-2 mt-4">
                @foreach (['facebook' => 'Facebook', 'instagram' => 'Instagram', 'youtube' => 'YouTube'] as $k => $label)
                    @if (! empty($S[$k]))<a href="{{ $S[$k] }}" target="_blank" rel="noopener" class="rounded-full border border-slate-600 hover:border-white hover:text-white px-3 py-1 text-xs">{{ $label }}</a>@endif
                @endforeach
            </div>
        </div>

        <div>
            <div class="text-white font-semibold mb-3">দ্রুত লিংক</div>
            <ul class="space-y-2">
                <li><a href="{{ route('shop.products') }}" class="hover:text-white">সব পণ্য</a></li>
                @foreach (collect($navCategories ?? [])->take(5) as $c)
                    <li><a href="{{ route('shop.category', $c) }}" class="hover:text-white">{{ $c->name }}</a></li>
                @endforeach
                <li><a href="{{ auth()->check() ? route('account') : route('login') }}" class="hover:text-white">আমার অ্যাকাউন্ট</a></li>
                <li><a href="{{ route('cart.index') }}" class="hover:text-white">কার্ট</a></li>
            </ul>
        </div>

        <div>
            <div class="text-white font-semibold mb-3">তথ্য ও নীতিমালা</div>
            <ul class="space-y-2">
                @forelse (($footerPages ?? []) as $p)
                    <li><a href="{{ route('page.show', $p->slug) }}" class="hover:text-white">{{ $p->title }}</a></li>
                @empty
                    <li class="text-slate-500">—</li>
                @endforelse
            </ul>
        </div>

        <div>
            <div class="text-white font-semibold mb-3">যোগাযোগ</div>
            <ul class="space-y-2 text-slate-400">
                @if (! empty($S['address']))<li>{{ $S['address'] }}</li>@endif
                @if (! empty($S['phone']))<li><a href="tel:{{ preg_replace('/[^\d+]/', '', $S['phone']) }}" class="hover:text-white">{{ $S['phone'] }}</a></li>@endif
                @if (! empty($S['email']))<li><a href="mailto:{{ $S['email'] }}" class="hover:text-white">{{ $S['email'] }}</a></li>@endif
                @if ($digits)<li><a href="https://wa.me/{{ $digits }}" target="_blank" rel="noopener" class="hover:text-white">WhatsApp এ মেসেজ করুন</a></li>@endif
                @if (! empty($S['hours']))<li>{{ $S['hours'] }}</li>@endif
            </ul>
        </div>
    </div>

    <div class="border-t border-slate-800">
        <div class="max-w-7xl mx-auto px-4 py-4 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-500">
            <span>© {{ date('Y') }} {{ config('shop.name') }}। সর্বস্বত্ব সংরক্ষিত।</span>
            <span class="flex items-center gap-2 text-xs"><a href="{{ request()->fullUrlWithQuery(['lang' => 'bn']) }}" class="{{ app()->getLocale() === 'bn' ? 'text-white font-semibold' : 'hover:text-white' }}">বাংলা</a><span>|</span><a href="{{ request()->fullUrlWithQuery(['lang' => 'en']) }}" class="{{ app()->getLocale() === 'en' ? 'text-white font-semibold' : 'hover:text-white' }}">English</a></span>
            <span class="flex flex-wrap gap-2">
                @foreach (\App\Support\Payments::methods() as $label)
                    <span class="rounded border border-slate-700 px-2 py-0.5 text-slate-400">{{ $label }}</span>
                @endforeach
            </span>
        </div>
    </div>
</footer>

<div class="h-24 md:h-28 bg-slate-900"></div>

{{-- বাম দিক থেকে ক্যাটাগরি ফিল্টার --}}
@if ($showCats)
<div id="catDrawer" class="hidden fixed inset-0 z-[70]" role="dialog" aria-modal="true" aria-label="ক্যাটাগরি">
    <div data-close class="absolute inset-0 bg-black/50"></div>
    <aside id="catPanel" class="absolute inset-y-0 left-0 w-[20rem] max-w-[88vw] bg-white shadow-2xl flex flex-col -translate-x-full transition-transform duration-300">
        <div class="flex items-center justify-between px-5 py-4 border-b border-slate-100">
            <h2 class="font-bold text-lg">ক্যাটাগরি</h2>
            <button type="button" data-close class="h-9 w-9 rounded-full hover:bg-slate-100" aria-label="বন্ধ করুন">✕</button>
        </div>
        <nav class="flex-1 overflow-y-auto p-3 space-y-1">
            <a href="{{ route('shop.products') }}" class="flex items-center gap-3 rounded-xl px-3 py-2.5 {{ request()->routeIs('shop.products') ? 'bg-brand-soft text-brand font-semibold' : 'hover:bg-slate-50' }}">
                <span class="h-10 w-10 rounded-full bg-brand text-white flex items-center justify-center"><svg viewBox="0 0 24 24" class="h-5 w-5" fill="currentColor" aria-hidden="true"><path d="M4 4h6v6H4V4zm10 0h6v6h-6V4zM4 14h6v6H4v-6zm10 0h6v6h-6v-6z"/></svg></span>
                <span class="flex-1">সব পণ্য</span>
            </a>
            @foreach ($navCategories as $c)
            <a href="{{ route('shop.category', $c) }}" class="flex items-center gap-3 rounded-xl px-3 py-2.5 {{ $curCat === $c->id ? 'bg-brand-soft text-brand font-semibold' : 'hover:bg-slate-50' }}">
                @if ($c->imageUrl())<img src="{{ $c->imageUrl() }}" alt="" loading="lazy" class="h-10 w-10 rounded-full object-cover border border-slate-200">
                @else<span class="h-10 w-10 rounded-full bg-brand-soft text-brand font-bold flex items-center justify-center">{{ mb_substr($c->name, 0, 1) }}</span>@endif
                <span class="flex-1">{{ $c->name }}</span>
                @if (($c->products_count ?? 0) > 0)<span class="text-xs text-slate-400">{{ $c->products_count }}</span>@endif
            </a>
            @endforeach
        </nav>
    </aside>
</div>
@endif

{{-- নিচ থেকে মেনু --}}
<div id="menuSheet" class="hidden fixed inset-0 z-[70]" role="dialog" aria-modal="true" aria-label="মেনু">
    <div data-close class="absolute inset-0 bg-black/50"></div>
    <div id="menuPanel" class="absolute bottom-0 inset-x-0 md:inset-x-auto md:left-1/2 md:-ml-[16rem] md:w-[32rem] bg-white rounded-t-3xl max-h-[85vh] overflow-y-auto translate-y-full transition-transform duration-300 pb-8">
        <div class="sticky top-0 bg-white flex items-center justify-between px-5 py-4 border-b border-slate-100 rounded-t-3xl">
            <h2 class="font-bold text-lg">মেনু</h2>
            <button type="button" data-close class="h-9 w-9 rounded-full hover:bg-slate-100" aria-label="বন্ধ করুন">✕</button>
        </div>
        <div class="p-5 space-y-6 text-sm">
            <div class="flex items-center justify-between rounded-2xl bg-slate-50 px-4 py-3">
                <span class="font-medium">🌐 Language</span>
                <span class="inline-flex overflow-hidden rounded-full border border-slate-300 text-sm font-medium">
                    <a href="{{ request()->fullUrlWithQuery(['lang' => 'bn']) }}" hreflang="bn" class="px-4 py-1.5 {{ app()->getLocale() === 'bn' ? 'bg-brand text-white' : 'hover:bg-slate-100' }}">বাংলা</a>
                    <a href="{{ request()->fullUrlWithQuery(['lang' => 'en']) }}" hreflang="en" class="px-4 py-1.5 {{ app()->getLocale() === 'en' ? 'bg-brand text-white' : 'hover:bg-slate-100' }}">English</a>
                </span>
            </div>
            <div class="grid grid-cols-3 gap-3 text-center">
                <a href="{{ route('shop.products') }}" class="rounded-2xl bg-slate-50 hover:bg-brand-soft py-4"><div class="text-2xl">🛍️</div><div class="mt-1 font-medium">সব পণ্য</div></a>
                <a href="{{ route('cart.index') }}" class="rounded-2xl bg-slate-50 hover:bg-brand-soft py-4"><div class="text-2xl">🛒</div><div class="mt-1 font-medium">কার্ট</div></a>
                <a href="{{ auth()->check() ? route('account') : route('login') }}" class="rounded-2xl bg-slate-50 hover:bg-brand-soft py-4"><div class="text-2xl">📦</div><div class="mt-1 font-medium">আমার অর্ডার</div></a>
            </div>
            @if (collect($footerPages ?? [])->isNotEmpty())
            <div>
                <div class="font-semibold mb-2">তথ্য ও নীতিমালা</div>
                <ul class="divide-y divide-slate-100 rounded-2xl border border-slate-100">
                    @foreach ($footerPages as $p)<li><a href="{{ route('page.show', $p->slug) }}" class="flex items-center justify-between px-4 py-3 hover:bg-slate-50">{{ $p->title }}<span class="text-slate-300">›</span></a></li>@endforeach
                </ul>
            </div>
            @endif
            @if (! empty($S['address']) || ! empty($S['phone']) || ! empty($S['email']) || $digits)
            <div>
                <div class="font-semibold mb-2">যোগাযোগ</div>
                <div class="rounded-2xl border border-slate-100 p-4 space-y-2 text-slate-600">
                    @if (! empty($S['address']))<div>📍 {{ $S['address'] }}</div>@endif
                    @if (! empty($S['phone']))<div>📞 <a href="tel:{{ preg_replace('/[^\d+]/', '', $S['phone']) }}" class="text-brand">{{ $S['phone'] }}</a></div>@endif
                    @if (! empty($S['email']))<div>✉️ <a href="mailto:{{ $S['email'] }}" class="text-brand">{{ $S['email'] }}</a></div>@endif
                    @if (! empty($S['hours']))<div>🕘 {{ $S['hours'] }}</div>@endif
                    @if ($digits)<a href="https://wa.me/{{ $digits }}" target="_blank" rel="noopener" class="mt-1 inline-block rounded-xl bg-[#25D366] text-white px-4 py-2 font-semibold">WhatsApp-এ মেসেজ করুন</a>@endif
                </div>
            </div>
            @endif
            @php $socials = array_filter(['Facebook' => $S['facebook'] ?? '', 'Instagram' => $S['instagram'] ?? '', 'YouTube' => $S['youtube'] ?? '']); @endphp
            @if ($socials)<div class="flex flex-wrap gap-2">@foreach ($socials as $l => $u)<a href="{{ $u }}" target="_blank" rel="noopener" class="rounded-full border border-slate-300 hover:border-brand hover:text-brand px-4 py-1.5">{{ $l }}</a>@endforeach</div>@endif
        </div>
    </div>
</div>

{{-- সার্চ --}}
<div id="searchOverlay" class="hidden fixed inset-0 z-[70] bg-white" role="dialog" aria-modal="true" aria-label="সার্চ">
    <div class="max-w-2xl mx-auto px-4 pt-5">
        <div class="flex items-center justify-between mb-3"><h2 class="font-bold text-lg">পণ্য খুঁজুন</h2><button type="button" data-close class="h-9 w-9 rounded-full hover:bg-slate-100" aria-label="বন্ধ করুন">✕</button></div>
        @include('layouts._search', ['class' => ''])
        <p class="mt-3 text-xs text-slate-400">কয়েকটি শব্দ লিখলেই নিচে পণ্য আসবে। যেমন: মধু ৫০০, নারিকেল তেল</p>
    </div>
</div>

{{-- নিচের নেভিগেশন: হোম · মেনু · কার্ট · সার্চ · অ্যাকাউন্ট --}}
<nav id="bottomNav" class="fixed bottom-0 inset-x-0 z-40 md:bottom-4 md:inset-x-auto md:left-1/2 md:-ml-[15rem] md:w-[30rem]" aria-label="প্রধান নেভিগেশন">
    @php
        $isHome = request()->routeIs('shop.index'); $isCart = request()->routeIs('cart.index'); $isAcc = request()->routeIs('account', 'account.*', 'login', 'register');
        $ico = 'h-6 w-6'; $on = 'text-brand'; $off = 'text-slate-500';
    @endphp
    <div class="bg-white/95 backdrop-blur border-t border-slate-200 md:border md:rounded-2xl md:shadow-2xl pb-[env(safe-area-inset-bottom)]">
        <ul class="grid grid-cols-5 items-end text-[11px] font-medium">
            <li><a href="{{ route('shop.index') }}" class="flex flex-col items-center gap-0.5 py-2 {{ $isHome ? $on : $off }}">
                <svg viewBox="0 0 24 24" class="{{ $ico }}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 11 12 3l9 8"/><path d="M5 10v10h5v-6h4v6h5V10"/></svg>হোম</a></li>
            <li><button type="button" data-open="menu" class="w-full flex flex-col items-center gap-0.5 py-2 {{ $off }} hover:text-brand">
                <svg viewBox="0 0 24 24" class="{{ $ico }}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M4 6h16M4 12h16M4 18h16"/></svg>মেনু</button></li>
            <li class="flex justify-center"><a href="{{ route('cart.index') }}" class="relative -mt-5 flex flex-col items-center" aria-label="কার্ট">
                <span class="h-14 w-14 rounded-full {{ $isCart ? 'bg-brand-dark' : 'bg-brand' }} text-white shadow-lg ring-4 ring-white flex items-center justify-center relative">
                    <svg viewBox="0 0 24 24" class="h-7 w-7" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 4h2l2.4 11.2a1 1 0 0 0 1 .8h9.2a1 1 0 0 0 1-.8L20 8H6.2"/><circle cx="9.5" cy="20" r="1.3"/><circle cx="17.5" cy="20" r="1.3"/></svg>
                    <span data-cart-count class="{{ $cartCount > 0 ? '' : 'hidden' }} absolute -top-1 -right-1 min-w-[1.2rem] h-[1.2rem] px-1 rounded-full bg-red-600 text-white text-[11px] font-bold leading-[1.2rem] text-center">{{ $cartCount }}</span>
                </span><span class="mt-0.5 {{ $isCart ? $on : $off }}">কার্ট</span></a></li>
            <li><button type="button" data-open="search" class="w-full flex flex-col items-center gap-0.5 py-2 {{ $off }} hover:text-brand">
                <svg viewBox="0 0 24 24" class="{{ $ico }}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>সার্চ</button></li>
            <li><a href="{{ auth()->check() ? route('account') : route('login') }}" class="flex flex-col items-center gap-0.5 py-2 {{ $isAcc ? $on : $off }}">
                <svg viewBox="0 0 24 24" class="{{ $ico }}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg>অ্যাকাউন্ট</a></li>
        </ul>
    </div>
</nav>

<div id="toastMsg" class="hidden fixed top-20 left-1/2 -translate-x-1/2 z-[90] max-w-[92vw] rounded-xl bg-slate-900 text-white text-sm px-4 py-2.5 shadow-xl"></div>

<script>
(function () {
    document.querySelectorAll('.js-search').forEach(function (box) {
        var input = box.querySelector('.js-q'), out = box.querySelector('.js-results'), url = box.dataset.url;
        var timer = null, ctrl = null, active = -1;

        function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text) e.textContent = text; return e; }
        function hide() { out.classList.add('hidden'); active = -1; }
        function rows() { return out.querySelectorAll('a[data-row]'); }
        function mark(i) {
            var r = rows(); if (!r.length) return;
            active = (i + r.length) % r.length;
            r.forEach(function (a, k) { a.classList.toggle('bg-brand-soft', k === active); });
            r[active].scrollIntoView({ block: 'nearest' });
        }

        function render(data) {
            out.textContent = '';
            if (!data.items.length) { out.appendChild(el('div', 'px-4 py-6 text-center text-sm text-slate-500', 'কোনো পণ্য পাওয়া যায়নি')); out.classList.remove('hidden'); return; }
            data.items.forEach(function (p) {
                var a = el('a', 'flex items-center gap-3 px-3 py-2.5 hover:bg-brand-soft border-b border-slate-100'); a.href = p.url; a.setAttribute('data-row', '1');
                if (p.image) { var img = el('img', 'h-12 w-12 rounded-lg object-cover shrink-0 border border-slate-200'); img.src = p.image; img.alt = ''; img.loading = 'lazy'; a.appendChild(img); }
                else { a.appendChild(el('span', 'h-12 w-12 rounded-lg bg-slate-100 shrink-0 flex items-center justify-center text-xs text-slate-400', 'ছবি নেই')); }
                var mid = el('span', 'min-w-0 flex-1');
                mid.appendChild(el('span', 'block text-sm font-medium truncate', p.name));
                var meta = [p.weight, p.category].filter(Boolean).join(' · ');
                if (meta) mid.appendChild(el('span', 'block text-xs text-slate-500 truncate', meta));
                a.appendChild(mid);
                var pr = el('span', 'text-right shrink-0');
                pr.appendChild(el('span', 'block text-sm font-semibold text-brand', '{{ config('shop.currency') }}' + p.price));
                if (p.old) pr.appendChild(el('span', 'block text-xs text-slate-400 line-through', '{{ config('shop.currency') }}' + p.old));
                if (!p.in_stock) pr.appendChild(el('span', 'block text-xs text-red-600', 'স্টক শেষ'));
                a.appendChild(pr);
                out.appendChild(a);
            });
            var more = el('a', 'block text-center text-sm font-medium text-brand hover:bg-brand-soft px-4 py-3', 'সব ফলাফল দেখুন →'); more.href = data.more; more.setAttribute('data-row', '1');
            out.appendChild(more); out.classList.remove('hidden'); active = -1;
        }

        function search() {
            var q = input.value.trim();
            if (q.length < 2) { hide(); return; }
            if (ctrl) ctrl.abort();
            ctrl = new AbortController();
            fetch(url + '?q=' + encodeURIComponent(q), { signal: ctrl.signal, headers: { 'Accept': 'application/json' }, credentials: 'same-origin' })
                .then(function (r) { return r.json(); }).then(render).catch(function () {});
        }

        input.addEventListener('input', function () { clearTimeout(timer); timer = setTimeout(search, 250); });
        input.addEventListener('focus', function () { if (out.childElementCount && input.value.trim().length >= 2) out.classList.remove('hidden'); });
        input.addEventListener('keydown', function (e) {
            if (e.key === 'ArrowDown') { e.preventDefault(); mark(active + 1); }
            else if (e.key === 'ArrowUp') { e.preventDefault(); mark(active - 1); }
            else if (e.key === 'Enter' && active >= 0) { e.preventDefault(); rows()[active].click(); }
            else if (e.key === 'Escape') { hide(); }
        });
        document.addEventListener('click', function (e) { if (!box.contains(e.target)) hide(); });
    });
})();
</script>

<style>
    .row-scroll { scrollbar-width: none; }
    .row-scroll::-webkit-scrollbar { display: none; }
    .reveal { opacity: 0; transform: translateY(18px); transition: opacity .6s ease, transform .6s ease; }
    .reveal.is-in { opacity: 1; transform: none; }
    @media (prefers-reduced-motion: reduce) { .reveal { opacity: 1; transform: none; transition: none; } }
</style>
<noscript><style>.reveal { opacity: 1 !important; transform: none !important; }</style></noscript>
<script>
(function () {
    // ঢোকার সময় ধীরে ফুটে ওঠা
    var els = document.querySelectorAll('.reveal');
    if ('IntersectionObserver' in window) {
        var io = new IntersectionObserver(function (es) { es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('is-in'); io.unobserve(e.target); } }); }, { threshold: 0.08 });
        els.forEach(function (el) { io.observe(el); });
    } else { els.forEach(function (el) { el.classList.add('is-in'); }); }

    // পণ্যের সারির বাম-ডান তীর
    function move(id, dir) { var r = document.getElementById('row-' + id); if (r) r.scrollBy({ left: dir * r.clientWidth * 0.85, behavior: 'smooth' }); }
    document.querySelectorAll('[data-row-prev]').forEach(function (b) { b.addEventListener('click', function () { move(b.dataset.rowPrev, -1); }); });
    document.querySelectorAll('[data-row-next]').forEach(function (b) { b.addEventListener('click', function () { move(b.dataset.rowNext, 1); }); });
})();
</script>

<style>
    @keyframes cartBump { 0% { transform: scale(1); } 40% { transform: scale(1.22); } 100% { transform: scale(1); } }
    .cart-bump { animation: cartBump .45s ease; }
</style>
<script>
(function () {
    var $ = function (s) { return document.querySelector(s); }, $$ = function (s) { return document.querySelectorAll(s); };
    var miniUrl = @json(route('cart.mini'));
    function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text !== undefined) e.textContent = text; return e; }

    // ---------- ড্রয়ার, মেনু ও সার্চ ----------
    var layers = {};
    function layer(name, rootId, panelId, closed, open, onOpen) {
        var root = document.getElementById(rootId); if (!root) return;
        var panel = panelId ? document.getElementById(panelId) : null;
        var L = {
            root: root,
            open: function () {
                Object.keys(layers).forEach(function (k) { if (k !== name) layers[k].close(); });
                root.classList.remove('hidden'); document.documentElement.classList.add('overflow-hidden');
                requestAnimationFrame(function () { requestAnimationFrame(function () { if (panel) { panel.classList.remove(closed); panel.classList.add(open); } }); });
                if (onOpen) onOpen();
            },
            close: function () {
                if (root.classList.contains('hidden')) return;
                if (panel) { panel.classList.remove(open); panel.classList.add(closed); }
                setTimeout(function () { root.classList.add('hidden'); document.documentElement.classList.remove('overflow-hidden'); }, panel ? 280 : 0);
            }
        };
        root.querySelectorAll('[data-close]').forEach(function (b) { b.addEventListener('click', L.close); });
        layers[name] = L;
    }
    layer('cat', 'catDrawer', 'catPanel', '-translate-x-full', 'translate-x-0');
    layer('menu', 'menuSheet', 'menuPanel', 'translate-y-full', 'translate-y-0');
    layer('search', 'searchOverlay', null, '', '', function () { setTimeout(function () { var i = document.querySelector('#searchOverlay .js-q'); if (i) i.focus(); }, 60); });
    $$('[data-open]').forEach(function (b) { b.addEventListener('click', function () { var l = layers[b.dataset.open]; if (l) l.open(); }); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') { Object.keys(layers).forEach(function (k) { layers[k].close(); }); if (mini) mini.classList.add('hidden'); } });

    // ---------- কার্ট: সংখ্যা, ছোট তালিকা, যোগ হওয়ার অ্যানিমেশন ----------
    var cartBtn = $('#cartBtn'), mini = $('#miniCart'), miniItems = $('#miniItems'), miniSub = $('#miniSub'), hideT = null;
    function setCount(n) {
        $$('[data-cart-count]').forEach(function (e) { e.textContent = n; e.classList.toggle('hidden', n < 1); });
        $$('[data-cart-count-text]').forEach(function (e) { e.textContent = n; });
    }
    function money(c, n) { return c + Math.round(n).toLocaleString('en-US'); }
    function renderMini(d, hl) {
        miniItems.textContent = '';
        if (!d.items.length) miniItems.appendChild(el('div', 'px-4 py-8 text-center text-sm text-slate-500', 'কার্ট খালি। পণ্য যোগ করুন।'));
        d.items.forEach(function (i) {
            var a = el('a', 'flex items-center gap-3 px-4 py-2.5 hover:bg-slate-50 ' + (hl && i.key === hl ? 'bg-brand-soft' : '')); a.href = i.url;
            if (i.image) { var im = el('img', 'h-12 w-12 rounded-lg object-cover border border-slate-200 shrink-0'); im.src = i.image; im.alt = ''; a.appendChild(im); }
            else a.appendChild(el('span', 'h-12 w-12 rounded-lg bg-slate-100 shrink-0'));
            var mid = el('span', 'min-w-0 flex-1'); mid.appendChild(el('span', 'block text-sm font-medium truncate', i.name));
            mid.appendChild(el('span', 'block text-xs text-slate-500', (i.label ? i.label + ' · ' : '') + i.qty + ' × ' + money(d.currency, i.unit)));
            a.appendChild(mid); a.appendChild(el('span', 'text-sm font-semibold whitespace-nowrap', money(d.currency, i.line)));
            miniItems.appendChild(a);
        });
        miniSub.textContent = money(d.currency, d.subtotal);
        setCount(d.count);
    }
    function loadMini() { fetch(miniUrl, { headers: { 'Accept': 'application/json' }, credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (d) { renderMini(d); }).catch(function () {}); }
    if (cartBtn) {
        cartBtn.addEventListener('click', function (e) { e.stopPropagation(); clearTimeout(hideT); mini.classList.toggle('hidden'); if (!mini.classList.contains('hidden')) loadMini(); });
        document.addEventListener('click', function (e) { if (!mini.contains(e.target) && !cartBtn.contains(e.target)) mini.classList.add('hidden'); });
    }
    function toast(msg) { var t = $('#toastMsg'); t.textContent = msg; t.classList.remove('hidden'); clearTimeout(t._t); t._t = setTimeout(function () { t.classList.add('hidden'); }, 3200); }
    function fly(img) {
        if (!img || !cartBtn || (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches)) return;
        var r = img.getBoundingClientRect(), t = cartBtn.getBoundingClientRect(); if (!r.width) return;
        var c = img.cloneNode(); c.removeAttribute('data-zoom'); c.removeAttribute('id'); c.removeAttribute('loading');
        c.style.cssText = 'position:fixed;z-index:200;pointer-events:none;object-fit:cover;border-radius:14px;opacity:.95;transition:all .8s cubic-bezier(.2,.7,.3,1);left:' + r.left + 'px;top:' + r.top + 'px;width:' + r.width + 'px;height:' + r.height + 'px';
        document.body.appendChild(c);
        requestAnimationFrame(function () { requestAnimationFrame(function () { c.style.left = (t.left + t.width / 2 - 18) + 'px'; c.style.top = (t.top + t.height / 2 - 18) + 'px'; c.style.width = '36px'; c.style.height = '36px'; c.style.opacity = '.25'; }); });
        setTimeout(function () { c.remove(); }, 900);
    }

    // পেজ না ছেড়ে কার্টে যোগ ("অর্ডার করুন" বাটন আগের মতোই সরাসরি চেকআউটে যায়)
    document.addEventListener('submit', function (e) {
        var f = e.target; if (!f.matches || !f.matches('form[action*="/cart/add/"]')) return;
        if (e.submitter && e.submitter.name === 'buy_now') return;
        e.preventDefault();
        var btn = e.submitter || f.querySelector('button'), old = btn ? btn.textContent : '';
        if (btn) { btn.disabled = true; btn.textContent = 'যোগ হচ্ছে...'; }
        var card = f.closest('article'), src = card ? card.querySelector('img') : document.getElementById('productMainImage');
        fetch(f.action, { method: 'POST', body: new FormData(f), credentials: 'same-origin', headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' } })
            .then(function (r) { return r.json().then(function (d) { return { ok: r.ok && d.ok, d: d }; }); })
            .then(function (x) {
                if (!x.ok) { toast(x.d.message || 'কার্টে যোগ করা যায়নি'); return; }
                fly(src); renderMini(x.d.mini, x.d.added);
                if (cartBtn) { cartBtn.classList.remove('cart-bump'); void cartBtn.offsetWidth; cartBtn.classList.add('cart-bump'); }
                setTimeout(function () { if (mini) { mini.classList.remove('hidden'); clearTimeout(hideT); hideT = setTimeout(function () { mini.classList.add('hidden'); }, 4200); } }, 650);
                if (window.fbq && x.d.fb) fbq('track', 'AddToCart', x.d.fb);
            })
            .catch(function () { f.submit(); })
            .then(function () { if (btn) { btn.disabled = false; btn.textContent = old; } });
    });
})();
</script>

@include('layouts._lightbox')

@unless (session('is_admin'))
<script>
(function () {
    var url = @json(route('live.ping')), meta = document.querySelector('meta[name=csrf-token]');
    if (!meta) return;
    function ping() {
        if (document.hidden) return;
        var q = new URLSearchParams(location.search);
        fetch(url, { method: 'POST', keepalive: true, credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': meta.content, 'Accept': 'application/json' },
            body: JSON.stringify({ path: location.pathname, ref: document.referrer || '', utm: q.get('utm_source') || '' }) }).catch(function () {});
    }
    ping(); setInterval(ping, 30000);
    document.addEventListener('visibilitychange', function () { if (!document.hidden) ping(); });
})();
</script>
@endunless

@if ($waLink = \App\Support\Contact::whatsappLink('আসসালামু আলাইকুম, আমি ' . config('shop.name') . ' থেকে কিছু জানতে চাই।'))
<a href="{{ $waLink }}" target="_blank" rel="noopener" aria-label="WhatsApp-এ মেসেজ করুন"
   class="fixed bottom-24 right-4 md:bottom-28 md:right-6 z-30 inline-flex items-center gap-2 rounded-full bg-[#25D366] text-white px-4 py-3 shadow-lg font-semibold text-sm hover:brightness-95">
    <svg viewBox="0 0 24 24" class="h-5 w-5" fill="currentColor" aria-hidden="true"><path d="M20 2H4a2 2 0 0 0-2 2v18l4-4h14a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2z"/></svg>
    WhatsApp
</a>
@endif
@endsection
