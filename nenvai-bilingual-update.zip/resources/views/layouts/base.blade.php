<!doctype html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    @php
        $__title = trim($__env->yieldContent('title'));
        $__full  = $__title !== '' ? $__title . ' | ' . config('shop.name') : config('shop.name');
        $__desc  = trim($__env->yieldContent('description')) ?: \App\Models\Setting::get('site_description');
        $__img   = trim($__env->yieldContent('og_image')) ?: \App\Support\Brand::logoUrl();
    @endphp
    <title>{{ $__full }}</title>
    @if ($__desc !== '')<meta name="description" content="{{ $__desc }}">@endif
    @hasSection('robots')<meta name="robots" content="@yield('robots')">@endif
    <link rel="canonical" href="{{ url()->current() }}">
    <meta property="og:site_name" content="{{ config('shop.name') }}">
    <meta property="og:locale" content="{{ app()->getLocale() === 'en' ? 'en_US' : 'bn_BD' }}">
    <meta property="og:type" content="@yield('og_type', 'website')">
    <meta property="og:title" content="{{ $__title !== '' ? $__title : config('shop.name') }}">
    @if ($__desc !== '')<meta property="og:description" content="{{ $__desc }}">@endif
    <meta property="og:url" content="{{ url()->current() }}">
    @if ($__img)<meta property="og:image" content="{{ $__img }}">@endif
    <meta name="twitter:card" content="{{ $__img ? 'summary_large_image' : 'summary' }}">
    @if ($logo = \App\Support\Brand::logoUrl())<link rel="icon" href="{{ $logo }}">@endif
    @stack('jsonld')
    @if ($__gv = \App\Models\Setting::get('google_site_verification'))<meta name="google-site-verification" content="{{ $__gv }}">@endif
    @if ($__bv = \App\Models\Setting::get('bing_site_verification'))<meta name="msvalidate.01" content="{{ $__bv }}">@endif
    @if ($__ver = \App\Models\Setting::get('meta_domain_verification'))<meta name="facebook-domain-verification" content="{{ $__ver }}">@endif
    @if (($__pid = \App\Support\Meta::pixelId()) && ! request()->routeIs('admin.*', 'invoice.show'))
    <script>
    !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');
    fbq('init', '{{ $__pid }}');
    fbq('track', 'PageView');
    @if (session('fb_add_to_cart'))
    fbq('track', 'AddToCart', {!! json_encode(session('fb_add_to_cart'), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) !!});
    @endif
    @stack('pixel')
    </script>
    <noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id={{ $__pid }}&ev=PageView&noscript=1" alt=""></noscript>
    @endif
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = { theme: { extend: {
            fontFamily: { sans: ['"Hind Siliguri"', 'system-ui', 'sans-serif'] },
            colors: { brand: @json(\App\Support\Brand::palette()) }
        } } }
    </script>
</head>
<body class="bg-slate-50 text-slate-800 font-sans antialiased">
    @yield('body')
</body>
</html>
