@extends('layouts.base')
@section('robots', 'noindex,nofollow')
@section('body')
@php
    $nav = [
        ['admin.dashboard', 'ড্যাশবোর্ড', 'dashboard', '📊', 'admin.dashboard'],
        ['admin.live', 'লাইভ ভিজিটর', 'dashboard', '🟢', 'admin.live*'],
        ['admin.blocked.index', 'ব্লক তালিকা', 'order_edit', '🚫', 'admin.blocked.*'],
        ['admin.orders.index', 'অর্ডার', 'orders', '🧾', 'admin.orders.*'],
        ['admin.abandoned.index', 'অসম্পূর্ণ অর্ডার', 'abandoned', '⏳', 'admin.abandoned.*'],
        ['admin.customers.index', 'গ্রাহক', 'customers', '👥', 'admin.customers.*'],
        ['admin.expenses.index', 'খরচ ও হিসাব', 'profit', '💸', 'admin.expense*'],
        ['admin.products.index', 'পণ্য', 'catalog', '📦', 'admin.products.*'],
        ['admin.reviews.index', 'রিভিউ', 'catalog', '⭐', 'admin.reviews.*'],
        ['admin.seo.index', 'SEO পরীক্ষা', 'catalog', '🔎', 'admin.seo.*'],
        ['admin.translations.index', 'ইংরেজি অনুবাদ', 'catalog', '🌐', 'admin.translations.*'],
        ['admin.categories.index', 'ক্যাটাগরি', 'catalog', '🗂️', 'admin.categories.*'],
        ['admin.import.form', 'CSV ইমপোর্ট', 'catalog', '📥', 'admin.import.*'],
        ['admin.sliders.index', 'স্লাইডার', 'catalog', '🖼️', 'admin.sliders.*'],
        ['admin.pages.index', 'পেজ ও পলিসি', 'catalog', '📄', 'admin.pages.*'],
        ['admin.zones.index', 'ডেলিভারি চার্জ', 'settings', '🚚', 'admin.zones.*'],
        ['admin.payments.edit', 'পেমেন্ট', 'settings', '💳', 'admin.payments.*'],
        ['admin.courier.edit', 'কুরিয়ার সংযোগ', 'settings', '📮', 'admin.courier.*'],
        ['admin.settings.edit', 'সেটিংস', 'settings', '⚙️', 'admin.settings.*'],
        ['admin.users.index', 'অ্যাডমিন ইউজার', 'admins', '🔑', 'admin.users.*'],
    ];
    $roleLabel = ['owner' => 'মালিক', 'manager' => 'ম্যানেজার', 'staff' => 'স্টাফ'][\App\Support\AdminAuth::role()] ?? '';
@endphp
<div class="min-h-screen md:flex">
    <aside class="md:w-60 bg-slate-900 text-slate-200 md:min-h-screen p-3 md:p-4 md:sticky md:top-0 md:h-screen md:overflow-y-auto">
        <div class="flex items-center justify-between md:block">
            <div class="font-bold text-white text-lg md:mb-1">{{ config('shop.name') }}</div>
            <div class="text-xs text-slate-400 md:mb-5">অ্যাডমিন প্যানেল</div>
        </div>
        <nav class="flex md:block gap-1 overflow-x-auto mt-2 md:mt-0">
            @foreach ($nav as [$route, $label, $ability, $icon, $pattern])
                @if (\App\Support\AdminAuth::can($ability))
                <a href="{{ route($route) }}" class="flex items-center gap-2 px-3 py-2 rounded-lg text-sm whitespace-nowrap {{ request()->routeIs($pattern) ? 'bg-brand text-white' : 'hover:bg-slate-800' }}">
                    <span class="w-5 text-center">{{ $icon }}</span>{{ $label }}
                </a>
                @endif
            @endforeach
            <a href="{{ route('shop.index') }}" target="_blank" class="flex items-center gap-2 px-3 py-2 text-sm text-slate-400 hover:text-white whitespace-nowrap md:mt-4"><span class="w-5 text-center">🛍️</span>দোকান দেখুন</a>
        </nav>
    </aside>

    <div class="flex-1 min-w-0">
        <header class="bg-white border-b border-slate-200 px-4 md:px-8 py-3 flex flex-wrap items-center gap-3">
            @if (\App\Support\AdminAuth::can('orders'))
            <form action="{{ route('admin.orders.index') }}" class="flex-1 min-w-[12rem] max-w-xl flex">
                <input name="q" placeholder="অর্ডার খুঁজুন: ফোন, নাম, অর্ডার নম্বর, পণ্য..." class="w-full rounded-l-lg border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand">
                <button class="rounded-r-lg bg-brand hover:bg-brand-dark text-white px-4 text-sm">খুঁজুন</button>
            </form>
            @endif
            <div class="ml-auto flex items-center gap-3 text-sm">
                <div class="relative" id="bellBox">
                    <button type="button" id="bellBtn" class="relative h-9 w-9 rounded-full border border-slate-300 hover:bg-slate-100" aria-label="নোটিফিকেশন">🔔<span id="bellBadge" class="hidden absolute -top-1 -right-1 min-w-[1.1rem] h-[1.1rem] px-1 rounded-full bg-red-600 text-white text-[10px] leading-[1.1rem] text-center">0</span></button>
                    <div id="bellPanel" class="hidden absolute right-0 mt-2 w-80 max-w-[90vw] bg-white border border-slate-200 rounded-xl shadow-xl z-50">
                        <div class="flex items-center justify-between px-4 py-2.5 border-b border-slate-100 text-xs">
                            <span class="font-semibold text-sm">নোটিফিকেশন</span>
                            <span class="flex items-center gap-3">
                                <label class="flex items-center gap-1 cursor-pointer"><input type="checkbox" id="bellSound" checked> শব্দ</label>
                                <button type="button" id="bellPerm" class="text-brand hidden">ব্রাউজার অ্যালার্ট চালু করুন</button>
                            </span>
                        </div>
                        <div id="bellList" class="max-h-80 overflow-y-auto"></div>
                        <a href="{{ route('admin.notifications.index') }}" class="block text-center text-sm text-brand py-2.5 border-t border-slate-100 hover:bg-slate-50">সব দেখুন</a>
                    </div>
                </div>
                <span class="text-slate-600">{{ \App\Support\AdminAuth::name() ?: 'অ্যাডমিন' }} @if ($roleLabel)<span class="ml-1 rounded-full bg-brand-soft text-brand text-xs px-2 py-0.5">{{ $roleLabel }}</span>@endif</span>
                <form method="POST" action="{{ route('admin.logout') }}">@csrf
                    <button class="rounded-lg border border-slate-300 hover:bg-slate-100 px-3 py-1.5">লগআউট</button>
                </form>
            </div>
        </header>
        <main class="p-4 md:p-8">
            @include('layouts.flash')
            @yield('content')
        </main>
    </div>
</div>
<div id="toastBox" class="fixed top-4 right-4 z-[90] space-y-2 w-80 max-w-[92vw]"></div>
<script>
(function () {
    var feed = @json(route('admin.notifications.feed')), KEY = 'nenvai_notif_read', SND = 'nenvai_notif_sound';
    var items = [], lastId = 0, readId = parseInt(localStorage.getItem(KEY) || '-1', 10), ready = false, ctx = null;
    var btn = document.getElementById('bellBtn'), panel = document.getElementById('bellPanel'), badge = document.getElementById('bellBadge'),
        list = document.getElementById('bellList'), sound = document.getElementById('bellSound'), perm = document.getElementById('bellPerm'), toasts = document.getElementById('toastBox');
    if (!btn) return;
    sound.checked = localStorage.getItem(SND) !== '0';
    sound.addEventListener('change', function () { localStorage.setItem(SND, sound.checked ? '1' : '0'); if (sound.checked) beep(); });
    if ('Notification' in window && Notification.permission === 'default') { perm.classList.remove('hidden'); perm.onclick = function () { Notification.requestPermission().then(function () { perm.classList.add('hidden'); }); }; }

    function beep() {
        if (!sound.checked) return;
        try {
            ctx = ctx || new (window.AudioContext || window.webkitAudioContext)();
            [[880, 0], [1175, 0.16]].forEach(function (n) {
                var o = ctx.createOscillator(), g = ctx.createGain(); o.type = 'sine'; o.frequency.value = n[0]; o.connect(g); g.connect(ctx.destination);
                var t = ctx.currentTime + n[1]; g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.25, t + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.28); o.start(t); o.stop(t + 0.3);
            });
        } catch (e) {}
    }
    function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text) e.textContent = text; return e; }
    function unread() { return items.filter(function (i) { return i.id > readId; }).length; }
    function paint() {
        var n = unread(); badge.textContent = n > 99 ? '99+' : n; badge.classList.toggle('hidden', n === 0);
        list.textContent = '';
        if (!items.length) list.appendChild(el('div', 'px-4 py-6 text-center text-sm text-slate-500', 'এখনো কোনো নোটিফিকেশন নেই'));
        items.slice().reverse().forEach(function (i) {
            var a = el('a', 'block px-4 py-2.5 border-b border-slate-100 hover:bg-slate-50 ' + (i.id > readId ? 'bg-brand-soft/60' : '')); a.href = i.url || '#';
            a.appendChild(el('div', 'text-sm font-medium', i.title)); if (i.body) a.appendChild(el('div', 'text-xs text-slate-600', i.body)); a.appendChild(el('div', 'text-[11px] text-slate-400 mt-0.5', i.ago));
            list.appendChild(a);
        });
    }
    function toast(i) {
        var t = el('a', 'block rounded-xl bg-slate-900 text-white shadow-xl px-4 py-3 border-l-4 border-green-400'); t.href = i.url || '#';
        t.appendChild(el('div', 'text-sm font-semibold', i.title)); if (i.body) t.appendChild(el('div', 'text-xs text-slate-300 mt-0.5', i.body));
        toasts.appendChild(t); setTimeout(function () { t.remove(); }, 9000);
        if ('Notification' in window && Notification.permission === 'granted' && document.hidden) { try { new Notification(i.title, { body: i.body || '' }); } catch (e) {} }
    }
    function load() {
        var url = feed + (ready ? '?after=' + lastId : '');
        fetch(url, { headers: { 'Accept': 'application/json' }, credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (d) {
            if (!ready) { items = d.items; lastId = d.latest; if (readId < 0) { readId = lastId; localStorage.setItem(KEY, readId); } ready = true; }
            else if (d.items.length) { d.items.forEach(function (i) { items.push(i); toast(i); }); items = items.slice(-30); lastId = d.latest; beep(); }
            paint();
        }).catch(function () {});
    }
    btn.addEventListener('click', function (e) { e.stopPropagation(); panel.classList.toggle('hidden'); if (!panel.classList.contains('hidden')) { readId = lastId; localStorage.setItem(KEY, readId); paint(); } });
    document.addEventListener('click', function (e) { if (!panel.contains(e.target) && e.target !== btn) panel.classList.add('hidden'); });
    load(); setInterval(load, 15000);
})();
</script>
@include('layouts._lightbox')
@endsection
