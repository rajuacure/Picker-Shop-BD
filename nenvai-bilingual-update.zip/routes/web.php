<?php
use App\Http\Controllers\Admin;
use App\Http\Controllers\AccountController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\CheckoutController;
use App\Http\Controllers\CheckoutTrackController;
use App\Http\Controllers\FeedController;
use App\Http\Controllers\InvoiceController;
use App\Http\Controllers\LiveController;
use App\Http\Controllers\CustomerAuthController;
use App\Http\Controllers\PageController;
use App\Http\Controllers\ReviewController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\ShopController;
use App\Http\Controllers\SitemapController;
use App\Http\Middleware\AdminOnly;
use App\Http\Middleware\AdminRole;
use Illuminate\Support\Facades\Route;

// দোকান
Route::post('/live/ping', [LiveController::class, 'ping'])->middleware('throttle:20,1')->name('live.ping');
Route::get('/search/suggest', [ShopController::class, 'suggest'])->middleware('throttle:90,1')->name('search.suggest');
Route::get('/review/{orderNo}', [ReviewController::class, 'create'])->middleware('signed')->name('reviews.create');
Route::post('/review/{orderNo}', [ReviewController::class, 'store'])->middleware(['signed', 'throttle:10,1'])->name('reviews.store');
Route::get('/invoice/{orderNo}', [InvoiceController::class, 'show'])->middleware('signed')->name('invoice.show');
Route::get('/sitemap.xml', SitemapController::class)->name('sitemap');
Route::get('/feeds/facebook.csv', [FeedController::class, 'facebook'])->name('feed.facebook');
Route::get('/feeds/google.xml', [FeedController::class, 'google'])->name('feed.google');
Route::get('/', [ShopController::class, 'index'])->name('shop.index');
Route::get('/products', [ShopController::class, 'products'])->name('shop.products');
Route::get('/category/{category:slug}', [ShopController::class, 'category'])->name('shop.category');
Route::get('/product/{product:slug}', [ShopController::class, 'show'])->name('shop.show');
Route::get('/page/{page:slug}', [PageController::class, 'show'])->name('page.show');

// কাস্টমার অ্যাকাউন্ট
Route::get('/login', [CustomerAuthController::class, 'loginForm'])->name('login');
Route::post('/login', [CustomerAuthController::class, 'login'])->middleware('throttle:10,1');
Route::get('/register', [CustomerAuthController::class, 'registerForm'])->name('register');
Route::post('/register', [CustomerAuthController::class, 'register'])->middleware('throttle:10,1');
Route::post('/logout', [CustomerAuthController::class, 'logout'])->name('logout');
Route::middleware('auth')->group(function () {
    Route::get('/account', [AccountController::class, 'index'])->name('account');
    Route::put('/account', [AccountController::class, 'update'])->name('account.update');
    Route::get('/account/orders/{orderNo}', [AccountController::class, 'order'])->name('account.order');
});

// কার্ট
Route::get('/cart', [CartController::class, 'index'])->name('cart.index');
Route::get('/cart/mini', [CartController::class, 'mini'])->name('cart.mini');
Route::post('/cart/add/{product}', [CartController::class, 'add'])->name('cart.add');
Route::patch('/cart/{product}', [CartController::class, 'update'])->name('cart.update');
Route::delete('/cart/{product}', [CartController::class, 'remove'])->name('cart.remove');

// চেকআউট
Route::get('/checkout', [CheckoutController::class, 'show'])->name('checkout.show');
Route::post('/checkout', [CheckoutController::class, 'store'])->name('checkout.store');
Route::post('/checkout/track', [CheckoutTrackController::class, 'track'])->middleware('throttle:60,1')->name('checkout.track');
Route::get('/order/{orderNo}/success', [CheckoutController::class, 'success'])->name('checkout.success');

// পেমেন্ট (গেটওয়ের কলব্যাকে CSRF টোকেন থাকে না — README দেখুন)
Route::get('/pay/{orderNo}', [PaymentController::class, 'start'])->name('payment.start');
Route::match(['get', 'post'], '/payment/ssl/success', [PaymentController::class, 'sslSuccess'])->name('payment.ssl.success');
Route::match(['get', 'post'], '/payment/ssl/fail', [PaymentController::class, 'sslFail'])->name('payment.ssl.fail');
Route::match(['get', 'post'], '/payment/ssl/cancel', [PaymentController::class, 'sslCancel'])->name('payment.ssl.cancel');
Route::post('/payment/ssl/ipn', [PaymentController::class, 'sslIpn'])->name('payment.ssl.ipn');
Route::get('/payment/bkash/{orderNo}', [PaymentController::class, 'bkashCallback'])->name('payment.bkash.callback');

// অ্যাডমিন
Route::prefix('admin')->name('admin.')->group(function () {
    Route::get('login', [Admin\AuthController::class, 'form'])->name('login');
    Route::post('login', [Admin\AuthController::class, 'login'])->middleware('throttle:5,1');
    Route::post('logout', [Admin\AuthController::class, 'logout'])->name('logout');

    Route::middleware(AdminOnly::class)->group(function () {
        Route::middleware(AdminRole::class . ':dashboard')->group(function () {
            Route::get('/', Admin\DashboardController::class)->name('dashboard');
            Route::get('live', [Admin\LiveController::class, 'index'])->name('live');
            Route::get('live/data', [Admin\LiveController::class, 'data'])->name('live.data');
            Route::get('notifications/feed', [Admin\NotificationController::class, 'feed'])->name('notifications.feed');
            Route::get('notifications', [Admin\NotificationController::class, 'index'])->name('notifications.index');
        });

        Route::middleware(AdminRole::class . ':order_edit')->group(function () {
            Route::get('orders/create', [Admin\OrderEditorController::class, 'create'])->name('orders.create');
            Route::post('orders', [Admin\OrderEditorController::class, 'store'])->name('orders.store');
            Route::get('orders/customer-lookup', [Admin\OrderEditorController::class, 'lookup'])->name('orders.lookup');
            Route::get('orders/{order}/edit', [Admin\OrderEditorController::class, 'edit'])->name('orders.edit');
            Route::put('orders/{order}', [Admin\OrderEditorController::class, 'update'])->name('orders.update');
            Route::post('orders/{order}/fake', [Admin\FraudController::class, 'markFake'])->name('orders.fake');
            Route::post('orders/{order}/unfake', [Admin\FraudController::class, 'unmarkFake'])->name('orders.unfake');
            Route::get('blocked-phones', [Admin\FraudController::class, 'blocked'])->name('blocked.index');
            Route::post('blocked-phones', [Admin\FraudController::class, 'blockStore'])->name('blocked.store');
            Route::delete('blocked-phones/{blocked}', [Admin\FraudController::class, 'blockDestroy'])->name('blocked.destroy');
        });

        Route::middleware(AdminRole::class . ':orders')->group(function () {
            Route::get('orders', [Admin\OrderController::class, 'index'])->name('orders.index');
            Route::get('orders/invoices', [Admin\InvoiceController::class, 'bulk'])->name('orders.invoices');
            Route::get('orders/{order}/invoice', [Admin\InvoiceController::class, 'show'])->name('orders.invoice');
            Route::get('orders/{order}', [Admin\OrderController::class, 'show'])->name('orders.show');
            Route::patch('orders/{order}/status', [Admin\OrderController::class, 'updateStatus'])->name('orders.status');
            Route::post('orders/{order}/note', [Admin\OrderController::class, 'addNote'])->name('orders.note');
            Route::post('orders/{order}/paid', [Admin\OrderController::class, 'markPaid'])->name('orders.paid');
        });

        Route::middleware(AdminRole::class . ':courier')->group(function () {
            Route::post('orders/{order}/courier/send', [Admin\CourierController::class, 'send'])->name('orders.courier.send');
            Route::post('orders/{order}/courier/sync', [Admin\CourierController::class, 'sync'])->name('orders.courier.sync');
            Route::post('orders/{order}/courier/manual', [Admin\CourierController::class, 'manual'])->name('orders.courier.manual');
        });

        Route::middleware(AdminRole::class . ':profit')->group(function () {
            Route::get('expenses', [Admin\ExpenseController::class, 'index'])->name('expenses.index');
            Route::post('expenses', [Admin\ExpenseController::class, 'store'])->name('expenses.store');
            Route::get('expenses/report', [Admin\ExpenseController::class, 'report'])->name('expenses.report');
            Route::get('expenses/export', [Admin\ExpenseController::class, 'export'])->name('expenses.export');
            Route::get('expenses/{expense}/edit', [Admin\ExpenseController::class, 'edit'])->name('expenses.edit');
            Route::put('expenses/{expense}', [Admin\ExpenseController::class, 'update'])->name('expenses.update');
            Route::delete('expenses/{expense}', [Admin\ExpenseController::class, 'destroy'])->name('expenses.destroy');
            Route::get('expense-categories', [Admin\ExpenseCategoryController::class, 'index'])->name('expense-categories.index');
            Route::post('expense-categories', [Admin\ExpenseCategoryController::class, 'store'])->name('expense-categories.store');
            Route::patch('expense-categories/{category}', [Admin\ExpenseCategoryController::class, 'update'])->name('expense-categories.update');
            Route::delete('expense-categories/{category}', [Admin\ExpenseCategoryController::class, 'destroy'])->name('expense-categories.destroy');
        });

        Route::middleware(AdminRole::class . ':customers')->group(function () {
            Route::get('customers', [Admin\CustomerController::class, 'index'])->name('customers.index');
            Route::get('customers/{phone}', [Admin\CustomerController::class, 'show'])->name('customers.show');
        });

        Route::middleware(AdminRole::class . ':abandoned')->group(function () {
            Route::get('abandoned', [Admin\AbandonedController::class, 'index'])->name('abandoned.index');
            Route::get('abandoned/export', [Admin\AbandonedController::class, 'export'])->name('abandoned.export');
            Route::patch('abandoned/{abandoned}', [Admin\AbandonedController::class, 'update'])->name('abandoned.update');
            Route::delete('abandoned/{abandoned}', [Admin\AbandonedController::class, 'destroy'])->name('abandoned.destroy');
        });

        Route::middleware(AdminRole::class . ':catalog')->group(function () {
            Route::resource('products', Admin\ProductController::class)->except('show');
            Route::resource('categories', Admin\CategoryController::class)->except('show');
            Route::resource('sliders', Admin\SliderController::class)->except('show');
            Route::resource('pages', Admin\PageController::class)->except('show');
            Route::get('reviews', [Admin\ReviewController::class, 'index'])->name('reviews.index');
            Route::patch('reviews/{review}', [Admin\ReviewController::class, 'update'])->name('reviews.update');
            Route::delete('reviews/{review}', [Admin\ReviewController::class, 'destroy'])->name('reviews.destroy');
            Route::get('seo', [Admin\SeoController::class, 'index'])->name('seo.index');
            Route::get('translations', [Admin\TranslationController::class, 'index'])->name('translations.index');
            Route::post('translations', [Admin\TranslationController::class, 'save'])->name('translations.save');
            Route::post('translations/clear-missing', [Admin\TranslationController::class, 'clearMissing'])->name('translations.clear');
            Route::get('import', [Admin\ProductImportController::class, 'form'])->name('import.form');
            Route::post('import', [Admin\ProductImportController::class, 'run'])->name('import.run');
            Route::get('import/sample', [Admin\ProductImportController::class, 'sample'])->name('import.sample');
            Route::get('export', [Admin\ProductImportController::class, 'export'])->name('export');
        });

        Route::middleware(AdminRole::class . ':settings')->group(function () {
            Route::get('settings', [Admin\SettingController::class, 'edit'])->name('settings.edit');
            Route::post('settings', [Admin\SettingController::class, 'update'])->name('settings.update');
            Route::get('payments', [Admin\PaymentSettingController::class, 'edit'])->name('payments.edit');
            Route::post('payments', [Admin\PaymentSettingController::class, 'update'])->name('payments.update');
            Route::get('courier', [Admin\CourierController::class, 'edit'])->name('courier.edit');
            Route::post('courier', [Admin\CourierController::class, 'update'])->name('courier.update');
            Route::post('courier/test', [Admin\CourierController::class, 'test'])->name('courier.test');
            Route::post('seo/robots', [Admin\SeoController::class, 'writeRobots'])->name('seo.robots');
            Route::post('settings/test-notify', [Admin\SettingController::class, 'testNotify'])->name('settings.test-notify');
            Route::resource('zones', Admin\ShippingZoneController::class)->except('show');
        });

        Route::middleware(AdminRole::class . ':admins')->group(function () {
            Route::resource('users', Admin\AdminUserController::class)->except('show')->parameters(['users' => 'adminUser']);
        });
    });
});
