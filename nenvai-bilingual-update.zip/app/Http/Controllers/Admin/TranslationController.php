<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Page;
use App\Models\Product;
use App\Models\Setting;
use App\Models\Slider;
use App\Models\Translation;
use App\Support\I18n;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;

/** সাইটের ইংরেজি সংস্করণের অনুবাদ: পণ্য, ক্যাটাগরি, পেজ, স্লাইডার, সাইটের লেখা ও বাকি সব লেখা */
class TranslationController extends Controller
{
    private const SETTINGS = ['topbar_text' => 'ওপরের ঘোষণা', 'footer_about' => 'ফুটারের পরিচিতি', 'address' => 'ঠিকানা', 'hours' => 'খোলার সময়', 'site_description' => 'সাইটের বর্ণনা (Google-এর লেখা)'];

    public function index(Request $request)
    {
        $tab = in_array($request->query('tab'), ['products', 'categories', 'pages', 'site', 'missing', 'all'], true) ? $request->query('tab') : 'products';
        $dict = I18n::dict()['all'];
        $have = fn (string $src) => isset($dict[I18n::norm($src)]);

        $rows = [];
        $pager = null;
        switch ($tab) {
            case 'products':
                $page = Product::orderBy('id')->paginate(20)->withQueryString();
                foreach ($page as $p) {
                    $rows[] = $this->row('p' . $p->id . 'n', 'পণ্যের নাম', $p->name, $dict, false);
                    if (trim((string) $p->description) !== '') $rows[] = $this->row('p' . $p->id . 'd', 'পণ্যের বিবরণ', $p->description, $dict, true, $p->name);
                }
                $pager = $page;
                break;
            case 'categories':
                foreach (Category::orderBy('sort_order')->orderBy('name')->get() as $c) $rows[] = $this->row('c' . $c->id, 'ক্যাটাগরি', $c->name, $dict, false);
                break;
            case 'pages':
                foreach (Page::orderBy('id')->get() as $g) {
                    $rows[] = $this->row('g' . $g->id . 't', 'পেজের শিরোনাম', $g->title, $dict, false);
                    $rows[] = $this->row('g' . $g->id . 'c', 'পেজের লেখা', $g->content, $dict, true, $g->title);
                }
                foreach (Slider::orderBy('id')->get() as $s) {
                    foreach (['title' => 'স্লাইডারের শিরোনাম', 'subtitle' => 'স্লাইডারের ছোট লেখা', 'button_text' => 'স্লাইডারের বাটন'] as $f => $label) {
                        if (trim((string) $s->$f) !== '') $rows[] = $this->row('s' . $s->id . $f[0], $label, $s->$f, $dict, false);
                    }
                }
                break;
            case 'site':
                foreach (self::SETTINGS as $k => $label) {
                    $v = trim((string) Setting::get($k));
                    if ($v !== '') $rows[] = $this->row('st:' . $k, $label, $v, $dict, mb_strlen($v) > 90);
                }
                foreach ($this->trustParts() as $i => [$label, $v]) $rows[] = $this->row('tb:' . $i, $label, $v, $dict, false);
                break;
            case 'missing':
                $miss = (array) Cache::get('i18n_missing', []);
                arsort($miss);
                foreach ($miss as $src => $n) {
                    if ($have($src)) continue;
                    $rows[] = $this->row('m:' . sha1($src), 'দেখা গেছে ' . $n . 'বার', $src, $dict, mb_strlen($src) > 90);
                }
                break;
            case 'all':
                foreach ($this->base() as $src => $en) $rows[] = $this->row('m:' . sha1($src), '', $src, $dict, mb_strlen($src) > 90);
                break;
        }

        return view('admin.translations', [
            'tab' => $tab, 'rows' => $rows, 'pager' => $pager,
            'counts' => $this->counts($dict),
        ]);
    }

    public function save(Request $request)
    {
        $n = 0;
        foreach ((array) $request->input('en', []) as $key => $val) {
            $src = $this->resolve((string) $key);
            if ($src === null) continue;
            $src = I18n::norm($src);
            if ($src === '' || mb_strlen($src) > 8000) continue;

            $val = trim(str_replace("\r", '', str_replace(['"', "'", '<', '>', '\\'], ['”', '’', '', '', ''], (string) $val)));
            $hash = sha1($src);
            if ($val === '') { Translation::where('src_hash', $hash)->delete(); continue; }
            Translation::updateOrCreate(['src_hash' => $hash], ['src' => $src, 'en' => mb_substr($val, 0, 8000), 'kind' => str_starts_with((string) $key, 'm:') ? 'ui' : 'data']);
            $n++;
        }
        I18n::forget();
        return redirect()->route('admin.translations.index', ['tab' => $request->input('tab', 'products'), 'page' => $request->input('page')])->with('success', 'অনুবাদ সেভ হয়েছে (' . $n . 'টি)। ইংরেজি সাইটে এখনই দেখা যাবে।');
    }

    public function clearMissing()
    {
        Cache::forget('i18n_missing');
        return back()->with('success', 'বাকি লেখার তালিকা খালি করা হয়েছে। ইংরেজি পেজ খুললে আবার জমা হবে।');
    }

    // ---------------------------------------------------------------- সহায়ক

    private function row(string $key, string $label, ?string $src, array $dict, bool $long, ?string $group = null): array
    {
        $src = (string) $src;
        return ['key' => $key, 'label' => $label, 'src' => $src, 'long' => $long, 'group' => $group, 'en' => $dict[I18n::norm($src)] ?? ''];
    }

    private function base(): array
    {
        $f = base_path('lang/en_ui.php');
        return is_file($f) ? (array) require $f : [];
    }

    /** ট্রাস্ট বারের (আইকন | শিরোনাম | ছোট লেখা) অনুবাদযোগ্য অংশ */
    private function trustParts(): array
    {
        $out = [];
        $i = 0;
        foreach (preg_split('/\r\n|\n|\r/', (string) Setting::get('trust_bar')) as $line) {
            $p = array_map('trim', explode('|', $line));
            if (count($p) < 2 || $p[1] === '') { $i += 2; continue; }
            $out[$i] = ['ট্রাস্ট বার: শিরোনাম', $p[1]];
            if (! empty($p[2])) $out[$i + 1] = ['ট্রাস্ট বার: ছোট লেখা', $p[2]];
            $i += 2;
        }
        return $out;
    }

    /** ফর্মের চাবি থেকে মূল বাংলা লেখা বের করা (ফর্মে পাঠানো লেখা বিশ্বাস করা হয় না) */
    private function resolve(string $key): ?string
    {
        if (preg_match('/^p(\d+)([nd])$/', $key, $m)) { $p = Product::find($m[1]); return $p ? ($m[2] === 'n' ? $p->name : $p->description) : null; }
        if (preg_match('/^c(\d+)$/', $key, $m)) return Category::find($m[1])?->name;
        if (preg_match('/^g(\d+)([tc])$/', $key, $m)) { $g = Page::find($m[1]); return $g ? ($m[2] === 't' ? $g->title : $g->content) : null; }
        if (preg_match('/^s(\d+)([tsb])$/', $key, $m)) { $s = Slider::find($m[1]); $f = ['t' => 'title', 's' => 'subtitle', 'b' => 'button_text'][$m[2]]; return $s?->$f; }
        if (preg_match('/^st:([a-z_]+)$/', $key, $m)) return isset(self::SETTINGS[$m[1]]) ? Setting::get($m[1]) : null;
        if (preg_match('/^tb:(\d+)$/', $key, $m)) return $this->trustParts()[(int) $m[1]][1] ?? null;
        if (str_starts_with($key, 'm:')) {
            $hash = substr($key, 2);
            foreach (array_keys($this->base()) as $src) if (sha1($src) === $hash) return $src;
            foreach (array_keys((array) Cache::get('i18n_missing', [])) as $src) if (sha1($src) === $hash) return $src;
        }
        return null;
    }

    /** প্রতিটি ট্যাবে কতটা অনুবাদ হয়ে গেছে */
    private function counts(array $dict): array
    {
        $done = fn (iterable $srcs) => collect($srcs)->filter(fn ($s) => trim((string) $s) !== '')->map(fn ($s) => isset($dict[I18n::norm((string) $s)]))->all();
        $pack = fn (array $flags) => ['done' => count(array_filter($flags)), 'total' => count($flags)];

        $prod = [];
        foreach (Product::select('name', 'description')->get() as $p) { $prod[] = $p->name; if (trim((string) $p->description) !== '') $prod[] = $p->description; }
        $pages = [];
        foreach (Page::select('title', 'content')->get() as $g) { $pages[] = $g->title; $pages[] = $g->content; }
        foreach (Slider::get() as $s) foreach (['title', 'subtitle', 'button_text'] as $f) $pages[] = $s->$f;
        $site = array_map(fn ($k) => Setting::get($k), array_keys(self::SETTINGS));
        foreach ($this->trustParts() as [$l, $v]) $site[] = $v;

        return [
            'products'   => $pack($done($prod)),
            'categories' => $pack($done(Category::pluck('name'))),
            'pages'      => $pack($done($pages)),
            'site'       => $pack($done($site)),
            'missing'    => ['done' => 0, 'total' => count(array_filter(array_keys((array) Cache::get('i18n_missing', [])), fn ($s) => ! isset($dict[I18n::norm($s)])))],
            'all'        => ['done' => count($this->base()), 'total' => count($this->base())],
        ];
    }
}
