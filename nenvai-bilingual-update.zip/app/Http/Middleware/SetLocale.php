<?php
namespace App\Http\Middleware;

use App\Support\I18n;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\StreamedResponse;

/** ভাষা বাছাই (?lang=en বা ?lang=bn, কুকিতে মনে রাখে)। ইংরেজি হলে পেজের বাংলা লেখা অনুবাদ করে দেয়। অ্যাডমিন সবসময় বাংলা। */
class SetLocale
{
    public function handle(Request $request, Closure $next)
    {
        if ($request->is('admin', 'admin/*')) {
            app()->setLocale('bn');
            return $next($request);
        }

        $q = $request->query('lang');
        if ($request->isMethod('GET') && in_array($q, ['bn', 'en'], true)) {
            return redirect($request->fullUrlWithoutQuery('lang'))->withCookie(cookie('lang', $q, 60 * 24 * 365));
        }

        $lang = $request->cookie('lang');
        $lang = in_array($lang, ['bn', 'en'], true) ? $lang : 'bn';
        app()->setLocale($lang);

        $response = $next($request);
        if ($lang !== 'en') return $response;

        try {
            if ($response instanceof RedirectResponse || $response instanceof BinaryFileResponse || $response instanceof StreamedResponse) return $response;
            if ($request->is('payment/*', 'feeds/*', 'sitemap.xml', 'live/*')) return $response;

            $type = strtolower((string) $response->headers->get('Content-Type'));
            $body = $response->getContent();
            if (! is_string($body) || $body === '') return $response;

            if (str_contains($type, 'text/html')) {
                $out = I18n::translateHtml($body);
            } elseif (str_contains($type, 'json')) {
                $out = I18n::translateJson($body);
            } else {
                return $response;
            }
            if ($out === '' || strlen($out) < strlen($body) / 3) return $response;   // কিছু ভুল হলে মূল পেজই যাবে
            $response->setContent($out);
            $response->headers->remove('Content-Length');
        } catch (\Throwable $e) {
            report($e);   // অনুবাদে সমস্যা হলে বাংলা পেজই যায়, সাইট ভাঙে না
        }
        return $response;
    }
}
