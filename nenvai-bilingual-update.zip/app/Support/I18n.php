<?php
namespace App\Support;

use App\Models\Translation;
use Illuminate\Support\Facades\Cache;

/**
 * দুই ভাষা (বাংলা/ইংরেজি): ইংরেজি বেছে নিলে পেজ তৈরি হওয়ার পর বাংলা লেখাগুলো অনুবাদ-তালিকা দেখে ইংরেজি করে দেওয়া হয়।
 * পণ্যের নাম/বিবরণ, ক্যাটাগরি, পেজ ইত্যাদির অনুবাদ অ্যাডমিনের "ইংরেজি অনুবাদ" পেজ থেকে আসে।
 * অনুবাদ না পেলে বাংলাই থাকে, আর সেটি "বাকি লেখা" তালিকায় জমা হয়।
 */
class I18n
{
    private const C = '\x{0980}-\x{09F2}\x{09F4}-\x{09FF}';   // বাংলা অক্ষর ও সংখ্যা (টাকার চিহ্ন ৳ বাদে)
    public const RUN = '/[' . self::C . ']+(?:[ \t.,!?:;\-()\/·&+%]+[' . self::C . ']+)*/u';
    private const BN = '/[' . self::C . ']/u';
    private const DIGITS = ['০' => '0', '১' => '1', '২' => '2', '৩' => '3', '৪' => '4', '৫' => '5', '৬' => '6', '৭' => '7', '৮' => '8', '৯' => '9'];
    private const UNITS = ['মি.লি.' => 'ml', 'মি.লি' => 'ml', 'মিলি' => 'ml', 'গ্রাম' => 'g', 'কেজি' => 'kg', 'লিটার' => 'L', 'পিস' => 'pcs', 'ডজন' => 'dozen'];

    private static ?array $dict = null;
    private static array $miss = [];

    public static function isEn(): bool
    {
        return app()->getLocale() === 'en';
    }

    public static function norm(string $s): string
    {
        return trim((string) preg_replace('/\s+/u', ' ', $s));
    }

    /** ['all' => বাংলা => ইংরেজি, 'mixed' => ASCII মেশানো বাক্যাংশ] */
    public static function dict(): array
    {
        if (self::$dict !== null) return self::$dict;

        $base = [];
        $file = base_path('lang/en_ui.php');
        if (is_file($file)) $base = (array) require $file;

        try {
            $db = Cache::remember('i18n_db_v1', 600, fn () => Translation::query()->pluck('en', 'src')->all());
        } catch (\Throwable $e) {
            $db = [];   // টেবিল না থাকলে (migrate বাকি) শুধু মূল তালিকা
        }

        $all = [];
        foreach ([$base, $db] as $set) {
            foreach ($set as $k => $v) {
                $k = self::norm((string) $k);
                if ($k !== '' && (string) $v !== '') $all[$k] = (string) $v;
            }
        }
        $mixed = array_filter($all, fn ($v, $k) => (preg_match('/[A-Za-z0-9]/', (string) $k) === 1 || str_starts_with((string) $k, '-')) && preg_match(self::BN, (string) $k) === 1, ARRAY_FILTER_USE_BOTH);

        return self::$dict = ['all' => $all, 'mixed' => $mixed];
    }

    public static function forget(): void
    {
        Cache::forget('i18n_db_v1');
        self::$dict = null;
    }

    /** কোডে সরাসরি অনুবাদ চাইলে: I18n::t('বাংলা লেখা') */
    public static function t(?string $s): string
    {
        $s = (string) $s;
        if ($s === '' || ! self::isEn()) return $s;
        return self::dict()['all'][self::norm($s)] ?? $s;
    }

    /** preg_replace_callback, ব্যর্থ হলে (null) মূল লেখাই ফেরত দেয় */
    private static function rc(string $pattern, callable $cb, string $subject, int $flags = 0): string
    {
        $r = preg_replace_callback($pattern, $cb, $subject, -1, $count, $flags);
        return $r === null ? $subject : $r;
    }

    public static function digits(string $s): string
    {
        return strtr($s, self::DIGITS);
    }

    public static function units(string $s): string
    {
        static $re = null;
        $re ??= '/(\d+(?:\.\d+)?)\s*(' . implode('|', array_map(fn ($u) => preg_quote($u, '/'), array_keys(self::UNITS))) . ')/u';
        return self::rc($re, fn ($m) => $m[1] . ' ' . self::UNITS[$m[2]], $s);
    }

    /** শুধু বাংলা শব্দের টুকরোগুলো অনুবাদ */
    private static function runs(string $text): string
    {
        $d = self::dict()['all'];
        return self::rc(self::RUN, function ($m) use ($d, $text) {
            $r = $m[0][0];
            $off = $m[0][1];
            $prev = $off > 0 ? $text[$off - 1] : ' ';
            $fix = fn (string $rep) => ($rep !== '' && $rep[0] === ' ' && ctype_space($prev)) ? ltrim($rep, ' ') : $rep;   // "5 " + " left" => "5 left"

            $k = self::norm($r);
            if (isset($d[$k])) return $fix($d[$k]);
            $parts = preg_split('/([.,!?:;()\/·&+%\-]+\s*)/u', $r, -1, PREG_SPLIT_DELIM_CAPTURE);
            if (is_array($parts) && count($parts) > 1) {
                foreach ($parts as $i => $p) {
                    if ($i % 2) continue;
                    $kk = self::norm($p);
                    if ($kk === '') continue;
                    if (isset($d[$kk])) $parts[$i] = $d[$kk]; else self::$miss[$kk] = true;
                }
                return $fix(implode('', $parts));
            }
            self::$miss[$k] = true;
            return $r;
        }, $text, PREG_OFFSET_CAPTURE);
    }

    /** একটি লেখা (টেক্সট নোড, অ্যাট্রিবিউট, JSON মান) অনুবাদ */
    private static function one(string $text, array $d): string
    {
        if (preg_match(self::BN, $text) !== 1) return $text;
        $k = self::norm($text);
        if (isset($d['all'][$k])) return $d['all'][$k];
        // শুরুতে ইমোজি/চিহ্ন থাকলে সেগুলো বাদ দিয়ে খোঁজা
        if (preg_match('/^([^\p{L}\p{N}]+)(.+)$/us', $text, $mm)) {
            $k2 = self::norm($mm[2]);
            if (isset($d['all'][$k2])) return $mm[1] . $d['all'][$k2];
        }
        if (mb_strlen($k) > 160) return $text;   // বড় লেখা (বিবরণ ইত্যাদি) টুকরো করে অনুবাদ করা হয় না
        return self::runs(self::units(self::digits($text)));
    }

    public static function translateHtml(string $html): string
    {
        $d = self::dict();
        $scripts = [];
        $blocks = [];

        // ১) <script>/<style> আলাদা রাখা
        $html = self::rc('~<(script|style)\b[^>]*>.*?</\1\s*>~is', function ($m) use (&$scripts) {
            $scripts[] = $m[0];
            return "\x02S" . (count($scripts) - 1) . "\x03";
        }, $html);

        // ২) <!--tr--> বিবরণ <!--/tr--> ব্লক: পুরো লেখার অনুবাদ থাকলে বসে, নইলে যেমন আছে তেমন (টুকরো অনুবাদ হয় না)
        $html = self::rc('~<!--(tr|trbr)-->(.*?)<!--/tr-->~s', function ($m) use (&$blocks, $d) {
            $plain = html_entity_decode(strip_tags((string) preg_replace('~<br\s*/?>~i', "\n", $m[2])), ENT_QUOTES | ENT_HTML5, 'UTF-8');
            $en = $d['all'][self::norm($plain)] ?? null;
            if ($en === null) {
                self::$miss[self::norm($plain)] = true;
                $blocks[] = $m[2];
            } else {
                $safe = htmlspecialchars($en, ENT_QUOTES, 'UTF-8');
                $blocks[] = $m[1] === 'trbr' ? nl2br($safe) : $safe;
            }
            return "\x02B" . (count($blocks) - 1) . "\x03";
        }, $html);

        // ৩) ASCII মেশানো বাক্যাংশ
        if ($d['mixed']) $html = strtr($html, $d['mixed']);

        // ৪) অ্যাট্রিবিউট
        $html = self::rc('~\b(alt|title|aria-label|placeholder|content)="([^"]*[' . self::C . '][^"]*)"~u', function ($m) use ($d) {
            $v = html_entity_decode($m[2], ENT_QUOTES | ENT_HTML5, 'UTF-8');
            $t = self::one($v, $d);
            return $t === $v ? $m[0] : $m[1] . '="' . htmlspecialchars($t, ENT_QUOTES, 'UTF-8') . '"';
        }, $html);

        // ৫) টেক্সট নোড
        $html = self::rc('~>([^<>]*[' . self::C . '][^<>]*)<~u', function ($m) use ($d) {
            $v = html_entity_decode($m[1], ENT_QUOTES | ENT_HTML5, 'UTF-8');
            if (! preg_match('/^(\s*)(.*?)(\s*)$/us', $v, $p)) return $m[0];
            $t = self::one($p[2], $d);
            return $t === $p[2] ? $m[0] : '>' . $p[1] . htmlspecialchars($t, ENT_QUOTES, 'UTF-8') . $p[3] . '<';
        }, $html);

        // ৬) ফিরিয়ে আনা: ব্লক, তারপর স্ক্রিপ্ট (স্ক্রিপ্টের ভেতরের লেখাও অনুবাদ হয়)
        $html = self::rc('~\x02B(\d+)\x03~', fn ($m) => $blocks[(int) $m[1]] ?? '', $html);
        $html = self::rc('~\x02S(\d+)\x03~', function ($m) use ($scripts, $d) {
            $s = $scripts[(int) $m[1]] ?? '';
            if ($d['mixed']) $s = strtr($s, $d['mixed']);
            return self::runs(self::units(self::digits($s)));
        }, $html);

        // ৭) সংখ্যা, একক ও দাঁড়ি
        $html = self::units(self::digits($html));
        $html = str_replace('।', '.', $html);

        self::flushMisses();
        return $html;
    }

    public static function translateJson(string $json): string
    {
        $data = json_decode($json, true);
        if (! is_array($data)) return $json;
        $d = self::dict();
        $walk = function ($v) use (&$walk, $d) {
            if (is_array($v)) return array_map($walk, $v);
            if (! is_string($v) || preg_match(self::BN, $v) !== 1) return $v;
            if ($d['mixed']) $v = strtr($v, $d['mixed']);
            return str_replace('।', '.', self::one($v, $d));
        };
        return (string) json_encode($walk($data), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION);
    }

    /** অনুবাদ না পাওয়া লেখাগুলো অ্যাডমিনকে দেখানোর জন্য জমা রাখা */
    private static function flushMisses(): void
    {
        if (! self::$miss) return;
        try {
            $have = self::dict()['all'];
            $store = Cache::get('i18n_missing', []);
            foreach (array_keys(self::$miss) as $k) {
                if (isset($have[$k]) || mb_strlen($k) < 2 || mb_strlen($k) > 300) continue;
                $store[$k] = ($store[$k] ?? 0) + 1;
            }
            if (count($store) > 500) { arsort($store); $store = array_slice($store, 0, 400, true); }
            Cache::put('i18n_missing', $store, now()->addDays(14));
        } catch (\Throwable $e) {
            // জমা রাখা না গেলে কিছু যায় আসে না
        }
        self::$miss = [];
    }
}
